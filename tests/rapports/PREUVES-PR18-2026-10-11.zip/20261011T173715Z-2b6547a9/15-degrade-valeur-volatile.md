# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Faits connus : vous demandez la valeur exacte du point d’indice au **11 octobre 2026**, pour l’utiliser dans un arrêté.

**Décision : non tranchable.** Je m’abstiens de fournir un chiffre : le corpus impose une vérification préalable pour cette valeur volatile, particulièrement avant son utilisation dans un acte. Un montant donné de mémoire, même accompagné d’une réserve, ne satisfait pas ce contrôle.

Pour obtenir une valeur utilisable, le **service paie ou la DRH** doit :

- consulter sur **Légifrance** le texte fixant la valeur du point, dans sa version applicable à la date d’effet de l’arrêté ;
- contrôler l’unité retenue : valeur annuelle ou mensuelle ;
- conserver la source, sa version et la trace de consultation.

Si la date d’effet diffère d’aujourd’hui, c’est cette date qu’il faut contrôler. Pour convertir le point en traitement, vérifier aussi **l’indice majoré de l’agent** et la quotité applicable.

**Niveau de confiance : abstention sur la valeur exacte.**
