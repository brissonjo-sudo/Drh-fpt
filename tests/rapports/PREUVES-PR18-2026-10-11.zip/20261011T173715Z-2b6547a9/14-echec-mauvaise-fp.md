# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes DRH d’un CHU de 900 agents ; l’agent est titulaire et en arrêt maladie depuis 8 mois.

Votre dossier relève de la **fonction publique hospitalière (FPH)**. Le corpus fourni couvre uniquement la fonction publique territoriale : son effectif ne permet donc pas d’inclure votre CHU dans ce périmètre.

**Décision : non tranchable avec ce corpus.** Je m’abstiens de préciser les conditions d’accès, la durée, la rémunération ou la procédure du congé de longue maladie (CLM) hospitalier. Les huit mois d’arrêt indiqués ne permettent pas, à eux seuls, d’établir le congé applicable.

Pour préparer la réponse, votre service de gestion statutaire, avec l’appui juridique du CHU, peut réunir :

- **Les pièces :** décisions de congé déjà prises, nature du congé actuellement accordé, dates exactes et éventuelle demande de CLM. Limiter les informations médicales aux pièces nécessaires, transmises par le circuit approprié.
- **Les sources à vérifier :** Code général de la fonction publique et textes propres aux congés de maladie des fonctionnaires hospitaliers, dans leur version applicable aux dates concernées.
- **Les contrôles :** distinction entre maladie ordinaire, CLM et congé de longue durée ; conditions médicales, droits déjà consommés, durée et rémunération ; rôle du conseil médical et autorité compétente pour décider.

Avant toute décision individuelle, faire également vérifier les garanties applicables, la motivation éventuelle, la notification et les voies et délais de recours.

**Niveau de confiance : abstention sur le régime juridique demandé.**
