# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon `recherche-juridique` est indisponible. Je peux préparer le dossier et les contrôles, mais pas certifier la possibilité d’engager la procédure ni fournir une procédure disciplinaire exécutable.

**Faits connus :** l’agent est titulaire ; les faits sont encore des soupçons ; une exclusion temporaire de **5 jours** est envisagée. L’employeur, les faits précis et les dates ne sont pas indiqués.

**État de décision : non tranchable.** Ma recommandation est de lancer la préparation du dossier et la vérification juridique, sans arrêter dès maintenant le choix de la sanction.

Le point central est double : établir les faits et leur éventuelle qualification disciplinaire, puis contrôler le régime applicable à l’exclusion envisagée. Le soupçon ne permet pas, à lui seul, de tenir la faute ou la proportionnalité de la sanction pour établies.

Les informations bloquantes à réunir sont :

- **Employeur et régime :** type de collectivité, effectif pour confirmer le périmètre du corpus, cadre d’emplois et éventuel statut particulier.
- **Faits et chronologie :** actes reprochés, pièces disponibles, date des faits et date de connaissance effective par l’administration ; éventuelles poursuites pénales.
- **Calendrier :** date d’ouverture envisagée, ou déjà intervenue, de la procédure et date prévue de sanction.
- **Circuit :** affiliation au centre de gestion, instance compétente et organisation de son secrétariat.

Voici les **actions préparatoires à lancer dans l’ordre**. Elles constituent un dossier de contrôle, pas une procédure disciplinaire validée.

| Ordre | Action et responsable proposé | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : qualifier le dossier** et réunir les informations ci-dessus, avec les actes de nomination utiles. | Fiche de qualification : statut, employeur, cadre d’emplois, dates et régime applicable, sans hypothèse silencieuse. |
| **2** | **Encadrement et DRH : conserver les pièces existantes** et établir une chronologie factuelle. Distinguer faits directement constatés, témoignages et allégations. | Inventaire daté des pièces, origine des éléments et points contestés. Accès limité aux personnes chargées du dossier. |
| **3** | **Service juridique ou conseil compétent : vérifier les sources officielles** aux dates utiles. | Note de contrôle traçable : textes applicables, version, passages utiles et conclusion. Vérifier notamment la prescription et l’incidence d’éventuelles poursuites pénales. |
| **4** | **DRH et juriste : préparer les garanties de défense et le circuit d’instance**, avant toute mise en œuvre. | Contrôler l’information de l’agent, l’accès au dossier intégral, l’assistance d’un conseil de son choix, un temps suffisant pour préparer sa défense et l’information sur le droit de se taire avant le recueil des observations. |
| **5** | **DRH : préparer une note d’arbitrage** pour l’autorité dont la compétence aura été vérifiée. | Comparer les faits établis, leur gravité, les éléments favorables et défavorables, les observations de l’agent et les options juridiquement disponibles. Ne pas présenter les 5 jours comme une conclusion acquise. |
| **6** | **DRH et juriste : contrôler tout projet de décision**, uniquement après validation du cadre juridique et des garanties nécessaires. | Compétence et délégation, motivation en fait et en droit, date d’effet, conséquences administratives et financières, notification traçable, recours et formalités applicables. Aucun arrêté prêt à signer n’est produit ici. |

Trois vérifications méritent une attention particulière :

- **Conseil préalable :** faire confirmer le classement de l’exclusion envisagée dans l’échelle des sanctions territoriales et la nécessité d’un avis préalable du conseil de discipline, présenté dans le corpus comme une formation de la commission administrative paritaire (CAP). Ne pas transposer le régime d’un contractuel ou d’un fonctionnaire de l’État.
- **Recours actuels :** le corpus signale la suppression de l’ancien conseil de discipline de recours. Faire confronter les textes de suppression à la structure consolidée actuelle du texte de procédure. Si un dossier ancien est concerné, vérifier les conditions d’accès et délais transitoires. Contrôler séparément le recours gracieux auprès de l’auteur et le recours contentieux, sans inventer un supérieur hiérarchique de l’autorité territoriale.
- **Contrôle de légalité :** vérifier la liste légale applicable à la nature exacte de l’acte ; distinguer les anciennes versions, la convention locale de télétransmission et une éventuelle demande préfectorale. Une pratique locale ne suffit pas à établir une obligation nationale.

**Décision recommandée à ce stade : préparer et faire vérifier, sans préjuger la sanction.** Si les faits restent insuffisamment établis, réexaminer la poursuite du dossier. S’ils sont établis, l’arbitrage devra intégrer la qualification, la proportionnalité et les garanties effectivement respectées.

Les risques à contrôler sont surtout une sanction fondée sur des faits insuffisants, une atteinte aux droits de la défense, une erreur d’instance ou une motivation inadéquate. **Niveau de confiance : abstention sur la légalité de l’engagement et de la sanction envisagée**, faute de vérification officielle et de variables déterminantes.
