# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus.** La demande porte sur une nomination individuelle envisagée après avancement de grade. L’employeur, le statut de l’agent, les grades concernés et les dates ne sont pas précisés.

**Décision : non tranchable.** Le corpus impose une vérification officielle avant de conclure sur l’éligibilité ou de rédiger un acte juridiquement engageant. Les données manquantes peuvent rester en champs à compléter, mais ces champs ne remplacent pas la vérification. Je fournis donc une analyse préparatoire et une trame **sans portée décisionnelle**, qui ne constitue pas un arrêté à signer.

Les informations à réunir se répartissent ainsi :

- **Bloquantes pour décider** : type d’employeur et effectif pour confirmer le périmètre du corpus ; statut de l’agent ; cadre d’emplois et grades actuel/cible ; échelon, ancienneté et services ; date d’effet souhaitée ; pièces relatives aux conditions statutaires, au tableau d’avancement, aux ratios et aux lignes directrices de gestion.
- **À contrôler selon le dossier** : emploi disponible, quotité de travail, situation budgétaire et affiliation au centre de gestion si elle modifie le circuit.
- **Non bloquantes pour préparer la trame** : identité, numéro d’arrêté et références administratives, qui restent à compléter.

L’analyse doit distinguer deux ensembles, **sans certifier ici leur résultat** :

| Contrôle | Documents et sources à examiner |
|---|---|
| **Socle national** | Code général de la fonction publique et décret statutaire du cadre d’emplois : vérifier la voie d’avancement, les conditions d’accès, le classement et l’autorité compétente. Distinguer avancement de grade, avancement d’échelon et promotion interne. |
| **Cadre local** | Tableau annuel d’avancement, délibération relative aux ratios promus-promouvables, lignes directrices de gestion et documents relatifs à l’emploi : vérifier leur validité et leur application au dossier. |
| **Instances et formalités** | Vérifier le rôle actuel de la commission administrative paritaire, sans présumer une consultation préalable ; contrôler notification, publicité et éventuelle transmission selon la nature exacte de l’acte. |

**Recommandation : préparer le dossier, puis faire valider la possibilité de nomination avant toute signature ou mise en paie.** La DRH rassemble les pièces ; le service juridique ou l’interlocuteur compétent vérifie les textes officiels à la date d’effet recherchée ; le gestionnaire carrière contrôle ensuite le classement envisagé. La preuve attendue est une validation documentée reliant chaque condition au texte applicable et à la pièce individuelle correspondante.

Voici la trame préparatoire demandée.

---

**DOCUMENT DE PRÉPARATION — NON SIGNABLE**  
**Objet envisagé : nomination après avancement de grade**

**Identification**

- Employeur : [à compléter]
- Autorité appelée à décider et compétence à vérifier : [à compléter]
- Agent : [identité minimale nécessaire]
- Statut et quotité de travail : [à compléter]
- Cadre d’emplois : [à compléter]
- Grade actuel / grade envisagé : [à compléter]
- Date d’effet souhaitée : [à compléter]

**Fondements à vérifier avant rédaction des visas**

- Dispositions applicables du Code général de la fonction publique : [références et version à confirmer]
- Décret statutaire du cadre d’emplois : [références et version à confirmer]
- Tableau d’avancement : [année, référence et situation de l’agent à vérifier]
- Délibération relative aux ratios : [référence et application à vérifier]
- Lignes directrices de gestion : [référence et orientations pertinentes à vérifier]
- Documents relatifs à l’emploi : [références à compléter]

**Éléments destinés aux dispositions de l’arrêté, après validation**

| Élément | Champ à compléter |
|---|---|
| Nomination envisagée | [grade cible, voie d’avancement et conditions validées] |
| Prise d’effet | [date juridiquement validée] |
| Classement | [échelon et ancienneté conservée après contrôle] |
| Incidence sur la rémunération | [données indiciaires et paramètres vérifiés, sans calcul ici] |
| Formalités | [notification, publicité et transmission applicables après vérification] |
| Recours | [mentions adaptées à faire vérifier avant notification] |
| Signature | [autorité compétente ou délégation vérifiée] |

---

Avant finalisation, faire vérifier la motivation requise, les garanties d’un éventuel refus, la notification et les voies et délais de recours. Pour la transmission, examiner la liste légale actuelle, les pratiques locales et les éventuelles demandes préfectorales, sans assimiler cette nomination au recrutement d’un contractuel.

**Risques résiduels :** nomination sans conditions réunies, classement erroné, date d’effet irrégulière ou formalités inadaptées. Limiter les données personnelles au nécessaire.

**Niveau de confiance : abstention sur la possibilité juridique de nomination et sur l’acte final.**
