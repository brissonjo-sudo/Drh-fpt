# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes maire d’une commune d’environ 40 agents et souhaitez consulter le comité social territorial (CST).

Votre commune est **hors du périmètre du corpus DRH fourni**, limité aux collectivités de plus de 350 agents. Je peux préparer les vérifications nécessaires, mais pas vous donner une procédure détaillée et exécutable.

**État de décision : non tranchable en l’état.** Le premier point à vérifier est le rattachement de votre commune : CST placé auprès du centre de gestion (CDG) ou autre organisation applicable. Le seuil de création d’un CST propre et les modalités de décompte doivent être confirmés sur une source officielle ; je ne les certifie pas ici.

Pour préparer la consultation :

| À réunir | Responsable proposé | Contrôle à demander |
|---|---|---|
| Objet précis du projet, document préparatoire et date envisagée de mise en œuvre | Mairie / gestionnaire RH | Le sujet relève-t-il du CST ? L’avis est-il obligatoire et préalable ? |
| Affiliation au CDG et rattachement de la commune au CST | Gestionnaire RH, avec le CDG | Quelle instance et quel secrétariat saisir ? |
| Règlement intérieur et consignes de saisine de cette instance | Secrétariat identifié | Pièces, calendrier, convocation, fonctionnement, éventuelle nouvelle consultation et trace de l’avis |
| Projet de décision ou de délibération | Mairie / conseil juridique | Autorité compétente, articulation entre avis et décision, formalités de mise en œuvre |

Les **règles nationales** sont à rechercher dans le Code général de la fonction publique et les textes réglementaires applicables aux CST. Le **circuit pratique local** doit ensuite être rapproché du règlement intérieur de l’instance.

Pour préciser ce dossier : **sur quel projet voulez-vous consulter le CST, auprès de quel CDG votre commune est-elle affiliée, et à quelle date souhaitez-vous mettre ce projet en œuvre ?**

**Niveau de confiance : abstention sur la procédure juridique.** Le risque principal est de saisir une instance inadaptée ou de décider avant une consultation requise.
