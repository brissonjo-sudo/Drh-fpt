# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je ne peux donc certifier les voies de recours ni fournir une clause de notification prête à envoyer.

**Faits connus :** agent territorial ; exclusion temporaire de fonctions de **5 jours** ; sanction prononcée en **2026**. Le statut de l’agent — titulaire, stagiaire ou contractuel — n’est pas précisé.

**Décision : non tranchable sans vérification.** Le corpus oriente vers la **suppression du conseil de discipline de recours pour les sanctions nouvelles**. Cette piste doit être confirmée officiellement avant de finaliser la notification. Il faut distinguer cette ancienne instance du **conseil de discipline préalable**, dont l’éventuelle consultation relève d’un autre contrôle.

Les voies à examiner pour la notification sont :

- **Le recours gracieux auprès de l’auteur de la sanction** : vérifier ses modalités et son effet sur le délai contentieux. Ne pas inventer un supérieur hiérarchique de l’autorité territoriale.
- **Le recours contentieux devant le tribunal administratif compétent** : vérifier le tribunal à désigner, les modalités de saisine et le délai applicable.
- **L’ancienne instance de recours** : vérifier sa suppression et le champ du régime transitoire. Le corpus rattache ce dernier à des sanctions anciennes ; une sanction prononcée en 2026 ne doit pas être assimilée silencieusement à ces dossiers.

**Pour sécuriser la notification, confiez au service juridique, avec la DRH, les contrôles suivants :**

1. Réunir le statut de l’agent, l’employeur exact, la décision, les dates d’ouverture de la procédure, de sanction et de notification.
2. Consulter sur Légifrance le Code général de la fonction publique, les textes de réforme et le décret relatif à la procédure disciplinaire territoriale, dans leurs versions applicables. Pour l’ancienne instance, confronter les dispositions de suppression et de transition à la structure consolidée actuelle.
3. Vérifier la compétence de l’auteur, l’instance préalable applicable, la proportionnalité et la motivation ; contrôler les garanties du dossier intégral, de l’assistance, du temps de préparation et du droit de se taire.
4. Valider les mentions de notification et de recours. Vérifier séparément la transmission au contrôle de légalité : liste légale actuelle, anciennes versions, convention locale et éventuelle demande préfectorale.

Le principal risque est de mentionner une instance supprimée ou des modalités de recours erronées. **Niveau de confiance : abstention sur la réponse juridique définitive et sur la rédaction exécutable.**
