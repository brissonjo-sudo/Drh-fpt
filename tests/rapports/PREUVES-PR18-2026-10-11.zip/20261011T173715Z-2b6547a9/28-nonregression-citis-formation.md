# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** fonctionnaire territorial ; accident de service contesté ; question portant sur la formation du conseil médical et la décision d’imputabilité.

Le corpus donne les **pistes suivantes à vérifier**, sans permettre de certifier juridiquement la réponse :

- **Formation plénière** : c’est la formation indiquée pour l’imputabilité au service, lorsqu’un avis du conseil médical est requis. La formation restreinte ne serait donc pas le circuit correspondant à cet objet.
- **Autorité territoriale** : elle est identifiée comme prenant la décision finale d’imputabilité. L’avis du conseil médical et la décision administrative sont à distinguer.
- **Saisine** : son caractère obligatoire dans votre dossier reste à contrôler ; la seule mention d’un accident « contesté » ne permet pas de le déterminer.

**État de décision : non tranchable sans la vérification requise.** Le service RH ou juridique doit contrôler les dispositions applicables du Code général de la fonction publique et des textes territoriaux relatifs aux accidents de service et au conseil médical, à la date pertinente.

À réunir : statut exact — titulaire ou stagiaire —, date et circonstances de l’accident, déclaration, certificat médical et motifs/pièces de contestation. Avant toute décision individuelle, faire également vérifier la compétence du signataire, la motivation requise, la notification et les voies et délais de recours, notamment en cas de refus.

**Niveau de confiance : abstention sur la conclusion juridique ; orientation documentaire fournie.**
