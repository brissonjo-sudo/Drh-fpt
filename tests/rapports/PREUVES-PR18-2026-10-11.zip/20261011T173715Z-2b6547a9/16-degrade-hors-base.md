# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre demande concerne des sapeurs-pompiers professionnels et porte sur le montant exact de l’indemnité de feu ainsi que son fondement juridique. La date de paie concernée n’est pas précisée.

**Décision : non tranchable avec le corpus fourni.** Celui-ci signale un régime indemnitaire spécifique aux sapeurs-pompiers professionnels, mais ne fournit ni le texte propre à l’indemnité de feu ni son barème. Je m’abstiens donc de donner un montant, un taux ou un numéro de décret non vérifiés.

Pour obtenir une réponse utilisable en paie, la **Direction des ressources humaines ou le service paie** doit réunir et contrôler :

- **Le fondement :** rechercher sur Légifrance le texte réglementaire propre à la rémunération des sapeurs-pompiers professionnels, puis l’article relatif à l’indemnité de feu, dans sa version applicable à la date concernée.
- **Le calcul :** vérifier les bénéficiaires, le taux ou barème, l’assiette exacte et les éventuelles règles de proratisation. Si l’assiette est indiciaire, contrôler l’indice retenu et la valeur du point à cette même date.
- **Les données individuelles :** cadre d’emplois, grade, échelon, quotité et situation administrative de chaque agent. Un montant unique pour tous ne peut pas être présumé.
- **Le cadre local :** réunir les actes ou paramètres de paie pertinents, sans les utiliser comme substitut au texte national.

**Niveau de confiance : abstention sur le montant et le fondement exacts.** Leur vérification doit précéder tout calcul ou paramétrage de paie.
