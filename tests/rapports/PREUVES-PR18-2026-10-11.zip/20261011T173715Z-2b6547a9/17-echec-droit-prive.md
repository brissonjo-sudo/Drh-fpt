# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre agent est titulaire et absent sans justificatif depuis plusieurs semaines. Les dates exactes et l’existence d’une mise en demeure ne sont pas précisées.

**Décision : non tranchable sans vérification.** Je ne peux pas valider l’utilisation de la présomption de démission. La piste documentaire du corpus distingue **la présomption de démission du droit privé** du **licenciement pour abandon de poste dans la fonction publique territoriale**. Cette distinction doit être confirmée avant toute décision.

Pour avancer, faites réunir par votre service RH :

- **Le cadre applicable :** employeur territorial, effectif, dates d’absence et éventuelle date d’effet envisagée.
- **Les pièces :** relevés d’absence, échanges avec l’agent, éventuels justificatifs matériels ou médicaux ; si une mise en demeure existe, son contenu et la preuve de sa notification.
- **Les faits après cette mise en demeure :** l’agent a-t-il repris à l’échéance indiquée ? A-t-il répondu, refusé la reprise ou expliqué son absence ? La durée d’absence seule ne permet pas de conclure dans ce dossier.

Le service RH ou juridique devra ensuite contrôler sur les sources officielles — Code général de la fonction publique et jurisprudence administrative — les conditions de l’abandon de poste, la régularité de la mise en demeure et le caractère approprié du délai de reprise. Il devra aussi **faire confirmer la distinction avec une sanction disciplinaire**, notamment l’absence de conseil de discipline et de communication du dossier *au titre disciplinaire* dans cette voie.

Avant une éventuelle décision, restent à vérifier : autorité compétente, motivation, date d’effet, notification, voies et délais de recours, et éventuelle transmission au contrôle de légalité. **Ne retenez aucune date d’effet automatiquement.**

**Recommandation :** préparez ce dossier de contrôle sans présumer une démission ni rédiger maintenant un acte de sortie. Le risque principal est une rupture des fonctions fondée sur une qualification ou des formalités incorrectes.

**Niveau de confiance : abstention sur la conclusion juridique.**
