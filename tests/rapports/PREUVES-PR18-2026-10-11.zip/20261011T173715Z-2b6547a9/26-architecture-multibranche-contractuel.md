# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le corpus permet de préparer l’analyse, mais pas de confirmer un droit à reprise d’ancienneté ou à avancement, ni de rédiger une décision exécutable.

**Faits connus**

L’agent est contractuel en contrat à durée indéterminée (CDI), rémunéré par référence à un indice. Il demande la reprise de toute son ancienneté et un avancement de grade comparable à celui d’un fonctionnaire titulaire. L’employeur, les clauses du contrat, l’historique des services et la date d’effet souhaitée ne sont pas précisés.

**État de décision : non tranchable en l’état.** Il faut examiner séparément ses deux demandes.

**Analyse à faire vérifier**

- **Référence à un indice et détention d’un grade.** Le corpus oriente vers une distinction essentielle : l’indice utilisé pour fixer une rémunération contractuelle ne doit pas être assimilé à l’attribution d’un grade. Il faut contrôler cette distinction dans les textes applicables et le contrat, avant de répondre sur l’avancement demandé.
- **Reprise d’ancienneté.** La demande doit préciser son objectif : repositionnement de rémunération, reconnaissance de l’expérience ou ouverture d’un droit particulier. Le corpus ne permet pas de reconnaître une reprise intégrale et automatique. Chaque période devra être examinée au regard du droit invoqué, des clauses contractuelles et du cadre local.
- **Évolution de rémunération.** La piste indiquée par le corpus est celle d’une réévaluation ou d’une revalorisation contractuelle, à distinguer de l’avancement statutaire du titulaire. Le champ, la périodicité applicable, les critères et les effets de cette réévaluation restent à vérifier. Son éventuelle obligation ne suffit pas à établir le droit à l’augmentation demandée.
- **Objectif de carrière statutaire.** Si l’agent souhaite accéder à une carrière de fonctionnaire, une étude distincte des voies d’accès au statut de titulaire est nécessaire, sans présumer son éligibilité.

**Pièces et variables à réunir**

Les éléments bloquants pour une réponse individuelle sont :

- le type d’employeur et son effectif, pour confirmer le périmètre territorial couvert par le corpus ;
- le contrat, ses avenants, son fondement de recrutement et les clauses relatives à la rémunération ou à son évolution ;
- les fonctions réellement exercées, la catégorie hiérarchique et le cadre d’emplois ou grade utilisé comme référence ;
- l’historique daté des services : employeurs, fonctions, catégories, quotités et interruptions ;
- les décisions de rémunération antérieures, les derniers entretiens professionnels et la date de la dernière réévaluation ;
- la délibération ou le cadre local de rémunération, ainsi que la date d’effet demandée.

Le montant actuel peut rester un champ à compléter pour ce premier cadrage ; il deviendra nécessaire si une proposition chiffrée est étudiée.

**Marche à suivre — dossier de préparation**

| Action | Responsable attendu | Contrôle et preuve |
|---|---|---|
| Clarifier les deux demandes et leur objectif | Agent et service ressources humaines | Demande écrite distinguant ancienneté, rémunération et grade |
| Reconstituer la situation contractuelle et les services | Service ressources humaines | Contrat, avenants et tableau des périodes documentées |
| Vérifier le régime applicable à la date utile | Référent juridique ou conseil compétent | Code général de la fonction publique et dispositions réglementaires propres aux contractuels territoriaux, avec versions et passages utiles |
| Préparer les options de réponse | Service ressources humaines, puis autorité dont la compétence sera vérifiée | Note séparant droits éventuellement établis, clauses contractuelles et marge de choix local |

Le contrôle juridique devra notamment rechercher les règles propres à la fixation et à la réévaluation de la rémunération des contractuels, puis examiner la portée des engagements locaux. **Ne pas transposer une mécanique d’avancement de titulaire sans en avoir établi le fondement applicable au contrat.**

Avant toute décision, faire vérifier la compétence de son auteur, les exigences de motivation — notamment pour un éventuel refus —, la notification et les voies et délais de recours. Toute modification contractuelle ou de paie devra ensuite être sécurisée selon les formalités effectivement applicables.

Les risques principaux sont une assimilation injustifiée au régime du titulaire, l’omission d’une clause contractuelle favorable ou une reconnaissance d’ancienneté sans fondement établi. Utiliser un dossier anonymisé pour les échanges de conseil.

**Niveau de confiance : abstention sur les droits individuels ; cadrage documentaire uniquement.**
