# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je peux préparer le contrôle de votre organisation, mais pas certifier les règles applicables ni valider votre cycle.

**Faits connus :** votre service fonctionne selon un cycle annualisé défini il y a plusieurs années. Vous souhaitez connaître les règles applicables aujourd’hui, au **11 octobre 2026**, et savoir si cette organisation peut être conservée.

**État de décision : non tranchable en l’état.** L’ancienneté du cycle ne permet, à elle seule, ni de le valider ni de conclure qu’il faut le remplacer.

Les contrôles à faire portent sur deux niveaux :

| Niveau | Points à vérifier |
|---|---|
| **Cadre national** | Durée annuelle de référence applicable ; décompte du travail effectif ; garanties de durée quotidienne et hebdomadaire, pauses et repos ; journée de solidarité ; congés annuels et fractionnement. |
| **Organisation locale** | Délibération en vigueur, consultation du comité social territorial (CST) ou de l’instance compétente lors de l’adoption, définition du cycle, périodes hautes et basses, décompte des heures et traitement des dépassements. |

Le corpus invite à examiner particulièrement **deux justifications différentes**, sans que je puisse en certifier ici les conséquences juridiques :

- **Un ancien régime plus favorable :** vérifier si votre organisation repose sur une dérogation historique et comment les évolutions nationales ont été prises en compte.
- **Des sujétions particulières actuelles :** si une réduction de durée est prévue pour le travail de nuit, du dimanche, en horaires décalés ou pour des tâches pénibles ou dangereuses, contrôler les textes applicables, la réalité de ces contraintes et leur justification dans la délibération.

Il faut aussi distinguer **le volume annuel de travail** de **sa répartition dans l’année**. Le contrôle peut conduire à revoir l’un sans nécessairement remettre en cause toute l’organisation.

Pour avancer, merci de préciser **le type d’employeur, l’effectif total, les statuts et quotités des agents concernés**, et de fournir la **délibération applicable avec son annexe décrivant le cycle**. Ces éléments déterminent le régime à examiner ; le corpus couvre les collectivités territoriales de plus de 350 agents.

Le dossier de préparation peut ensuite être organisé ainsi :

1. **Ressources humaines :** réunir délibération, modifications, avis de l’instance consultée et règles de décompte. La preuve attendue est le document adopté, pas seulement une pratique de service.
2. **Responsable du service :** rapprocher ce cadre des plannings réellement appliqués, des heures réalisées et des contraintes du service.
3. **Service juridique, avec le centre de gestion si pertinent :** vérifier sur Légifrance les dispositions du Code général de la fonction publique, les textes territoriaux sur le temps de travail et les congés, ainsi que les réformes relatives aux anciens régimes dérogatoires, dans leur version applicable aujourd’hui.
4. **RH et paie :** après cette vérification, contrôler la cohérence du logiciel de gestion des temps et identifier les adaptations éventuelles.

**Recommandation : préparer cette revue avant de décider du maintien ou de la modification du cycle.** Toute modification éventuelle devra également faire contrôler l’autorité compétente, les consultations et l’acte nécessaires.

**Risque principal :** conserver un décompte ou des horaires incompatibles avec le cadre actuel. **Niveau de confiance : abstention sur la conformité de votre organisation.**
