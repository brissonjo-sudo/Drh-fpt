# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** une commune a prononcé une exclusion temporaire de fonctions de **5 jours** contre un fonctionnaire communal. La date de la sanction n’est pas précisée.

**Décision : non tranchable sans vérification.** Je ne peux donc pas certifier une obligation de transmission au titre de l’article **L. 2131-2 du Code général des collectivités territoriales (CGCT), à confirmer en version consolidée**.

La piste documentaire indiquée par le corpus est de **distinguer la liste légale actuelle des anciennes versions qui visaient certaines sanctions soumises au conseil de discipline**. La durée de l’exclusion ou l’intervention d’une instance disciplinaire ne permettent pas, seules, de conclure à une transmission obligatoire.

Le service juridique ou le service chargé du contrôle de légalité doit vérifier :

- la **date de la sanction** et la version officielle de l’article applicable à cette date ;
- l’existence d’une **catégorie légale couvrant précisément cet acte** ;
- séparément, la convention locale de télétransmission et une éventuelle demande du préfet : ces éléments doivent être distingués de l’obligation légale invoquée.

**Niveau de confiance : abstention sur l’obligation de transmission.** Le corpus fournit une piste de contrôle, sans remplacer la consultation de la source officielle.
