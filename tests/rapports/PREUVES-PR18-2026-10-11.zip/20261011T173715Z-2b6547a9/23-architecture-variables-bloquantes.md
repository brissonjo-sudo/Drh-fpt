# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable.** Le nom et le cadre d’emplois ne permettent pas d’établir si une nomination au grade supérieur est possible cette année. Je m’abstiens donc de confirmer son éligibilité.

**Faits connus :** vous préparez un tableau d’avancement de grade ; vous disposez du nom de l’agent et de son cadre d’emplois. Son statut, son grade actuel et le grade visé ne sont pas précisés. Inutile de communiquer son nom pour cette analyse.

Pour constituer le dossier, réunissez en une fois :

- **Employeur :** type de collectivité et effectif, pour confirmer le périmètre du corpus — collectivités de plus de 350 agents.
- **Situation de l’agent :** titulaire, stagiaire ou contractuel ; grade actuel, grade visé, échelon, ancienneté et historique des services, avec les derniers arrêtés de carrière.
- **Calendrier et parcours :** date de nomination envisagée, éventuel examen professionnel obtenu et justificatif.
- **Pièces locales :** lignes directrices de gestion, délibération fixant le ratio promus-promouvables, éléments d’appréciation professionnelle et situation de l’emploi permettant la nomination.

**Contrôles à confier à la DRH avant toute proposition :**

| Point à vérifier | Source ou pièce à consulter |
|---|---|
| Régime applicable et conditions d’accès au grade visé, à la date envisagée | Code général de la fonction publique et décret statutaire du cadre d’emplois, en version applicable sur Légifrance |
| Grade cible dans le même cadre d’emplois : éviter une confusion avec la promotion interne | Décret statutaire |
| Tableau annuel, ratio local et critères de sélection | Textes officiels, délibération et lignes directrices de gestion |
| Rôles respectifs de l’autorité territoriale, de l’assemblée et de la commission administrative paritaire | Textes actuels : ne pas présumer une consultation préalable de cette commission |
| Distinction entre éligibilité, inscription au tableau et nomination effective | Textes applicables, emploi disponible et pièces locales |

**Recommandation :** préparer une fiche d’examen de candidature avec ces pièces, puis faire consigner par la DRH les conditions vérifiées et les éléments encore manquants. À ce stade, ne pas présenter la nomination comme acquise.

Avant une décision individuelle, faire également vérifier la compétence du signataire, la date d’effet, les exigences de motivation éventuelles, la notification, la publicité, la transmission et les voies de recours, y compris en cas de refus.

**Niveau de confiance : abstention sur l’éligibilité et la nomination.** Le risque principal serait de confondre une candidature envisageable avec une nomination juridiquement sécurisée.
