# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je peux préparer les contrôles, mais pas certifier les voies de recours ni fournir une notification prête à envoyer.

**Faits connus :** agent territorial ; exclusion temporaire de fonctions de **5 jours**, prononcée en **2026**. Son statut — titulaire, stagiaire ou contractuel — n’est pas précisé.

**Sur le conseil de discipline de recours :** le corpus donne comme piste documentaire la **suppression de cette ancienne instance pour les sanctions nouvelles**. Cette piste doit être confirmée sur les textes officiels applicables avant de répondre définitivement. Il faut distinguer :

- le **conseil de discipline préalable**, dont l’intervention dépend du statut et de la sanction ;
- l’ancien **conseil de discipline de recours**, dont la suppression et les dispositions transitoires doivent être contrôlées.

Le corpus rattache le régime transitoire à certaines sanctions anciennes : il ne fournit pas de fondement pour ouvrir cette voie à une sanction prononcée en 2026. Les conditions et délais d’un éventuel régime ancien restent toutefois à vérifier ; ils ne rouvrent pas automatiquement un recours aujourd’hui.

**Pour préparer la notification, faites vérifier par le service juridique :**

| Point | Contrôle nécessaire |
|---|---|
| Recours administratif | Recours gracieux auprès de l’auteur de la sanction, modalités et effet éventuel sur le délai contentieux. Ne pas inventer un supérieur hiérarchique de l’autorité territoriale. |
| Recours contentieux | Tribunal administratif compétent, modalités de saisine, délai applicable et point de départ lié à la notification. |
| Ancienne instance de recours | Confirmer sa suppression et l’absence de régime transitoire applicable avant de retenir les mentions finales. |
| Régularité de la sanction | Statut de l’agent, instance préalable, motivation, dossier intégral, assistance d’un conseil, temps suffisant pour la défense et information sur le droit de se taire. |
| Transmission | Vérifier séparément la liste légale actuelle, la convention locale et les éventuelles demandes préfectorales. |

**Pièces à réunir :** statut de l’agent, employeur exact, décision motivée, dates exactes d’ouverture de la procédure et de sanction, date de notification envisagée et pièces de la procédure.

**Sources à consulter :** Code général de la fonction publique, textes disciplinaires territoriaux et textes de suppression/transitoire, Code des relations entre le public et l’administration, Code de justice administrative et Code général des collectivités territoriales, dans leurs versions applicables.

**État de décision : non tranchable sans cette vérification.** Le principal risque est d’indiquer une voie obsolète ou des modalités erronées. Faites valider les mentions avant notification. **Niveau de confiance : abstention sur la conclusion juridique.**
