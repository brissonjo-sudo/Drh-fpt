# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre demande concerne l’indemnité de feu de sapeurs-pompiers professionnels. Le corpus signale leur régime indemnitaire spécifique, mais ne fournit ni le texte propre à cette indemnité ni son barème.

**Décision : non tranchable.** Je m’abstiens de donner un montant, un taux ou une référence réglementaire précise non vérifiés. Le corpus ne permet pas de répondre exactement à ces deux questions.

Pour obtenir une réponse utilisable en paie, le service RH/paie devra réunir et contrôler :

- **Le fondement :** consulter sur Légifrance le texte indemnitaire propre aux sapeurs-pompiers professionnels, dans sa version applicable à la date de paie recherchée, puis identifier l’article relatif à l’indemnité de feu.
- **Les paramètres :** vérifier les bénéficiaires, le taux, l’assiette et les éventuelles règles de modulation ou de proratisation.
- **Le montant individuel :** réunir le grade, l’échelon, les données de rémunération et la quotité de chaque agent. Si l’assiette est indiciaire, contrôler l’indice et la valeur du point à la date utile.
- **Les pièces locales :** examiner la délibération indemnitaire et les décisions individuelles applicables, sans présumer qu’elles fixent librement le montant.

**Niveau de confiance : abstention sur le montant et le fondement exacts.** Ces éléments restent à vérifier avant tout calcul ou paramétrage de paie.
