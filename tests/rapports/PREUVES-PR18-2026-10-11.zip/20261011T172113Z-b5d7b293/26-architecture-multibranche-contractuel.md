# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon `recherche-juridique` est indisponible : je fournis un cadrage et les contrôles à effectuer, sans certifier le résultat juridique.

**Faits connus**

L’agent est contractuel en contrat à durée indéterminée (CDI), rémunéré par référence à un indice. Il demande la reprise intégrale de son ancienneté et un avancement de grade selon les règles d’un fonctionnaire titulaire. L’employeur et la date d’effet souhaitée ne sont pas précisés.

**Décision : non tranchable en l’état.** Il faut examiner séparément ses deux demandes, sans transposer automatiquement le régime du titulaire.

Le corpus conduit à vérifier trois distinctions déterminantes :

- **Indice de rémunération et grade statutaire** : contrôler qu’une référence indiciaire sert à fixer la rémunération sans conférer un grade ni les droits de carrière correspondants. Le CDI et la titularisation doivent également être distingués.
- **Ancienneté et reprise de services** : identifier l’objet exact de la demande — reconnaissance des services pour fixer la rémunération, réévaluation ou application d’un mécanisme de classement statutaire. Ces objets ne doivent pas être confondus ; la reprise de toute l’ancienneté ne peut être tenue pour acquise.
- **Réévaluation et avancement** : vérifier le champ et la périodicité de la réévaluation applicable à ce CDI, ainsi que la portée des clauses contractuelles. Ne pas assimiler réexamen de la rémunération, augmentation automatique et avancement de grade.

**Marche à suivre : préparer l’examen de la demande**

| Action | Responsable et pièces | Résultat attendu |
|---|---|---|
| Compléter le dossier | Direction des ressources humaines (DRH) : contrat, avenants, fondement du recrutement, quotité de travail, fonctions et catégorie de référence ; historique des services, interruptions et précédentes réévaluations | Distinguer les services établis et les éléments manquants |
| Préciser la demande | Agent et DRH : ancienneté revendiquée, résultat salarial attendu, grade demandé et date d’effet souhaitée ; type d’employeur et effectif à préciser | Qualifier chaque demande sans supposer un régime |
| Vérifier le cadre applicable | DRH ou conseil juridique : Code général de la fonction publique et dispositions réglementaires applicables aux contractuels, dans leur version à la date utile ; contrat et cadre local de rémunération | Confirmer les droits éventuels, les marges de décision locales et l’autorité compétente |
| Préparer la réponse | DRH, après vérification : analyse distincte de l’ancienneté et du grade, comparaison avec les clauses et règles applicables | Réponse motivée sur chaque point et proposition éventuelle de réévaluation |

**Piste à examiner pour répondre à son objectif :** une réévaluation de rémunération tenant compte de son expérience et de ses fonctions, si le cadre vérifié le permet. Si l’agent recherche une carrière de fonctionnaire, examiner séparément les voies d’accès au statut de titulaire et leurs conditions, sans promettre une titularisation.

Avant toute décision ou modification de paie, contrôler les clauses, les compétences, les formalités nécessaires et, pour une réponse défavorable, la motivation et les recours applicables. Le risque principal est d’importer les règles du titulaire ou de promettre une reprise d’ancienneté sans fondement établi.

**Niveau de confiance : abstention sur les droits individuels ; cadrage documentaire uniquement.**
