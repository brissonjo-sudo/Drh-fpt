# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable.** Le nom et le cadre d’emplois ne permettent pas de déterminer si l’agent peut être nommé au grade supérieur en 2026. Je m’abstiens donc de conclure sur son éligibilité.

**Faits connus :** vous préparez un tableau d’avancement de grade et disposez uniquement de l’identité de l’agent et de son cadre d’emplois.

Pour avancer, réunissez les informations suivantes :

| Informations manquantes | Ce qu’elles permettront de contrôler |
|---|---|
| Statut : titulaire, stagiaire ou contractuel ; grade actuel et grade visé | Régime applicable et distinction entre avancement de grade et changement de cadre d’emplois |
| Échelon, ancienneté dans cet échelon et dans le grade, état des services | Conditions statutaires et date à laquelle elles pourraient être remplies |
| Situation de travail et éventuelles interruptions ou positions particulières | Services et ancienneté effectivement pris en compte |
| Examen professionnel éventuellement obtenu, avec sa date | Exigence éventuelle du statut particulier et voie d’accès correspondante |
| Date de nomination envisagée | Version des textes et conditions à contrôler à cette date |
| Type d’employeur, effectif et éventuel statut particulier | Champ d’application du corpus, limité aux collectivités de plus de 350 agents |

Ces données sont **bloquantes lorsqu’elles modifient le régime ou les conditions d’accès**. Les détails de présentation du tableau sont, eux, non bloquants. Inutile de communiquer ici le nom de l’agent : une fiche anonymisée suffit.

La **Direction des ressources humaines (DRH)** pourra ensuite préparer deux contrôles distincts, sans confondre éligibilité et nomination :

- **Socle national à vérifier :** Code général de la fonction publique et décret statutaire du cadre d’emplois, dans leur version applicable. Contrôler les grades, les conditions d’accès, leur date d’appréciation et les possibilités de nomination.
- **Cadre local à réunir :** tableau annuel envisagé, délibération fixant le ratio promus-promouvables, lignes directrices de gestion et situation de l’emploi correspondant. Faire vérifier leur incidence sur cette candidature, ainsi que les rôles respectifs de l’assemblée délibérante et de l’autorité territoriale.

Le contrôle doit aussi préciser le **rôle actuel de la commission administrative paritaire**, sans présumer qu’une consultation préalable sur l’avancement est requise, et distinguer ce rôle de celui du **comité social territorial** concernant les lignes directrices de gestion.

**Recommandation :** constituez d’abord cette fiche et rassemblez les pièces locales ; faites ensuite consigner par la DRH les sources applicables et le résultat de chaque contrôle avant toute nomination. Le risque principal serait de retenir une candidature sur la seule appartenance à un cadre d’emplois.

**Niveau de confiance : abstention sur l’éligibilité et la nomination**, faute de données déterminantes et de vérification officielle.
