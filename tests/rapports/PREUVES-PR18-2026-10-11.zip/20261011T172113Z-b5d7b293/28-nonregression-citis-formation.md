# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** fonctionnaire territorial, accident de service contesté, question portant sur l’imputabilité au service.

Le corpus fournit les **pistes suivantes à vérifier**, sans permettre de certifier juridiquement la réponse :

- **Formation du conseil médical :** contrôler la compétence de la **formation plénière** pour l’imputabilité au service, en la distinguant de la formation restreinte. C’est la piste indiquée par le corpus.
- **Décision finale :** contrôler la compétence de **l’autorité territoriale** — maire ou président selon l’employeur. Le corpus distingue son pouvoir de décision de l’avis rendu par le conseil médical.
- **Nécessité de la saisine :** vérifier si les circonstances et le motif de contestation imposent effectivement un avis ; ne pas déduire une saisine automatique du seul caractère contesté de l’accident.

**État de décision : non tranchable sans vérification officielle.** La piste documentaire est donc : **formation plénière pour l’avis sur l’imputabilité, puis décision de l’autorité territoriale**, sous réserve de confirmation.

Pour préparer le contrôle, réunir la date et les circonstances de l’accident, la déclaration, le certificat médical, les éléments de contestation et préciser si le fonctionnaire est titulaire ou stagiaire. Le régime des contractuels doit être examiné séparément.

La DRH ou le service juridique devra consulter le Code général de la fonction publique et les textes territoriaux applicables au congé pour invalidité temporaire imputable au service et au conseil médical, dans leur version pertinente, puis contrôler motivation, notification et recours avant toute décision.

**Niveau de confiance : abstention sur la conclusion juridique ; orientation documentaire uniquement.**
