# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** il s’agit d’un fonctionnaire communal et d’une exclusion temporaire de fonctions de 5 jours. La date de la sanction n’est pas précisée.

**Décision : non tranchable sans vérification.** Je ne peux donc pas certifier une obligation ou une absence d’obligation de transmission.

La piste documentaire indiquée par le corpus consiste à contrôler la **liste légale applicable à la date de la sanction**, dans l’article L. 2131-2 du Code général des collectivités territoriales (CGCT), **à confirmer en version consolidée**. Il faut rechercher si la nature exacte de cet acte relève d’une catégorie de transmission obligatoire, sans reprendre automatiquement une ancienne liste visant les sanctions soumises à l’avis du conseil de discipline.

Le service juridique ou la direction des ressources humaines doit réunir :

- la date et l’arrêté de sanction ;
- la version officielle de l’article applicable à cette date ;
- la convention locale de télétransmission et les éventuelles demandes du préfet.

Le contrôle doit distinguer **obligation légale**, transmission volontaire, pratique locale et demande préfectorale. Une pratique de télétransmission ne suffit pas à établir l’obligation au titre de cet article.

**Niveau de confiance : abstention sur la conclusion juridique.**
