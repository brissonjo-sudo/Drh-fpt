# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes DRH d’un CHU de 900 agents ; l’agent est titulaire et en arrêt maladie depuis huit mois.

Votre question concerne la **fonction publique hospitalière**, expressément exclue du corpus DRH territorial fourni. L’effectif de 900 agents ne change pas cette limite.

**Décision : non tranchable avec ce corpus.** Je ne peux donc pas préciser les conditions d’accès au congé de longue maladie, sa durée, sa rémunération ou sa procédure. Les huit mois d’arrêt indiqués ne permettent pas, à eux seuls, de déterminer le congé actuellement accordé ni les droits de l’agent.

Pour préparer une réponse hospitalière fiable, réunissez :

- **Les pièces administratives :** corps et grade, dates exactes des arrêts, décisions de congé et de renouvellement, historique des congés et éventuelle demande de longue maladie.
- **Les éléments médicaux nécessaires :** certificats et avis utiles, dans le respect du secret médical, sans diffuser le diagnostic dans le dossier administratif courant.
- **Les sources à vérifier :** dispositions du Code général de la fonction publique et textes propres aux fonctionnaires hospitaliers, dans leur version applicable aux périodes concernées.

Le **service RH chargé du statut hospitalier, avec son appui juridique**, devra contrôler la qualification du congé actuel, l’éligibilité au congé de longue maladie, les droits déjà consommés, la rémunération, ainsi que les instances et l’autorité compétentes. Les formalités de décision, de notification et de recours devront également être vérifiées.

**Point de vigilance :** ne pas appliquer les règles territoriales à ce dossier hospitalier ni modifier la paie sur cette seule analyse.

**Niveau de confiance : abstention sur le régime juridique demandé.**
