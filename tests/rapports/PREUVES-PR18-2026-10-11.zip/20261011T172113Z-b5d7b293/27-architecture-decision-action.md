# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je peux préparer le dossier et les contrôles, mais pas confirmer une procédure disciplinaire exécutable.

**Faits connus :** l’agent est titulaire ; les faits sont soupçonnés ; une exclusion temporaire de **5 jours** est envisagée. L’employeur, les faits précis et leurs dates ne sont pas indiqués.

**État de décision : non tranchable.** Je ne peux pas confirmer juridiquement que vous pouvez engager cette procédure. Il manque la vérification du régime applicable, des faits et des garanties à respecter. Cela ne signifie pas que cette voie est interdite.

**Ma recommandation : lancer la préparation du dossier, sans arrêter aujourd’hui le choix de la sanction.** L’exclusion envisagée doit rester une hypothèse à examiner.

Voici les actions à lancer **dans l’ordre**. Il s’agit d’un plan de préparation et de contrôle, pas de la procédure disciplinaire elle-même.

| Ordre | Action concrète et responsable | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : qualifier le dossier.** Confirmer le type d’employeur, son effectif, le cadre d’emplois et le grade de l’agent, l’affiliation au centre de gestion et l’existence d’un régime particulier. Réunir les dates des faits, de leur connaissance par l’administration et, si elles existent, d’ouverture de la procédure et de sanction envisagée. | Fiche de qualification et pièces statutaires. Ces données servent à déterminer le régime, le circuit d’instance et la version des textes à contrôler. |
| **2** | **DRH et encadrement : réunir les éléments déjà disponibles.** Rapports, documents, témoignages et éléments favorables comme défavorables à l’agent. Identifier d’éventuelles poursuites pénales. | Chronologie distinguant faits établis, allégations et points contestés ; origine de chaque pièce. Avant une audition destinée à recueillir les observations de l’agent, faire vérifier les garanties applicables, notamment le droit de se taire. |
| **3** | **Juriste RH ou conseil compétent : vérifier les sources officielles.** Consulter le Code général de la fonction publique, les textes disciplinaires territoriaux et, si nécessaire, le statut particulier, dans leur version applicable. | Note de vérification traçable : textes, versions et passages utiles. Contrôler notamment la prescription, son point de départ et l’incidence éventuelle des poursuites pénales. |
| **4** | **DRH et juriste : faire valider le circuit et les droits de la défense.** | Faire vérifier le classement de l’exclusion envisagée dans le deuxième groupe et l’exigence d’un conseil de discipline préalable, ainsi que son rattachement à la commission administrative paritaire. Contrôler l’information de l’agent, l’accès au dossier intégral, l’assistance d’un conseil de son choix et un temps suffisant pour préparer sa défense. |
| **5** | **Autorité compétente, avec la DRH : réexaminer les suites envisageables après ces contrôles.** | Examiner la matérialité des faits, leur qualification et la proportionnalité de la réponse. Faire vérifier qui détient le pouvoir de décision et la portée de l’avis éventuellement requis. Ne pas transformer l’hypothèse de départ en sanction automatique. |
| **6** | **DRH et juriste : contrôler tout projet de décision avant signature et mise en œuvre.** | Compétence du signataire, motivation en fait et en droit, garanties accomplies, date d’effet, notification traçable, conséquences administratives et de paie, publicité éventuelle et recours applicables. |

Deux vérifications doivent rester distinctes :

- **Recours :** vérifier la suppression de l’ancienne instance disciplinaire de recours, sans la confondre avec le conseil préalable. Contrôler les recours administratifs et contentieux actuels, leurs délais et tout régime transitoire éventuel.
- **Contrôle de légalité :** vérifier la liste légale applicable à la nature exacte de l’acte. Examiner séparément les anciennes versions, la convention locale de télétransmission et les demandes du préfet ; une pratique locale ne suffit pas à établir une obligation nationale.

Les risques à maîtriser sont une sanction prématurément choisie, des faits insuffisamment établis, une atteinte aux droits de la défense ou une mauvaise identification du circuit compétent. Limiter la circulation du dossier aux personnes nécessaires.

**Niveau de confiance : abstention sur la possibilité juridique d’engager la procédure et sur la sanction ; dossier préparatoire uniquement.**
