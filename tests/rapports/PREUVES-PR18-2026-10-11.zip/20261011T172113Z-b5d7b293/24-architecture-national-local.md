# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je peux préparer le contrôle de votre organisation, mais je m’abstiens de certifier une durée, un seuil ou une procédure.

**Faits connus :** votre service suit un cycle annualisé défini depuis plusieurs années. Vous souhaitez connaître les règles applicables aujourd’hui et savoir si ce cycle peut être conservé.

**Décision : non tranchable en l’état.** L’ancienneté du cycle ne suffit pas à établir sa conformité actuelle. Sa conservation doit être examinée en rapprochant les textes nationaux en vigueur, les actes locaux et les horaires réellement pratiqués.

Pour préciser le régime applicable, les informations **bloquantes** sont : le type d’employeur et son effectif, les catégories d’agents concernées, leurs quotités de travail, le contenu du cycle et la délibération qui l’a établi ou modifié. Un éventuel régime particulier doit aussi être identifié. Le logiciel de gestion des horaires est une information **non bloquante** pour ce premier cadrage.

Le contrôle à préparer porte sur trois ensembles :

| Point à examiner | Vérification nécessaire |
|---|---|
| **Socle national** | Durée annuelle de référence applicable ; portée des réformes sur les anciens régimes dérogatoires ; conditions permettant une réduction pour des sujétions particulières. Aucun volume horaire n’est confirmé ici. |
| **Garanties de travail et de repos** | Limites quotidiennes et hebdomadaires, moyenne sur la période de référence, repos et pauses. Contrôler ces garanties dans le planning réel, en plus du total annuel. |
| **Organisation locale** | Validité et contenu de la délibération, périodes hautes et basses, décompte des congés et absences, dépassements horaires et éventuelles sujétions. Vérifier les rôles respectifs de l’assemblée délibérante, de l’autorité territoriale et du comité social territorial (CST). |

**Ma recommandation : faire établir un diagnostic documenté avant d’arbitrer le maintien ou la modification du cycle.**

1. **Responsable du service :** réunir les plannings prévisionnels et réalisés, les quotités et les relevés d’heures.
2. **Direction des ressources humaines :** rassembler la délibération initiale, ses modifications, le règlement du temps de travail et les avis d’instance disponibles.
3. **Service juridique ou conseil compétent :** vérifier sur Légifrance les textes territoriaux de temps de travail, le Code général de la fonction publique et les règles de compétence pertinentes, dans leur version applicable **au 11 octobre 2026**. Restituer les écarts et les formalités éventuellement nécessaires.

Si ces contrôles établissent la conformité, le maintien pourra être envisagé. S’ils révèlent des écarts, les adaptations dépendront de leur nature. Les risques à examiner sont notamment un décompte annuel erroné, des repos insuffisants ou un acte local devenu inadapté.

**Niveau de confiance : abstention sur la conformité juridique du cycle actuel.**
