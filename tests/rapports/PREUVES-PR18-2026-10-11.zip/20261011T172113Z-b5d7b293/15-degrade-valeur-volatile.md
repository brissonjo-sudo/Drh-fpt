# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous demandez la valeur exacte du point d’indice aujourd’hui, **11 octobre 2026**, pour un arrêté. La date d’effet de cet arrêté n’est pas précisée.

**Décision : non tranchable.** Je m’abstiens de donner un chiffre : le corpus impose de vérifier cette valeur avant son utilisation dans un acte. Un montant non vérifié, même accompagné d’une réserve, ne convient pas.

Pour obtenir la valeur utilisable, le **service RH/paie** doit :

- consulter sur **Légifrance** le texte fixant la valeur du point, dans sa version applicable à la date d’effet de l’arrêté ;
- contrôler l’unité retenue : valeur annuelle ou mensuelle, pour éviter une erreur de conversion ;
- conserver la source et sa date d’application. Pour calculer le traitement, contrôler aussi l’**indice majoré** de l’agent et sa quotité.

**Point à préciser :** quelle est la date d’effet de l’arrêté ?

**Niveau de confiance : abstention sur la valeur exacte.**
