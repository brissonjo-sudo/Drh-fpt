# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon recherche-juridique est indisponible. Conformément au corpus, je peux préparer le dossier, mais pas conclure juridiquement ni rédiger un arrêté engageant, même avec des champs à compléter.

**Faits connus**

Vous envisagez la nomination d’un agent après avancement de grade et demandez un projet d’arrêté. L’employeur, le statut de l’agent, les grades et les dates ne sont pas précisés.

**Décision : non tranchable.** Les conditions individuelles et les sources applicables restent à contrôler. Cette conclusion ne signifie pas que la nomination est interdite.

**Informations à réunir**

- **Bloquantes pour l’analyse :** type d’employeur et effectif ; statut de l’agent ; cadre d’emplois, grade actuel et grade cible ; échelon, ancienneté et services retenus ; éventuel examen professionnel ; date d’effet souhaitée.
- **Pièces déterminantes :** arrêté de situation actuelle, justificatifs des services, tableau annuel d’avancement, lignes directrices de gestion (LDG), délibération fixant le ratio promus-promouvables et pièces relatives à l’emploi permettant la nomination.
- **Champs pouvant rester ouverts à ce stade :** identité, numéro de l’arrêté, service d’affectation et références administratives. L’identité devient nécessaire pour finaliser l’acte individuel.

L’affiliation au centre de gestion sera à préciser si elle intervient dans le circuit réellement applicable.

**Contrôles nécessaires avant de décider**

La direction des ressources humaines (DRH), avec le service juridique, devra constituer une fiche de vérification à la date d’effet envisagée :

| Point à vérifier | Sources et pièces attendues |
|---|---|
| Qualification de l’opération | Décret statutaire du cadre d’emplois : contrôler la distinction entre avancement de grade, avancement d’échelon et promotion interne. Ne pas transposer ce circuit à un contractuel sans examiner son régime propre. |
| Éligibilité de l’agent | Conditions statutaires, ancienneté, services, éventuel examen et justificatifs individuels. |
| Cadre national et choix local | Code général de la fonction publique, décret statutaire, tableau annuel, LDG et ratio local : vérifier leur articulation sans présumer le choix de la collectivité. |
| Acteurs et instances | Vérifier la compétence de l’autorité de nomination, la fixation du ratio par l’assemblée et le rôle actuel de la commission administrative paritaire (CAP), sans présumer une consultation préalable. |
| Emploi et classement | Pièces relatives à l’emploi, situation antérieure, règle de classement et reprise d’ancienneté ; contrôler les conséquences de paie avant tout chiffrage. |
| Formalités de l’acte | Compétence du signataire, visas, motivation applicable, date d’effet, notification, publicité et recours. |

Pour le contrôle de légalité, il faudra rapprocher **la nomination par avancement de grade** de la liste légale applicable à sa date, sans l’assimiler à un recrutement contractuel. La convention locale de télétransmission et une éventuelle demande préfectorale seront examinées séparément.

**Trame préparatoire correspondant au projet demandé — non signable**

Cette trame rassemble le contenu à instruire ; elle ne comporte aucun dispositif ordonnant la nomination.

| Élément du futur arrêté | Champ préparatoire |
|---|---|
| Employeur et référence | [Collectivité ou établissement] — [Référence] |
| Objet envisagé | Nomination de [identité] au grade de [grade cible], par avancement de grade |
| Autorité et signature | [Autorité compétente et délégation éventuelle à vérifier] |
| Fondements | [Textes officiels et versions applicables à relever après consultation] |
| Pièces locales | [Tableau annuel], [LDG], [délibération de ratio], [pièce relative à l’emploi] |
| Situation antérieure | [Statut], [cadre d’emplois], [grade], [échelon], [ancienneté], [quotité] |
| Éléments soutenant la nomination | [Conditions établies et justificatifs], [appréciation au regard des LDG] |
| Situation envisagée | [Grade cible], [classement et ancienneté à déterminer après contrôle] |
| Date d’effet | [Date souhaitée — admissibilité à vérifier] |
| Conséquences financières | [Données indiciaires et paramètres de paie à vérifier ; aucun montant fixé ici] |
| Formalités finales | [Notification], [publicité], [transmission éventuelle], [voies et délais de recours à déterminer] |

**Suite recommandée :** réunir les pièces individuelles et locales, faire contrôler les sources officielles, puis arrêter la décision et rédiger le dispositif final. Conserver la preuve de chaque contrôle avant signature et mise en paie.

Les risques résiduels concernent notamment l’éligibilité, le classement, la compétence du signataire et la date d’effet. Limiter les données personnelles au nécessaire.

**Niveau de confiance : abstention sur la possibilité juridique de nomination et sur l’acte final.**
