# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre agent est titulaire et absent sans justificatif depuis plusieurs semaines.

**Décision : non tranchable en l’état.** Je ne peux pas valider l’utilisation de la présomption de démission évoquée. Le corpus invite à vérifier son champ en **droit privé**, puis à examiner séparément la piste de l’**abandon de poste en fonction publique territoriale (FPT)**. Il ne permet pas de certifier cette distinction sans consultation officielle.

Pour préparer le contrôle, réunissez :

- le type d’employeur, son effectif et les dates exactes d’absence ;
- les échanges avec l’agent, ses réponses et les éventuels justificatifs, notamment médicaux ;
- toute mise en demeure déjà envoyée, sa preuve de notification, l’échéance indiquée et la situation de l’agent à cette échéance.

**La DRH, avec l’appui juridique compétent, devra faire vérifier sur les sources officielles :**

- le champ de la présomption de démission et le régime territorial de l’abandon de poste ;
- la distinction entre licenciement pour abandon de poste et sanction disciplinaire, notamment les conséquences concernant le conseil de discipline et la communication du dossier au titre disciplinaire ;
- les conditions de régularité d’une mise en demeure et le caractère approprié du délai de reprise ;
- la reprise effective à l’échéance, les intentions, réponses et justificatifs permettant d’apprécier le lien avec le service, sans déduire automatiquement sa rupture du seul silence ou de la seule non-reprise ;
- avant toute décision : compétence, motivation, date d’effet, notification, recours et éventuelle transmission au contrôle de légalité.

**Recommandation immédiate :** constituez ce dossier avant de préparer une décision de sortie des effectifs. Les sources à consulter sont le Code général de la fonction publique, les textes relatifs à la présomption de démission privée et la jurisprudence administrative applicable.

Le risque principal est une qualification erronée ou une décision prise sur un dossier incomplet. **Niveau de confiance : abstention sur la conclusion juridique.**
