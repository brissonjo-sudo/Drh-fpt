# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes maire d’une commune d’environ 40 agents et souhaitez consulter un comité social territorial (CST). Le projet concerné et sa date de mise en œuvre ne sont pas précisés.

Le corpus fourni couvre les collectivités de plus de 350 agents : **votre commune est hors de son périmètre**. Je ne peux donc pas vous donner une procédure détaillée applicable ni certifier un seuil.

**Décision : non tranchable en l’état.** Le premier contrôle porte sur le rattachement de votre commune : CST propre ou CST placé auprès du centre de gestion (CDG). L’expression « mon CST » ne suffit pas à établir l’instance compétente.

Voici le **dossier de préparation** que votre service RH ou votre secrétaire général de mairie peut constituer avant de demander confirmation au CDG :

| Point à faire vérifier | Pièce ou information à réunir |
|---|---|
| Instance compétente et seuil de rattachement | Effectif exact, affiliation au CDG, documents de rattachement |
| Nécessité de la consultation et moment où elle intervient | Objet précis du projet, projet de décision ou de délibération |
| Modalités de saisine | Règlement de l’instance, formulaire éventuel, calendrier et pièces demandées |
| Garanties et suite de la consultation | Contrôles sur l’information des représentants, l’avis, sa traçabilité et l’autorité chargée de décider |
| Formalités de l’acte final | Notification ou publicité, transmission et recours à vérifier selon sa nature |

**Sources à consulter pour ces contrôles :** Code général de la fonction publique, textes réglementaires relatifs aux CST territoriaux, Code général des collectivités territoriales et documents du CDG compétent. Il faudra distinguer les exigences nationales des modalités locales.

La prochaine action utile est de faire confirmer **le rattachement et le circuit correspondant à votre projet**, avant de programmer la consultation. Une erreur d’instance ou de calendrier pourrait fragiliser la décision finale.

**Quel projet souhaitez-vous soumettre au CST, et savez-vous si votre commune est affiliée au CDG ?**

**Niveau de confiance : abstention sur la procédure juridique applicable.**
