# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Vous pouvez conserver un cycle annualisé, mais son ancienneté ne prouve pas sa conformité actuelle.** Il faut contrôler la délibération qui le fonde, les horaires réellement pratiqués et le régime des agents concernés.

**Décision : non tranchable en l’état pour votre organisation précise.** L’annualisation reste possible ; sa conservation dépend des contrôles ci-dessous.

L’analyse porte sur le droit applicable au **11 octobre 2026**, à partir des extraits officiels et des traces de consultation fournis dans le corpus.

**Les règles à appliquer aujourd’hui**

Pour les agents territoriaux relevant du régime général :

| Point à contrôler | Règle nationale |
|---|---|
| Durée de référence à temps complet | **35 heures par semaine**, avec un décompte annuel de **1 607 heures**, sans préjudice des heures supplémentaires |
| Annualisation | Le cycle peut aller du cycle hebdomadaire au **cycle annuel** |
| Travail quotidien | **10 heures maximum** |
| Amplitude de la journée | **12 heures maximum**, pauses comprises |
| Travail hebdomadaire | **48 heures maximum**, heures supplémentaires comprises ; **44 heures en moyenne** sur toute période de 12 semaines consécutives |
| Repos | **11 heures minimum** par jour ; **35 heures minimum** par semaine, comprenant en principe le dimanche |
| Pause | Au moins **20 minutes** avant que le travail quotidien n’atteigne 6 heures |

Ces règles proviennent du décret relatif au temps de travail de l’État, rendu applicable à la FPT sous les adaptations du décret territorial : articles [1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142), [3](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150) et [4](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560147) du décret n° 2000-815 du 25 août 2000, versions depuis le 01/01/2023 ; [article 1 du décret n° 2001-623 du 12 juillet 2001](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version depuis le 14/07/2001. **Consultations du 11/10/2026 attestées dans le corpus.**

L’équilibre annuel ne permet donc pas de compenser une semaine excessive ou un repos insuffisant par une période moins travaillée. Les dérogations aux garanties minimales sont encadrées par l’article 3 précité ; un besoin habituel du service ne suffit pas, à lui seul, à les justifier.

**Ce qui relève de votre collectivité**

L’organe délibérant détermine les conditions de mise en place des cycles **après avis du CST**. Une réduction de la durée annuelle peut tenir compte de sujétions réelles : nuit, dimanche, horaires décalés, travail en équipes, modulation importante du cycle, travaux pénibles ou dangereux. Elle doit être fondée sur ces sujétions et décidée après avis du CST.

Sources : articles [2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477) et [4](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472) du décret territorial précité, versions depuis le 01/01/2023 ; consultations du 11/10/2026 fournies.

**Pour décider de conserver votre cycle**

1. **La DRH récupère** la délibération applicable, ses modifications, l’avis de l’instance consultée à l’époque et le règlement du temps de travail.
2. **Le responsable du service et la DRH comparent** ces documents aux plannings réels : total annuel, pics hebdomadaires, repos, pauses et heures supplémentaires. Une pause compte comme travail effectif si l’agent reste à disposition de l’employeur sans pouvoir vaquer librement à ses occupations personnelles ([article 2 du décret n° 2000-815](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version depuis le 29/06/2006, consultation fournie du 11/10/2026).
3. **Si des écarts apparaissent**, la collectivité prépare les adaptations nécessaires et, pour modifier les conditions des cycles, suit le circuit CST puis délibération.

**Pouvez-vous préciser la population concernée — agents territoriaux de droit commun ou régime particulier — et reproduire les dispositions de votre délibération sur le cycle et la durée annuelle ?** Ces éléments permettront de trancher sans présumer votre règle locale.

**Confiance : stable pour les règles nationales citées ; abstention sur la conformité de votre cycle actuel.** Les risques à contrôler sont principalement un décompte annuel incorrect, des repos insuffisants et un écart entre la délibération et les pratiques.
