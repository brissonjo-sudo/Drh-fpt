# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Le corpus confirme qu’une nomination par avancement de grade est possible, mais ne permet pas de vérifier l’éligibilité de cet agent ni les conditions propres à son cadre d’emplois. Le projet ci-dessous constitue une **trame à compléter et à contrôler avant signature**.

Pour finaliser : **quel est l’employeur, l’agent est-il titulaire, quels sont ses grades actuel et visé, et quelle date d’effet souhaitez-vous ?** Ces éléments déterminent le régime applicable et les textes statutaires à vérifier.

Les autres pièces déterminantes peuvent rester identifiées comme champs à compléter : tableau annuel d’avancement et rang de l’agent, LDG applicables, délibération fixant le taux de promotion lorsqu’il s’applique, emploi d’affectation et acceptation de cet emploi.

**Ce que les sources fournies permettent d’établir au 11 octobre 2026**

- L’avancement repose sur les modalités prévues pour le grade : choix, examen professionnel ou concours professionnel. Pour la voie du choix, l’autorité apprécie la valeur professionnelle et l’expérience en tenant compte des LDG.  
  Source : [CGFP — modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), version depuis le 01/03/2022, trace de consultation fournie du 11/10/2026 — fonction : conditions d’avancement.
- L’autorité territoriale prononce l’avancement parmi les agents inscrits au tableau, **dans l’ordre du tableau**. L’inscription seule ne permet donc pas de considérer la nomination comme acquise.  
  Source : [CGFP — nomination et ordre du tableau](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), même version et date de consultation — fonction : compétence et sélection.
- Le plafond de promotions dépend du taux fixé par l’assemblée après avis du CST, **avec l’exception expressément prévue pour le cadre d’emplois des agents de police municipale**. Le taux local n’est pas fourni.  
  Source : [CGFP — taux de promotion](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), même version et date — fonction : plafond et choix local.
- L’avancement est subordonné à l’acceptation de l’emploi assigné dans le nouveau grade.  
  Source : [CGFP — acceptation de l’emploi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496), même version et date — fonction : condition de nomination.

**Restent à vérifier** dans le statut particulier applicable : conditions personnelles d’accès, éventuel examen, règles de classement et emploi permettant la nomination. Aucun échelon, indice ou montant ne peut être fixé avec ce dossier.

La DRH doit réunir ces pièces, contrôler l’éligibilité, le rang et le nombre de promotions possibles, puis faire valider le classement avant de soumettre l’arrêté à l’autorité compétente.

**Projet d’arrêté — document préparatoire, non prêt à signer**

**[Collectivité / établissement]**  
**Arrêté n° [référence] portant nomination de [identité] au grade de [grade d’avancement]**

[Qualité de l’autorité territoriale],

Vu le code général de la fonction publique, notamment ses dispositions applicables à l’avancement de grade des fonctionnaires territoriaux [références exactes à relever avant signature] ;

Vu [texte statutaire du cadre d’emplois, version applicable et dispositions relatives à l’avancement et au classement à vérifier] ;

Vu les lignes directrices de gestion applicables [référence et date] ;

[Si applicable : Vu la délibération fixant le taux de promotion, référence et date, après avis du CST du …] ;

Vu le tableau annuel d’avancement au grade de [grade], établi pour l’année [année], sur lequel [identité] figure au rang [rang] ;

Vu [acte et pièce établissant l’existence et la disponibilité de l’emploi correspondant] ;

Vu [pièce établissant l’acceptation par l’agent de l’emploi assigné] ;

Considérant que [identité], titulaire du grade de [grade actuel], remplit les conditions statutaires suivantes : [conditions et pièces justificatives contrôlées] ;

Considérant que cette nomination respecte l’ordre du tableau et [le plafond de promotions applicable / les dispositions spécifiques vérifiées] ;

**Arrête :**

**Article 1 — Nomination**  
À compter du [date d’effet validée], [identité] est nommé(e), par avancement de grade, au grade de [grade], relevant du cadre d’emplois de [cadre d’emplois].

**Article 2 — Classement**  
L’agent est classé au [échelon], avec une ancienneté conservée de [durée], conformément à [disposition statutaire vérifiée].  
[Indices à renseigner après contrôle de la grille applicable.]

**Article 3 — Affectation**  
L’agent est affecté à l’emploi de [intitulé], au sein de [service], qu’il ou elle a accepté.

**Article 4 — Exécution et notification**  
[Responsables compétents] sont chargés de l’exécution du présent arrêté. Celui-ci est notifié à l’intéressé(e).  
[Formalités de publicité et de transmission à déterminer après vérification du régime de l’employeur.]

**Article 5 — Recours**  
Le présent arrêté peut être contesté devant le tribunal administratif de [juridiction territorialement compétente à vérifier], dans un délai de deux mois à compter de sa notification.

Fait à [lieu], le [date].  
[Qualité, nom et signature de l’autorité compétente]

**Contrôles avant signature :** compétence et délégation éventuelle, conditions statutaires, tableau et rang, plafond applicable, emploi accepté, classement, date d’effet, notification et formalités de publicité/transmission.

La clause de recours repose sur les extraits fournis des [règles de délai contentieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005) et de leur [opposabilité lors de la notification](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), versions respectivement depuis le 01/01/2020 et le 01/01/2001, consultations tracées le 11/10/2026. La juridiction reste à déterminer.

**Confiance : abstention sur la nomination individuelle et le classement ; socle général étayé par les consultations officielles fournies.** Les risques résiduels sont une nomination sans éligibilité établie, hors ordre ou plafond, et un classement erroné. Limiter les données personnelles du projet aux informations nécessaires à l’acte.
