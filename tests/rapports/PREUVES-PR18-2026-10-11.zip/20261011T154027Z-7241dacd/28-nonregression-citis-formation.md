# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**La formation plénière**, lorsque la consultation du conseil médical est requise pour l’imputabilité d’un accident de service. **La décision finale appartient à l’autorité territoriale** : le conseil médical rend un avis.

La saisine n’est toutefois **pas automatique du seul fait que l’accident est contesté**. Le texte prévoit la consultation lorsqu’une faute personnelle ou une circonstance particulière est potentiellement de nature à détacher l’accident du service.

Les extraits officiels fournis permettent de confirmer ces trois points :

- **Déclencheur de la consultation** : [décret du 30 juillet 1987, disposition sur la saisine](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859).
- **Formation compétente : plénière** : [disposition sur ses compétences](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783).
- **Décision de l’autorité territoriale au terme de l’instruction** : [disposition sur la décision d’imputabilité](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843).

**Pour votre dossier :** identifiez précisément le motif de contestation ; s’il correspond au déclencheur ci-dessus, saisissez la formation plénière, puis soumettez le dossier et son avis à l’autorité territoriale pour décision.

**État : possible sous conditions** pour la saisine ; son caractère requis dépend du motif de contestation. **Confiance : stable** sur la formation compétente et l’auteur de la décision, d’après les versions applicables au 11 octobre 2026 et les traces de consultation fournies.
