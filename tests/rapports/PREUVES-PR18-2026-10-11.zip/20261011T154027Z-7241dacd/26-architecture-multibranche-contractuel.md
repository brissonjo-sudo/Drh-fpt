# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne donne pas au contractuel les droits de carrière d’un fonctionnaire titulaire.** Son expérience peut justifier un réexamen de sa rémunération, mais elle ne crée pas un droit automatique à la reprise intégrale de son ancienneté ou à un avancement de grade.

L’analyse porte sur un **CDI de droit public territorial**, au **11 octobre 2026**, à partir des extraits officiels fournis.

**Ce qu’il peut demander**

- **Une prise en compte de son expérience dans sa rémunération.** Le CGFP prévoit que celle-ci tient compte des fonctions, de la qualification requise et de l’expérience. J’en déduis que l’agent peut demander un examen argumenté de son parcours ; ce texte n’impose pas la conversion de chaque année d’ancienneté en échelon ou en points d’indice.  
  Source : [CGFP — fixation de la rémunération des contractuels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), version depuis le 1er mars 2022, consultation fournie du 11 octobre 2026.

- **Une réévaluation de sa rémunération au moins tous les trois ans.** Cette obligation concerne les CDI, notamment au regard des entretiens professionnels ou de l’évolution des fonctions. **Réévaluer ne signifie pas augmenter automatiquement** : le texte impose le réexamen, sans garantir un montant d’augmentation.  
  Source : [décret relatif aux contractuels territoriaux — rémunération](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), version depuis le 1er juillet 2026, consultation fournie du 11 octobre 2026.

**Ce qu’il ne peut pas obtenir par assimilation au titulaire**

L’indice constitue une référence de rémunération ; il ne confère ni grade ni carrière statutaire. **L’avancement de grade comme un titulaire est donc impossible en l’état de sa qualité de contractuel.** Une évolution de fonctions ou de rémunération reste à examiner selon son régime contractuel.

**Point à clarifier : occupe-t-il un emploi fonctionnel de direction relevant du recrutement direct ?** L’extrait sur la rémunération prévoit pour ces emplois un classement spécifique en échelons tenant compte de l’expérience. Les textes auxquels il renvoie ne sont pas fournis : ce classement particulier est **non tranchable** avec ce dossier et ne doit pas être confondu avec un avancement de grade.

**Marche à suivre**

1. **DRH : réunir les pièces** — CDI et avenants, fondement du recrutement, clause indiciaire, fiche de poste, justificatifs d’expérience, comptes rendus d’entretien et date de la dernière réévaluation. Le statut éventuel d’emploi fonctionnel est à contrôler en premier.
2. **Responsable hiérarchique : documenter l’évolution professionnelle** — responsabilités, compétences, résultats et changements de fonctions. Pour un CDI sur emploi permanent, l’entretien professionnel est annuel.  
   Source : [décret — entretien professionnel](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), version depuis le 1er janvier 2023, consultation fournie du 11 octobre 2026.
3. **DRH : proposer un arbitrage motivé** sur la rémunération, en distinguant les critères nationaux des clauses contractuelles et paramètres locaux. Si le réexamen triennal manque, le réaliser ; aucune hausse ni rétroactivité ne peut être chiffrée avec les éléments disponibles.
4. **Autorité territoriale : décider**, puis faire formaliser l’évolution éventuelle après contrôle des clauses applicables. La paie intervient sur la base de cette décision formalisée.

**Décision :** réexamen de rémunération **possible** ; hausse **possible sous conditions** ; reprise intégrale automatique non établie ; avancement de grade comme titulaire **impossible en l’état**.

**Confiance : stable sur l’obligation de réévaluation documentée ; à vérifier sur les clauses individuelles et le régime éventuel d’emploi fonctionnel.** Le principal risque est de transformer une référence indiciaire en carrière statutaire ou de promettre une augmentation automatique.
