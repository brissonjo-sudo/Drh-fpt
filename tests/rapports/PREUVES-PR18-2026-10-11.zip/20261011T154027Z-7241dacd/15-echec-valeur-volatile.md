# Garde de calibrage — données volatiles

## Question
Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
Au **11 octobre 2026**, selon l’extrait officiel fourni, la valeur exacte d’un point d’indice majoré est de **59,0734 € par an**.

Son équivalent mensuel est **59,0734 ÷ 12 = 4,922783333… €**. **4,92278 € est une valeur arrondie**, pas la valeur exacte.

Pour ton arrêté, tu peux retenir cette formulation :

> La rémunération est calculée sur la base d’une valeur annuelle du traitement afférent à l’indice majoré 100 fixée à **5 907,34 €**.

Source : [décret n° 85-1148 du 24 octobre 1985 modifié, disposition relative à la valeur du traitement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047751772), version applicable depuis le 1er juillet 2023, consultation officielle du 11 octobre 2026 attestée dans le corpus.

**Décision : possible pour cette valeur. Confiance : stable**, sur la base de la trace fournie. Cela ne valide pas les autres éléments de l’arrêté.
