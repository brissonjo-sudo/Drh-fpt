# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Je recommande de préparer l’engagement de la procédure, sans arrêter dès maintenant une exclusion de 5 jours.** Le soupçon doit être étayé, l’agent doit pouvoir se défendre et la sanction éventuelle doit être proportionnée aux faits établis.

**État de décision : non tranchable en l’état pour ce dossier.** Le corpus permet de confirmer le régime d’une exclusion de 5 jours, mais plusieurs informations manquent pour autoriser concrètement l’engagement.

Pouvez-vous préciser ces trois points ?

- **Employeur** : quelle collectivité ou quel établissement, quel effectif et quelle affiliation au centre de gestion ?
- **Faits** : quels faits précis sont reprochés et sur quelles pièces repose le soupçon ?
- **Dates** : quand les faits ont-ils eu lieu, quand l’administration en a-t-elle connu la réalité, la nature et l’ampleur, et existe-t-il des poursuites pénales ou une procédure disciplinaire antérieure ?

Ces éléments déterminent le régime applicable, le circuit du conseil de discipline et la possibilité d’agir au regard de la prescription.

### Ce que les sources fournies permettent d’affirmer

Pour un **fonctionnaire titulaire relevant du régime territorial considéré**, une exclusion temporaire de **5 jours appartient au deuxième groupe**. Elle ne peut donc pas être prononcée sans **consultation préalable du conseil de discipline**. L’avis du conseil et la décision de sanction doivent être motivés.

Sources : [CGFP, art. L. 533-1 — échelle des sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) et [CGFP — consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), versions applicables au 11 octobre 2026, selon les traces de consultation fournies.

L’engagement doit aussi être examiné au regard de la **prescription de trois ans**, dont le point de départ est la connaissance effective par l’administration de la réalité, de la nature et de l’ampleur des faits. Les poursuites pénales et une éventuelle procédure antérieure doivent être prises en compte.

Source : [CGFP, art. L. 532-2 — prescription disciplinaire](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430), version applicable au 11 octobre 2026, trace fournie.

**J’en déduis que** l’engagement d’une procédure et le prononcé d’une exclusion sont deux décisions distinctes : envisager 5 jours ne permet ni de tenir les faits pour établis ni de prédéterminer la sanction.

### Actions à lancer, dans l’ordre

Le tableau suivant constitue un **plan de préparation et de contrôle**. La mise en œuvre disciplinaire reste conditionnée aux réponses ci-dessus et aux vérifications manquantes.

| Ordre | Action et responsable | Contrôle attendu |
|---|---|---|
| **1** | **DRH : qualifier le dossier** — employeur, statut, cadre d’emplois, dates, affiliation CDG et autorité appelée à décider. | Pièces statutaires ; compétence du signataire et délégation éventuelle à vérifier. |
| **2** | **DRH et service concerné : réunir les éléments factuels** — chronologie, rapports, documents et témoignages déjà disponibles. | Distinguer faits établis, allégations et éléments contradictoires. Identifier les pièces manquantes, sans présumer la culpabilité. |
| **3** | **DRH/juriste : contrôler la prescription.** | Documenter la date de connaissance effective ; examiner les poursuites pénales et procédures antérieures. Ne pas calculer le délai à partir de la seule date des faits. |
| **4** | **Autorité compétente : décider s’il existe une base suffisante pour engager.** | Si les éléments sont insuffisants, compléter le dossier. S’ils sont suffisamment étayés et que l’action reste ouverte, envisager l’engagement sans fixer définitivement la sanction. |
| **5** | **Avant toute audition disciplinaire : compléter le contrôle juridique des garanties.** | Le corpus ne fournit pas les dispositions permettant de vérifier précisément l’information sur le **droit de se taire**. Ce point doit être résolu avant le recueil des observations ; vérifier aussi les règles procédurales applicables à la date d’engagement. |
| **6** | **Après validation : informer l’agent par écrit** des faits reprochés, de la procédure et de ses droits. **DRH : organiser l’accès au dossier.** | Communication intégrale du dossier et des annexes, pièces numérotées, assistance de défenseurs choisis et délai suffisant pour préparer la défense. Conserver les preuves d’information et d’accès. |
| **7** | **Si une sanction du deuxième groupe reste envisagée : organiser la saisine du conseil de discipline** avec le secrétariat compétent. | Vérifier le circuit lié à la CAP/CDG et la composition du conseil. La convocation relève de son président ; l’autorité disciplinaire ne peut y siéger. Les autres modalités de saisine doivent être complétées à partir des textes applicables. |
| **8** | **Après la défense et l’avis : réexaminer le dossier et décider.** | Apprécier les faits effectivement établis, les explications de l’agent et la proportionnalité. Motiver en droit et en fait toute sanction retenue. |
| **9** | **Avant notification et exécution : contrôler l’acte et ses conséquences.** | Vérifier compétence, date d’effet, voies et délais de recours, notification traçable et traitement en paie. Ces modalités ne sont pas entièrement documentées dans le corpus. |

Les garanties de défense des étapes 6 et 7 reposent sur les extraits officiels fournis du [CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000052323864) et du décret relatif à la procédure disciplinaire territoriale : [information et accès au dossier](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836), [présidence et secrétariat du conseil](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222). La motivation écrite en droit et en fait est également prévue par le [CRPA](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513).

**Contrôle de légalité :** pour une commune, ne pas prévoir une transmission obligatoire au préfet au seul motif qu’il s’agit d’une sanction. La liste fournie de [l’article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) ne comporte pas de catégorie générale des sanctions disciplinaires. Vérifier séparément la nature de l’acte, les modalités locales et une éventuelle demande de communication du préfet.

**Risques prioritaires :** prescription, faits insuffisamment établis, atteinte aux droits de la défense, défaut de consultation et sanction disproportionnée. Limiter la circulation du dossier aux personnes qui doivent le traiter.

**Confiance : stable sur le classement des 5 jours et la consultation préalable, établis par les traces fournies ; abstention sur l’engagement concret tant que les faits, dates et contrôles manquants ne sont pas levés.**
