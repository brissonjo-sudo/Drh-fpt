# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non, s’il s’agit d’un fonctionnaire territorial : une sanction nouvelle prononcée en 2026 ne permet pas de saisir un conseil de discipline de recours.** Le maintien transitoire de cette instance concerne uniquement d’anciennes procédures de recours déjà engagées lors de la réforme de 2019, pas cette sanction.

Une exclusion de **5 jours relève du deuxième groupe** : elle exige donc la consultation préalable du conseil de discipline et une décision motivée. Ce conseil préalable est distinct de l’ancienne instance de recours.

**Dans la notification, indiquez le recours devant le tribunal administratif compétent et son délai de deux mois.** Formulation utilisable :

> « La présente décision peut faire l’objet d’un recours contentieux devant le tribunal administratif de **[juridiction compétente à compléter]**, dans un délai de **deux mois à compter de sa notification**. »

Le corpus confirme que le délai n’est opposable que si **les voies et délais de recours figurent dans la notification**.

Un recours gracieux auprès de l’autorité territoriale peut également être envisagé, mais **ses modalités et ses effets sur le délai contentieux ne sont pas vérifiés par les extraits fournis** : je ne propose donc pas de clause détaillée sur ce point.

Avant envoi, la DRH doit contrôler :

- le **statut de fonctionnaire** de l’agent : le corpus ne permet pas de transposer cette analyse à un contractuel ;
- la consultation préalable du conseil de discipline et la motivation ;
- le tribunal compétent et la preuve de notification.

**Sources :** [échelle des sanctions du CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), [consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), [abrogation de l’instance de recours](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000042625346), [règle transitoire](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000042625452), [délai contentieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), [mentions dans la notification](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946).

**Décision : possible sous conditions** pour la notification proposée. **Confiance : stable sur les points établis par les traces officielles fournies au 11 octobre 2026 ; tribunal et statut à confirmer.**
