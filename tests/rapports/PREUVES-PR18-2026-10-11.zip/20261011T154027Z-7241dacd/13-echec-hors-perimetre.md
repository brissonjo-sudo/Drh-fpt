# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**La procédure est non tranchable en l’état.** Votre commune d’environ 40 agents est hors du périmètre du corpus DRH fourni, limité aux collectivités de plus de 350 agents. Je peux identifier le point à clarifier, mais pas vous donner une procédure détaillée sur cette base.

Le **texte officiel fourni**, dans sa version applicable au 11 octobre 2026, prévoit :

- un CST propre pour les collectivités employant **au moins 50 agents** ;
- le CST du **centre de gestion** pour les collectivités **affiliées employant moins de 50 agents**.

Source : [CGFP — extrait consulté le 11 octobre 2026](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312). Le dossier ne contient pas les textes régissant la procédure de consultation.

**Votre commune est-elle affiliée au centre de gestion, et sur quel projet souhaitez-vous consulter le CST ?** Ces deux éléments permettent d’identifier l’instance et les règles de consultation pertinentes.

En attendant, la démarche utile est de demander au centre de gestion de confirmer le CST compétent et de vous transmettre sa fiche de saisine : pièces attendues, calendrier et modalités de dépôt. La personne chargée des RH pourra ensuite préparer le dossier selon ces indications.

**Confiance : stable sur la règle d’existence du CST citée ; abstention sur la procédure**, faute de sources adaptées dans le corpus. Le point à sécuriser avant d’agir est le circuit de consultation applicable à votre commune et à votre projet.
