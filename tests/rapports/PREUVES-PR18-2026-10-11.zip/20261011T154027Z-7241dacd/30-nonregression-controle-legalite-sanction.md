# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non.** Une exclusion temporaire de fonctions de **5 jours** prononcée contre un fonctionnaire communal **n’est pas soumise à transmission obligatoire au titre de l’article L. 2131-2 du CGCT**.

Dans la version officielle fournie, cet article ne comporte aucune catégorie générale visant les sanctions disciplinaires. Son **5°**, relatif à certaines décisions individuelles concernant les agents, ne couvre pas cette exclusion.

**À distinguer :** le préfet peut demander communication d’un acte non soumis à transmission obligatoire, sur le fondement de l’article **L. 2131-3 du CGCT**. Une telle demande doit donc être traitée séparément.

**Conséquence pratique :** ne pas inscrire cette sanction parmi les actes obligatoirement transmissibles sur le fondement de L. 2131-2 ; vérifier séparément l’existence d’une demande préfectorale.

Sources : [L. 2131-2 CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) et [L. 2131-3 CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), versions en vigueur depuis le **1er juillet 2022**, traces de consultation fournies du **11 octobre 2026**.

**Confiance : stable**, pour cette question précise, sur la base des extraits officiels fournis.
