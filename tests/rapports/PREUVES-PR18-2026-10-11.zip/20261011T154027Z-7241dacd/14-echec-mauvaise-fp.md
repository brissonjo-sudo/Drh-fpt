# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Votre CHU relève de la fonction publique hospitalière (FPH), et non de la fonction publique territoriale (FPT).** L’effectif de 900 agents ne change pas ce périmètre : le corpus fourni exclut expressément la FPH.

**État de décision : non tranchable avec ce corpus.** Je ne peux donc pas déterminer le régime de congé de longue maladie applicable, sa durée, sa rémunération ou sa procédure. Les huit mois d’arrêt ne suffisent pas, à eux seuls, à établir la nature du congé.

Pour instruire le dossier, votre gestionnaire statutaire devra réunir :

- les décisions de congé déjà prises et leurs dates : congé de maladie ordinaire ou CLM déjà accordé ;
- le statut et le corps de l’agent ;
- l’historique des congés pertinent et les pièces médicales nécessaires, dans le circuit confidentiel approprié.

Il faudra ensuite vérifier les dispositions du **CGFP et les textes propres aux fonctionnaires hospitaliers**, dans leur version applicable aux périodes concernées, avant de déterminer les droits et les démarches.

**Niveau de confiance : abstention sur le régime de CLM**, faute de base documentaire hospitalière et de consultation officielle autorisée dans cette évaluation.
