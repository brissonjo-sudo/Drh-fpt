# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Le taux prévu est de 25 % du traitement soumis à retenue pour pension. Le montant exact en euros est non tranchable avec les données fournies**, car le traitement servant de base n’est pas indiqué pour vos agents.

Le fondement est le **décret n° 90-850 du 25 septembre 1990 portant dispositions communes à l’ensemble des sapeurs-pompiers professionnels**, dans la [disposition officielle fournie au dossier](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025). La trace de consultation du 11 octobre 2026 confirme une version applicable à cette date, en vigueur depuis le 26 juillet 2020 :

> « Les sapeurs-pompiers professionnels peuvent percevoir […] une indemnité de feu d’un taux de 25 % du traitement soumis à retenue pour pension. »

Le texte vise donc **le traitement soumis à retenue pour pension**, et non la rémunération totale comprenant les autres primes.

**Pour obtenir le montant exact**, le service paie doit identifier cette base pour chaque agent et pour le mois concerné, puis lui appliquer le taux de 25 %. Le texte renvoie également aux conditions de l’article 17 de la loi qu’il mentionne : ce renvoi n’est pas documenté dans les extraits fournis. Les conditions de versement et les actes applicables à votre SDIS restent donc à contrôler avant validation en paie.

**Quel mois souhaitez-vous calculer, et quel est le traitement soumis à retenue pour pension de chaque agent concerné ?** Des données anonymisées suffisent.

**Confiance :** taux et fondement confirmés par la trace officielle fournie ; abstention sur le montant individuel et les conditions de versement non documentées.
