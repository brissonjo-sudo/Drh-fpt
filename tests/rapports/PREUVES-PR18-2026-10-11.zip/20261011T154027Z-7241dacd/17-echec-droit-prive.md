# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non : la présomption de démission ne s’applique pas à votre agent fonctionnaire titulaire.** Elle concerne les salariés de droit privé, y compris ceux employés par une personne publique dans les conditions du droit privé. Les extraits du Code du travail fournis établissent cette limite de champ : [champ d’application](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006900781) et [présomption de démission](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104), versions applicables au 11 octobre 2026 selon les traces du corpus.

Pour votre agent, la voie à examiner est **l’abandon de poste**, prévu par le [CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184). Plusieurs semaines d’absence sans justificatif ne permettent pas, à elles seules, de conclure à une démission ou de prononcer immédiatement une radiation.

La décision **CE, Section, 11 décembre 1998, nos 147511 et 147512, publiée au Lebon**, impose préalablement une mise en demeure :

- **écrite et notifiée** à l’agent ;
- lui demandant de reprendre son service dans un délai fixé par l’administration ;
- l’avertissant expressément du risque de **radiation des cadres sans procédure disciplinaire préalable**.

Dans cette affaire, l’absence du dernier avertissement a entraîné l’annulation de la radiation. [Décision officielle fournie au corpus](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335).

**Décision : impossible d’utiliser cette présomption pour votre titulaire ; radiation pour abandon de poste non tranchable en l’état.**

La DRH doit d’abord documenter les absences, les démarches de contact et les éventuelles justifications, puis sécuriser la mise en demeure et sa preuve de notification. À son échéance, elle devra examiner la reprise du service ou les explications reçues avant de proposer une décision.

**Confiance :** conclusion sur l’inapplicabilité étayée par les sources fournies. La décision individuelle reste à vérifier : le corpus ne permet pas de fixer un délai adapté ni de contrôler l’ensemble des conditions actuelles d’une radiation.
