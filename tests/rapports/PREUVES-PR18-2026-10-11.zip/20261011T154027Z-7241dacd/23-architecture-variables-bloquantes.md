# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable en l’état : le nom et le cadre d’emplois ne suffisent pas pour déterminer si cet agent peut être nommé au grade supérieur en 2026.** Vous pouvez poursuivre la préparation du dossier, sans retenir encore sa nomination.

**Pouvez-vous préciser ces trois blocs, sans transmettre son nom ?**

- **Situation de l’agent** : titulaire, stagiaire ou contractuel ; cadre d’emplois exact, grade actuel et grade visé.
- **Conditions individuelles** : échelon, ancienneté dans le grade et services accomplis ; examen professionnel obtenu, le cas échéant ; date de nomination envisagée.
- **Pièces locales disponibles** : lignes directrices de gestion (LDG), délibération fixant le taux de promotion lorsqu’il s’applique, éléments d’appréciation professionnelle et situation de l’emploi permettant la nomination.

Il faut distinguer **remplir les conditions statutaires**, **être inscrit au tableau** et **être effectivement nommé**. Les extraits officiels fournis établissent que :

- l’avancement peut notamment intervenir au choix ou après examen professionnel ; au choix, l’appréciation professionnelle et les LDG interviennent — [CGFP, modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506) ;
- le taux local fixe un **maximum de promotions**, avec une exception indiquée pour le cadre d’emplois des agents de police municipale — [CGFP, taux de promotion](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500) ;
- la nomination est prononcée parmi les agents inscrits, **dans l’ordre du tableau** — [CGFP, nomination](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498).

Ces trois extraits disposent de traces de consultation au **11 octobre 2026**, pour des versions applicables à cette date.

**Suite recommandée :** la DRH rassemble les éléments ci-dessus, vérifie le statut particulier du cadre d’emplois à la date envisagée, puis confronte le dossier aux LDG, au plafond local applicable et aux possibilités de nomination.

**Limite et confiance : abstention sur l’éligibilité individuelle.** Le décret statutaire et les pièces locales manquent au corpus ; aucune ancienneté minimale ni possibilité de nomination ne peut donc être confirmée ici.
