# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je ne peux donc certifier les voies de recours ni fournir une clause de notification prête à envoyer.

**Faits connus :** agent territorial ; exclusion temporaire de fonctions de **5 jours**, prononcée en **2026**. Son statut exact reste à préciser : titulaire, stagiaire ou contractuel.

**État de décision : non tranchable sans la vérification requise.** Le corpus donne toutefois une piste claire à contrôler : la **suppression du conseil de discipline de recours pour les sanctions nouvelles**, avec un régime transitoire concernant des sanctions anciennes. Il faut distinguer cette ancienne instance de recours du **conseil de discipline consulté avant la sanction**. La sanction décrite comme prononcée en 2026 ne doit pas être assimilée automatiquement à un dossier ancien.

Pour préparer la notification, faites valider par le service juridique les points suivants :

| Voie à examiner | Mentions à vérifier avant rédaction |
|---|---|
| **Recours gracieux auprès de l’auteur de la sanction** | Destinataire, modalités et effet éventuel sur le délai du recours contentieux. Ne pas inventer un supérieur hiérarchique de l’autorité territoriale. |
| **Recours contentieux devant le tribunal administratif** | Tribunal compétent, délai applicable, point de départ lié à la notification et modalités de saisine. |
| **Ancien conseil de discipline de recours** | Suppression et portée du régime transitoire ; ne pas le présenter comme une voie ouverte sans validation. |

**Contrôle à organiser :** réunir le statut de l’agent, la décision et les dates exactes d’ouverture de la procédure, de sanction et de notification prévue. Le service juridique devra confronter les dispositions applicables du **Code général de la fonction publique**, le texte réglementaire de discipline propre au statut de l’agent et les textes de suppression et de transition. Il devra aussi vérifier les règles du **Code de justice administrative** et du **Code des relations entre le public et l’administration** concernant les recours.

La clause pourra ensuite être finalisée avec les voies effectivement ouvertes. Le risque à éviter est d’orienter l’agent vers une instance supprimée ou de lui indiquer un délai erroné.

**Niveau de confiance : abstention sur les voies juridiquement applicables et leurs délais.**
