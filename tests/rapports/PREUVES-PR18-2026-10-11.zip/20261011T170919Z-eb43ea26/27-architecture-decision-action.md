# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je m’appuie uniquement sur le corpus fourni. Je ne peux donc confirmer juridiquement l’ouverture de la procédure ni fournir une procédure disciplinaire prête à exécuter.

**Faits connus**

- L’agent est **titulaire**.
- Les faits sont **soupçonnés**, sans éléments de preuve précisés.
- Une **exclusion temporaire de 5 jours** est envisagée.
- L’employeur, les dates des faits et leur date de connaissance ne sont pas indiqués.

**Décision : non tranchable en l’état.**

Il faut distinguer deux questions : les éléments disponibles permettent-ils d’engager une procédure disciplinaire ? Et, après examen des faits et de la défense, justifient-ils la sanction envisagée ? La durée annoncée ne permet pas, à elle seule, de répondre à ces questions.

**Ma recommandation : lancer la préparation du dossier et son contrôle juridique, sans arrêter dès maintenant le choix de l’exclusion.** La décision d’engager sera à prendre après validation du fondement, de la compétence et des garanties applicables. La sanction éventuelle devra ensuite faire l’objet d’un examen distinct.

Les informations bloquantes à réunir sont : type d’employeur et effectif ; faits précis, dates et pièces disponibles ; date de connaissance effective par l’administration ; éventuelles poursuites pénales ; date d’ouverture envisagée et existence d’actes déjà accomplis. Le cadre d’emplois et tout statut particulier doivent aussi être identifiés. L’affiliation au centre de gestion sera utile pour contrôler le circuit de l’instance.

Voici les **actions de préparation à lancer dans l’ordre**. Elles organisent les contrôles ; elles ne valent pas validation de la procédure.

| Ordre | Action et responsable proposé | Pièces et contrôles attendus |
|---|---|---|
| **1** | **DRH et responsable du service : établir une chronologie factuelle.** | Décrire chaque fait, sa date, les sources et la date de connaissance par l’administration. Séparer faits documentés, témoignages et suppositions. Repérer les éléments contradictoires et les éventuelles poursuites pénales. **Preuve :** chronologie et inventaire des pièces. |
| **2** | **DRH et juriste : vérifier le régime applicable.** | Confirmer l’employeur territorial, le statut de titulaire et les éventuelles particularités. Consulter le Code général de la fonction publique et les textes disciplinaires territoriaux dans leur version applicable. Contrôler prescription, compétence du signataire et éventuel régime transitoire. **Preuve :** note de vérification avec sources, versions et passages utiles. |
| **3** | **Juriste : contrôler spécialement la sanction envisagée et l’instance préalable.** | Vérifier le classement de l’exclusion de 5 jours dans l’échelle territoriale et l’éventuelle consultation préalable du conseil de discipline. Identifier le secrétariat compétent et le circuit applicable. **Preuve :** contrôle écrit du classement et de la consultation requise. |
| **4** | **DRH et juriste : préparer les garanties de défense avant tout lancement formel.** | Faire vérifier l’information de l’agent, l’accès au **dossier intégral**, l’assistance d’un **conseil de son choix**, le temps suffisant pour préparer sa défense et l’information sur le **droit de se taire** avant le recueil des observations. **Preuve :** dossier inventorié et supports contrôlés, avec modalités de traçabilité. |
| **5** | **Décideur dont la compétence aura été vérifiée : arbitrer l’engagement.** | Examiner la note juridique et les éléments factuels. Si les contrôles permettent l’engagement, faire valider le calendrier et le circuit complet avant mise en œuvre. Sinon, compléter le dossier ou réexaminer l’orientation. **Preuve :** arbitrage documenté, sans sanction prédéterminée. |
| **6** | **Après instruction : préparer un nouvel arbitrage et contrôler l’acte éventuel.** | Examiner les observations de l’agent, les éléments établis, l’avis préalable s’il est requis et la proportionnalité de la réponse. Contrôler motivation en fait et en droit, compétence, date d’effet, conséquences administratives et financières, notification et recours. **Preuve :** dossier final et validation avant signature. |

Deux contrôles demandent une attention particulière :

- **Recours :** vérifier les voies actuelles et leurs délais. Distinguer le conseil de discipline préalable de l’ancienne instance de recours dont le corpus signale la suppression ; ne pas reprendre une ancienne notification.
- **Transmission :** vérifier la liste légale applicable à la nature exacte de l’acte. Examiner séparément les anciennes versions, la convention locale de télétransmission et les éventuelles demandes du préfet. Une pratique locale ne suffit pas à établir une obligation nationale.

Le principal risque est de transformer des soupçons en décision déjà acquise, ou de lancer un circuit incomplet. Limiter l’accès au dossier aux personnes utiles au traitement et éviter toute diffusion nominative superflue.

**Niveau de confiance : abstention sur la possibilité juridique d’engager et sur la sanction.** Le dossier de préparation ci-dessus permet d’organiser les vérifications nécessaires pour trancher.
