# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Faits connus : vous demandez la valeur du point d’indice au **11 octobre 2026**, pour un arrêté.

**Décision : non tranchable.** Je m’abstiens de fournir un chiffre non vérifié destiné à un acte. Le corpus impose cette abstention pour la valeur du point d’indice ; une mention « à vérifier » après le chiffre ne suffirait pas.

Pour obtenir la valeur utilisable, le service paie ou la DRH devra :

- consulter sur **Légifrance** le texte réglementaire fixant la rémunération indiciaire, dans sa version applicable à la date d’effet de l’arrêté ;
- contrôler l’unité retenue : valeur annuelle ou mensuelle du point ;
- conserver la référence officielle, la version applicable et le passage établissant la valeur.

Si la date d’effet diffère d’aujourd’hui, c’est cette date qu’il faudra contrôler avant de chiffrer l’arrêté.

**Niveau de confiance : abstention sur la valeur exacte.**
