# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes DRH d’un centre hospitalier universitaire (CHU) de 900 agents ; l’agent est titulaire et en arrêt maladie depuis huit mois.

Votre dossier concerne la **fonction publique hospitalière**, alors que le corpus fourni couvre uniquement la **fonction publique territoriale**. L’effectif de 900 agents ne change pas cette limite : je ne peux pas transposer le régime territorial au personnel hospitalier.

**Décision : non tranchable avec ce corpus.** Je m’abstiens donc d’indiquer les conditions d’accès, la durée, la rémunération ou la procédure du congé de longue maladie hospitalier. Les huit mois d’arrêt ne permettent pas, à eux seuls, de déterminer le congé actuellement accordé ni les droits restants.

Pour préparer une réponse fiable, le service RH hospitalier, avec son appui juridique, doit réunir :

- **Les pièces :** décisions de congé déjà prises, dates exactes des arrêts, historique des congés antérieurs et éventuelle demande de longue maladie.
- **Les éléments médicaux utiles :** existence d’un avis ou d’une instruction médicale, en limitant la circulation des données de santé.
- **Les sources à contrôler :** Code général de la fonction publique et textes propres aux congés de maladie des fonctionnaires hospitaliers, dans leur version applicable aux dates concernées.

Ce contrôle devra établir l’éligibilité, les droits à congé et à rémunération, ainsi que les autorités et instances compétentes, avant toute décision ou modification de paie.

**Niveau de confiance : abstention sur le régime juridique demandé.**
