# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** fonctionnaire communal ; exclusion temporaire de fonctions de 5 jours ; question portant sur sa transmission obligatoire au contrôle de légalité. La date de la sanction n’est pas précisée.

**Décision : non tranchable sans vérification.** Je ne peux donc pas certifier un « oui » ou un « non ».

La piste donnée par le corpus est de **vérifier si la liste applicable prévoit encore la transmission des sanctions disciplinaires** : il signale une différence entre la liste actuelle et d’anciennes versions visant les sanctions soumises à l’avis du conseil de discipline. Ce signalement reste à vérifier officiellement. Le contrôle de l’instance disciplinaire préalable doit être distingué de celui de la transmission au préfet.

Pour trancher, le service juridique devra réunir :

- **La date de la sanction et l’arrêté**, puis consulter sur Légifrance l’article **L. 2131-2 du Code général des collectivités territoriales (CGCT), à confirmer en version consolidée applicable à cette date**.
- **La catégorie légale exacte** qui imposerait éventuellement la transmission, sans reprendre automatiquement une ancienne liste.
- **La convention locale de télétransmission et les éventuelles demandes préfectorales**, en distinguant obligation légale, transmission volontaire et pratique locale.

Le risque principal est d’appliquer une liste ancienne ou de confondre consultation disciplinaire et contrôle de légalité.

**Niveau de confiance : abstention sur l’obligation de transmission.**
