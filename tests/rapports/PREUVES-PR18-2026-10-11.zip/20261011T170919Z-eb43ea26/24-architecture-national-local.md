# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon `recherche-juridique` est indisponible. Je peux préparer le contrôle de votre organisation, mais pas certifier les règles applicables ni valider votre cycle.

**Faits connus :** votre service suit un cycle annualisé défini il y a plusieurs années. L’analyse porte sur son maintien au **11 octobre 2026**. Le type d’employeur, l’effectif, les statuts des agents et les documents locaux ne sont pas précisés.

**Décision : non tranchable en l’état.** L’ancienneté du cycle ne suffit pas à établir sa conformité actuelle. Il faut contrôler séparément les règles nationales applicables et les choix locaux qui organisent votre service.

Les points à faire vérifier sont les suivants :

| Contrôle | Ce qu’il faut examiner |
|---|---|
| **Durée annuelle** | Référence nationale actuelle, modalités de décompte et éventuelles réductions liées à des sujétions réelles et documentées : nuit, dimanche, pénibilité, notamment. |
| **Régimes historiques** | Effet des réformes sur les avantages antérieurs et éventuelle mise en conformité de votre délibération. Un ancien usage ne permet pas, à lui seul, de valider leur maintien. |
| **Garanties de travail et de repos** | Durées quotidiennes et hebdomadaires, moyenne sur la période de référence, amplitude, pauses et repos ; éventuelles dérogations et leurs conditions. Un total annuel ne suffit pas à contrôler ces garanties. |
| **Organisation locale** | Délibération en vigueur, période d’annualisation, semaines hautes et basses, plannings, congés, réduction du temps de travail (RTT), journée de solidarité et traitement des absences. |
| **Agents concernés** | Statut, filière, emploi à temps complet ou non complet, temps partiel : vérifier les conséquences propres à chaque situation. |
| **Acteurs et outils** | Compétences respectives de l’assemblée délibérante, de l’autorité territoriale et du comité social territorial (CST), consultation requise et concordance du logiciel de gestion des temps avec les règles validées. |

**Pour avancer, réunissez en une fois :**

- le type de collectivité ou d’établissement, son effectif et les populations concernées ;
- la délibération initiale et ses modifications, le règlement du temps de travail et les avis du CST ou de l’ancienne instance ;
- le cycle détaillé, un planning annuel représentatif, le décompte des heures et les justificatifs des éventuelles sujétions.

La **direction des ressources humaines**, avec le responsable du service, peut constituer ce dossier. Le service juridique ou le centre de gestion compétent devra ensuite consulter les versions applicables des textes officiels sur Légifrance : Code général de la fonction publique, textes relatifs au temps de travail territorial et aux garanties minimales, réformes des régimes antérieurs et règles propres aux agents concernés.

Deux scénarios sont à instruire : **maintien**, si les contrôles confirment la conformité du cycle et de son fondement local ; **adaptation**, si des écarts sont constatés, avec vérification du circuit de consultation et d’adoption nécessaire.

Le risque principal est de conserver un décompte annuel apparemment correct tout en méconnaissant les repos ou le cadre local applicable. **Niveau de confiance : abstention sur la conformité et les valeurs réglementaires ; dossier de préparation uniquement.**
