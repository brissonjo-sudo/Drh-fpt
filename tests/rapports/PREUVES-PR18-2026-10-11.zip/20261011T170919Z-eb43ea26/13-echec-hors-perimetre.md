# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes maire d’une commune d’environ 40 agents et souhaitez consulter le comité social territorial (CST). Votre commune est **hors du périmètre du corpus DRH fourni**, réservé aux collectivités de plus de 350 agents. Je ne peux donc pas vous fournir une procédure juridique détaillée applicable.

**Décision : non tranchable en l’état.** Il faut d’abord vérifier quel CST est compétent et préciser l’objet de la consultation. L’expression « mon CST » ne suffit pas à établir son rattachement.

Voici le **dossier de préparation** à confier à votre secrétariat de mairie ou à votre gestionnaire RH :

| Point à faire vérifier | Pièces et sources à réunir |
|---|---|
| **Quel CST saisir ?** Vérifier le rattachement au CST placé auprès du centre de gestion (CDG), ou l’existence d’un CST propre ou commun. Contrôler le seuil applicable et son mode de décompte, sans les certifier ici. | Documents de rattachement, confirmation du CDG, dispositions officielles applicables du Code général de la fonction publique. |
| **Le projet nécessite-t-il une consultation, et à quel moment ?** Identifier l’objet exact, le caractère éventuellement obligatoire et préalable de l’avis, ainsi que l’autorité qui prendra ensuite la décision. | Projet de décision ou de délibération, note explicative, textes applicables à cet objet et à la date envisagée. |
| **Quelles formalités respecter ?** Faire contrôler la saisine, les pièces, les délais, les règles de séance et les suites de l’avis, notamment en cas d’avis défavorable. | Règlement intérieur du CST compétent, calendrier et consignes de son secrétariat, textes réglementaires en version applicable. |

**Première action recommandée :** demander au CDG de confirmer votre rattachement et d’identifier le secrétariat compétent. Cette confirmation permettra de préparer le dossier ; elle ne remplace pas la vérification des règles applicables.

**Quel projet souhaitez-vous soumettre au CST, et à quelle date envisagez-vous de le décider ?**

Le risque principal est de saisir la mauvaise instance ou de décider avant une consultation requise. **Niveau de confiance : abstention sur la procédure juridique**, faute de vérification officielle et compte tenu du périmètre du corpus.
