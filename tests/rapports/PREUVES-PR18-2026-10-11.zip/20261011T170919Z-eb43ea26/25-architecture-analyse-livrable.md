# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** Le corpus permet de préparer le dossier, mais pas de confirmer la possibilité de nomination ni de rédiger un arrêté juridiquement engageant. Les champs à compléter permettent de préparer la rédaction ; ils ne remplacent pas la vérification juridique requise.

**Faits connus**

La demande porte sur une nomination après avancement de grade. L’employeur, le statut de l’agent, les grades concernés et la date d’effet ne sont pas renseignés. Aucun tableau d’avancement, document local ou justificatif individuel n’est fourni.

**Analyse préparatoire**

La nomination pourrait être envisagée **si les contrôles ci-dessous aboutissent favorablement**. Aucun de leurs résultats n’est certifié ici.

- **Régime applicable :** identifier l’employeur, son effectif, l’éventuel statut particulier, le statut de l’agent et sa quotité de travail. Vérifier que l’opération relève bien de l’avancement de grade, et non d’une promotion interne ou d’un autre mécanisme.
- **Conditions individuelles :** rapprocher le grade actuel et le grade cible du statut particulier applicable à la date envisagée. Contrôler l’échelon, l’ancienneté, les services retenus et l’éventuel examen professionnel.
- **Cadre collectif :** vérifier le tableau d’avancement de l’année concernée, l’inscription de l’agent, le ratio promus-promouvables et les lignes directrices de gestion.
- **Acteurs et instances :** contrôler les rôles respectifs de l’autorité territoriale, de l’assemblée délibérante et de la commission administrative paritaire. L’affiliation au centre de gestion doit être documentée si elle influe sur le circuit ; ne pas transposer automatiquement celui de la promotion interne.
- **Emploi et effets :** contrôler la situation de l’emploi support, les crédits disponibles, les éventuelles formalités liées à cet emploi, la date d’effet et les règles de classement dans le grade cible.

Le **socle national** est à rechercher dans le Code général de la fonction publique et le statut particulier du cadre d’emplois. Les **choix locaux** sont à établir à partir des lignes directrices de gestion, de la délibération relative aux ratios et des documents concernant l’emploi. Leur conformité au socle national reste à contrôler.

**Document préparatoire à la rédaction — non signable**

En application de l’abstention imposée par le corpus, voici la version préparatoire la plus avancée possible. Elle ne constitue pas un projet d’arrêté exécutable.

| Élément du futur arrêté | Champ à compléter et contrôle associé |
|---|---|
| Objet | Nomination de **[identité de l’agent]** au grade de **[grade cible]**, au titre de **[année du tableau]** |
| Employeur et signataire | **[collectivité ou établissement]**, **[autorité signataire]** ; compétence et éventuelle délégation à vérifier |
| Situation actuelle | **[statut]**, **[cadre d’emplois]**, **[grade]**, **[échelon]**, **[ancienneté]**, **[quotité et durée de l’emploi]** |
| Fondements nationaux | **[dispositions du code et du statut particulier]** ; références et versions à vérifier à la date d’effet |
| Fondements locaux | **[lignes directrices de gestion]**, **[délibération sur les ratios]**, **[tableau d’avancement]**, **[document relatif à l’emploi]** |
| Éléments justificatifs | **[conditions remplies et pièces probantes]**, **[examen professionnel, si pertinent]**, **[inscription au tableau]** |
| Nomination envisagée | **[grade cible]**, **[emploi ou affectation]**, **[date d’effet demandée]** ; possibilité et cohérence temporelle à vérifier |
| Classement envisagé | **[échelon de classement]**, **[ancienneté conservée]** ; à déterminer après contrôle des règles applicables, sans calcul fourni ici |
| Formalités finales | **[notification]**, **[publicité éventuelle]**, **[recours]**, **[transmission éventuelle]** ; contenu et modalités à vérifier avant rédaction |

**Suite recommandée**

1. **Gestionnaire carrière :** réunir les pièces individuelles et locales ; constituer une fiche de contrôle avec les justificatifs de chaque condition.
2. **Service juridique ou interlocuteur compétent :** consulter les sources officielles dans leur version applicable et consigner les passages soutenant la nomination, le classement et les formalités.
3. **DRH :** faire finaliser l’arrêté après ces contrôles, puis contrôler sa cohérence avec le dossier et le paramétrage de paie.

Pour la transmission, vérifier séparément la liste légale applicable à la **nature exacte de cet acte**, la convention locale de télétransmission et une éventuelle demande préfectorale. Ne pas assimiler cette nomination au recrutement d’un contractuel.

**Avant signature :** contrôler également la motivation éventuellement requise, la notification, les droits de recours du destinataire et des tiers, ainsi que la minimisation des données personnelles.

Les risques restant ouverts concernent principalement l’éligibilité, le tableau et le ratio, l’emploi support, le classement et la date d’effet. **Niveau de confiance : abstention sur la possibilité juridique de nomination et sur l’arrêté final.**
