# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre demande concerne l’indemnité de feu de sapeurs-pompiers professionnels. L’employeur, les situations individuelles et la date de paie concernée ne sont pas précisés.

**Décision : non tranchable.** Je ne peux fournir ni montant exact, ni taux, ni référence réglementaire certaine. Le corpus ne contient pas le texte propre à cette indemnité ; il signale que les sapeurs-pompiers professionnels relèvent d’un régime spécifique à vérifier.

Pour obtenir une réponse utilisable en paie, le service RH/paie devra :

- **Identifier le fondement** sur Légifrance : texte réglementaire propre au régime indemnitaire des sapeurs-pompiers professionnels, dispositions relatives à l’indemnité de feu et version applicable à la période concernée.
- **Contrôler les bénéficiaires, l’assiette et le taux**, ainsi que les éventuels paramètres locaux prévus par ce texte.
- **Réunir les données individuelles nécessaires** : grade, échelon, indice, quotité de travail et pièces de rémunération. Si l’assiette est indiciaire, vérifier l’indice majoré et la valeur du point à la date utile avant toute conversion en euros.

**À préciser en une fois :** quelle période de paie souhaitez-vous contrôler, pour quel employeur et quels grades/échelons ?

**Niveau de confiance : abstention sur le montant et le fondement juridique.** Aucun chiffre issu de cette réponse ne peut servir au paramétrage de la paie.
