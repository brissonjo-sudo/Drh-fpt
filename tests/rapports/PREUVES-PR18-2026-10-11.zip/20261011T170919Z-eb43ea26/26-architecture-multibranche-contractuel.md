# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je fournis donc un dossier de préparation, sans certifier les droits de l’agent ni une procédure applicable.

**Faits connus :** l’agent est contractuel en contrat à durée indéterminée (CDI), rémunéré par référence à un indice. Il demande la reprise de toute son ancienneté et un avancement de grade selon le régime d’un fonctionnaire titulaire.

**Décision : non tranchable en l’état.** Les clauses du contrat et les textes applicables doivent être contrôlés avant d’accepter ou de refuser sa demande.

Le point central est de distinguer **la référence indiciaire utilisée pour rémunérer l’agent** de **la détention d’un grade et du déroulement d’une carrière statutaire**. Le corpus invite à vérifier que cette référence ne confère pas un grade et n’ouvre pas un avancement automatique. Cette piste doit être confirmée sur les sources officielles avant toute réponse définitive.

Les deux demandes appellent des contrôles distincts :

- **Reprise d’ancienneté :** préciser les services concernés et l’effet recherché — rémunération actuelle, évolution future ou classement lors d’une éventuelle nomination comme fonctionnaire. Vérifier les engagements contractuels et les règles applicables ; ne pas transposer automatiquement un dispositif de classement réservé aux titulaires.
- **Avancement de grade :** contrôler les conditions statutaires de ce mécanisme et son champ d’application. Examiner séparément la voie d’une réévaluation de rémunération : le corpus distingue cette réévaluation d’un avancement automatique et invite à vérifier son obligation, sa périodicité et ses critères, sans présumer une augmentation.

Pour préparer la décision, voici la marche à suivre **documentaire**, sans constituer une procédure juridique exécutable :

| Action | Responsable du contrôle | Pièces et résultat attendu |
|---|---|---|
| Qualifier le dossier | Ressources humaines | Confirmer l’employeur territorial, le caractère public du contrat, l’effectif relevant du périmètre du corpus, les fonctions, la catégorie et la quotité de travail. |
| Examiner les engagements | Ressources humaines | Contrat, avenants, clauses de rémunération et d’évolution, indice de référence, historique des réévaluations et évaluations professionnelles. |
| Documenter l’ancienneté | Ressources humaines avec l’agent | État des services, employeurs, fonctions, catégories, quotités et interruptions ; préciser la date de demande et l’effet souhaité. |
| Vérifier le droit applicable | Juriste ou conseil statutaire | Consulter sur Légifrance le Code général de la fonction publique et les dispositions réglementaires territoriales relatives aux contractuels, en contrôlant une éventuelle recodification à la date utile. |
| Préparer l’arbitrage | Ressources humaines et décideur compétent, compétence à vérifier | Distinguer les obligations nationales, les engagements du contrat et les possibilités ouvertes par le cadre local de rémunération. |

La réponse écrite à préparer devra traiter séparément chaque demande et, si une évolution de rémunération est envisageable, préciser ses conditions et le support juridique requis. Une éventuelle voie d’accès au statut de fonctionnaire nécessiterait une analyse distincte.

Avant décision : contrôler la compétence, les formalités, la motivation et les recours éventuellement requis. Les risques principaux sont une transposition erronée du régime des titulaires ou l’oubli d’un engagement contractuel. Aucun montant ni reclassement ne peut être établi ici.

**Niveau de confiance : abstention sur le fond juridique ; cadrage documentaire uniquement.**
