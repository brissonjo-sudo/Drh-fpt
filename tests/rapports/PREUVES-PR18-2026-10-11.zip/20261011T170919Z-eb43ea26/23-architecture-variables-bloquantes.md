# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous préparez un tableau d’avancement de grade pour cette année. Vous disposez seulement du nom de l’agent et de son cadre d’emplois.

**Décision : non tranchable.** Ces informations ne permettent pas d’établir son éligibilité ni la possibilité d’une nomination. Le nom n’est pas nécessaire pour examiner le dossier.

Pour avancer, réunissez en une fois :

- **L’employeur :** type de collectivité, effectif — pour confirmer le périmètre de plus de 350 agents — et affiliation au centre de gestion.
- **La situation de l’agent :** titulaire, stagiaire ou contractuel ; grade exact actuel, grade envisagé, échelon et date d’accès à cet échelon.
- **Son parcours :** ancienneté dans le grade, services retenus, éventuel examen professionnel obtenu et justificatifs.
- **La date de nomination envisagée**, afin de contrôler les conditions à cette date.
- **Les pièces locales :** lignes directrices de gestion, délibération sur les ratios promus-promouvables et éléments de la campagne d’avancement.

Le **dossier de préparation à confier au service carrière de la DRH** doit couvrir ces contrôles :

| Contrôle à faire vérifier | Pièces et sources à examiner |
|---|---|
| Qualification de l’opération : avancement de grade ou promotion interne | Grades actuel et cible, cadre d’emplois ; décret statutaire particulier |
| Conditions d’accès au grade cible et date à laquelle elles seraient remplies | Historique de carrière, services, examen éventuel ; textes officiels applicables |
| Distinction entre éligibilité, inscription au tableau et nomination | Code général de la fonction publique et décret statutaire |
| Articulation du cadre national et des choix locaux | Tableau annuel, ratios fixés par l’assemblée et lignes directrices de gestion |
| Acteurs compétents et rôle actuel de la commission administrative paritaire | Textes sur les instances ; organisation locale et affiliation au centre de gestion |
| Possibilité et formalités d’une nomination | Situation de l’emploi, autorité compétente, date d’effet et contrôles de l’acte |

**Recommandation :** demandez d’abord la fiche de carrière et les pièces locales au service RH, puis faites contrôler les textes sur Légifrance dans leur version applicable à la date envisagée. Ne considérez pas l’agent comme nommable sur la seule base de son cadre d’emplois.

Le risque principal est de confondre une condition d’éligibilité avec une possibilité effective de nomination. **Niveau de confiance : abstention sur la nomination**, faute de données déterminantes et de vérification officielle.
