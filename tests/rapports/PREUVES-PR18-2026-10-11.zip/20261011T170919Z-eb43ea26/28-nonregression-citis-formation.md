# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** fonctionnaire territorial, accident de service contesté, question portant sur la formation du conseil médical et la décision d’imputabilité.

Le corpus fournit deux **pistes à vérifier avant toute saisine ou décision** :

- **Formation plénière** : c’est la formation indiquée pour examiner l’imputabilité au service lorsqu’un avis du conseil médical est requis. La formation restreinte correspond à d’autres questions médicales ; il faut contrôler cette distinction dans les textes applicables.
- **Autorité territoriale** : le corpus lui attribue la décision finale d’imputabilité. L’avis du conseil médical et la décision de l’employeur sont donc à distinguer, sous réserve de vérification officielle.

**Je ne peux pas certifier ces compétences ni conclure que la contestation impose, à elle seule, une saisine.**

Pour lever cette réserve, la DRH ou le service juridique devra contrôler le Code général de la fonction publique et les textes réglementaires territoriaux applicables au conseil médical et au congé pour invalidité temporaire imputable au service (**CITIS**), à la date utile.

Pièces à réunir : statut exact du fonctionnaire, date et circonstances de l’accident, déclaration, certificat médical et motifs précis de la contestation. Le régime des agents contractuels doit être distingué de celui du fonctionnaire concerné.

**État de décision : non tranchable sans vérification officielle. Niveau de confiance : abstention sur la conclusion juridique.**
