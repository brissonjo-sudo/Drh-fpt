# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** Je ne peux pas valider l’utilisation de la présomption de démission pour votre agent. La piste à faire vérifier est **l’abandon de poste en fonction publique territoriale**, en contrôlant sa distinction avec la présomption de démission du droit privé.

**Faits connus :** votre agent est titulaire et absent sans justificatif depuis plusieurs semaines. L’employeur, les dates exactes et les démarches déjà entreprises ne sont pas précisés.

Pour préparer l’examen du dossier, réunissez :

- le statut exact de l’employeur, son effectif et la date de début d’absence ;
- les obligations de service et le relevé des absences ;
- les contacts tentés, les réponses de l’agent et les éventuels justificatifs, notamment médicaux ;
- toute mise en demeure déjà envoyée, avec son contenu et la preuve de notification.

**Contrôles à confier à la DRH et au service juridique avant toute décision :**

- Vérifier, dans le Code général de la fonction publique et la jurisprudence officielle applicable, les conditions permettant de caractériser une rupture du lien avec le service. La durée de l’absence, seule, ne permet pas ici de conclure.
- Contrôler les exigences de mise en demeure : contenu, notification, délai approprié et avertissement sur les conséquences envisagées.
- Vérifier la distinction entre licenciement pour abandon de poste et sanction disciplinaire, notamment les conséquences sur le conseil de discipline et la communication du dossier au titre disciplinaire.
- Contrôler l’autorité compétente, la motivation, la date d’effet — sans la fixer automatiquement au premier jour d’absence —, la notification, les recours et l’éventuelle transmission au contrôle de légalité.

La recommandation immédiate est donc de **constituer ce dossier et faire vérifier le régime applicable avant d’engager une sortie des effectifs**. Une qualification erronée ou une mise en demeure irrégulière constitue un risque à examiner.

**Niveau de confiance : abstention sur la conclusion juridique.**
