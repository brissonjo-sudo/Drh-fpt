# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable en l’état.** Son nom et son cadre d’emplois ne suffisent pas pour déterminer s’il peut être nommé au grade supérieur en **2026**. Il faut distinguer **remplir les conditions d’avancement**, **être inscrit au tableau** et **être effectivement nommé**.

Pouvez-vous préciser, **sans transmettre son nom** :

- le **cadre d’emplois exact**, le **grade actuel** et le **grade visé** ;
- son statut, son **échelon**, la date d’accès à cet échelon et ses **services/ancienneté** ;
- son emploi à temps complet ou non complet, et un éventuel temps partiel ;
- un éventuel **examen professionnel réussi** et la **date de nomination souhaitée** ;
- le type de collectivité et son effectif, pour confirmer le périmètre applicable.

Le cadre général ressort des **consultations officielles archivées fournies**, datées du 11 octobre 2026 :

| Point à contrôler | Conséquence |
|---|---|
| **Conditions du statut particulier** | La DRH doit vérifier le texte propre au cadre d’emplois et au grade visé. Il n’est pas fourni : l’éligibilité individuelle reste inconnue. |
| **Tableau annuel d’avancement** | Pour l’avancement au choix, il repose sur la valeur professionnelle et les acquis de l’expérience ; une autre voie peut prévoir un examen professionnel. [Source — version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506) |
| **Ratio promus/promouvables** | Il fixe un nombre maximal de promotions. L’assemblée délibérante fixe le taux après avis du **comité social territorial (CST)**. Le texte exclut le cadre d’emplois des agents de police municipale : son régime doit donc être vérifié séparément. [Source — version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500) |
| **Lignes directrices de gestion (LDG)** | Elles fixent les orientations et critères généraux pour l’avancement au choix ; leur contenu local doit être examiné. [Source — version depuis le 01/08/2026](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251) |
| **Décision de nomination** | L’autorité territoriale prononce l’avancement parmi les agents inscrits, dans l’ordre du tableau. L’inscription ne suffit donc pas à établir une nomination certaine. [Source — version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498) |

**Prochaine action :** la DRH réunit la situation de carrière, le statut particulier, les LDG, la délibération sur le ratio applicable et le tableau envisagé, puis contrôle les conditions à la date souhaitée. Le rôle actuel de la **commission administrative paritaire (CAP)** reste à vérifier dans son texte propre : les extraits officiels fournis ne le documentent pas.

**Confiance :** cadre général étayé par les sources fournies ; possibilité individuelle de nomination non déterminée.
