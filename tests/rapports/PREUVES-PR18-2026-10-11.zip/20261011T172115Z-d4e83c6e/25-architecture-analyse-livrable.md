# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**La nomination est possible sous conditions. Pour cet agent, elle reste non tranchable faute de données individuelles et de pièces locales.** Vous pouvez néanmoins préparer l’arrêté avec des champs à compléter ; le projet ci-dessous ne sera signable qu’après les contrôles indiqués.

Analyse au **11 octobre 2026**, fondée uniquement sur les extraits officiels et leurs traces de consultation fournis dans le corpus. Aucune consultation complémentaire n’a été effectuée.

**Conditions de nomination**

Le projet concerne un **fonctionnaire territorial titulaire**, promu dans un grade de son cadre d’emplois. Il ne convient pas au recrutement d’un contractuel ni à une promotion interne vers un autre cadre d’emplois.

Les extraits officiels permettent d’établir les points suivants :

| Condition | Conséquence pour la nomination |
|---|---|
| **Tableau annuel d’avancement** | L’autorité territoriale prononce l’avancement parmi les fonctionnaires inscrits au tableau et doit respecter leur ordre. L’inscription ne vaut donc pas, à elle seule, nomination. |
| **Modalité d’avancement** | Il faut identifier la voie applicable : choix, examen professionnel ou concours professionnel, puis vérifier les conditions propres au grade. |
| **Lignes directrices de gestion (LDG)** | Pour l’avancement au choix, l’autorité tient compte des orientations et critères généraux des LDG, tout en conservant son pouvoir d’appréciation. |
| **Ratio promus-promouvables** | Hors exception prévue pour le cadre d’emplois des agents de police municipale, le nombre maximal de promotions résulte de l’effectif des agents remplissant les conditions multiplié par le taux fixé par l’assemblée délibérante, après avis du comité social territorial (CST). |
| **Acceptation de l’emploi** | L’avancement est subordonné à l’acceptation par l’agent de l’emploi assigné dans son nouveau grade. |
| **Date d’effet** | La décision individuelle peut prévoir une date d’effet antérieure à son caractère exécutoire. Cela ne dispense pas de vérifier les autres conditions à cette date. |

Sources : CGFP, versions applicables depuis le **1er mars 2022**, consultées dans les archives le **11 octobre 2026** : [modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), [ratio et compétence de l’assemblée](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), [tableau et ordre des promotions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), [acceptation de l’emploi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496), [date d’effet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425494). Pour le contenu des LDG : [extrait du CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251), version applicable depuis le **1er août 2026**, consultation archivée du **11 octobre 2026**.

**J’en déduis que** la nomination peut être préparée si l’agent est éligible, régulièrement inscrit au tableau, atteint dans l’ordre des promotions, compris dans le plafond applicable et accepte l’emploi proposé. Aucun de ces éléments individuels n’est établi ici.

**Contrôles à terminer avant signature**

La DRH doit réunir, dans cet ordre :

1. **Situation statutaire** : employeur, statut de titulaire, cadre d’emplois, grades actuel et cible, échelon, ancienneté, services, quotité et date d’effet souhaitée. Le décret statutaire applicable n’est pas fourni : **éligibilité et classement restent à vérifier**.
2. **Dossier de campagne** : tableau annuel signé, rang de l’agent, nominations déjà prononcées, LDG applicables et, si le régime l’exige, délibération du ratio avec avis du CST et calcul du plafond.
3. **Emploi d’accueil** : pièces relatives à l’emploi, à sa disponibilité et aux crédits ; conformité de ces éléments aux textes à contrôler. Recueillir la preuve de l’acceptation de l’agent.
4. **Circuit de décision** : qualité du signataire et éventuelle délégation, classement validé, formalités de publicité, notification et recours.

Le corpus métier indique que la **commission administrative paritaire (CAP)** n’est plus consultée préalablement sur l’avancement. **La source officielle de cette compétence n’est toutefois pas fournie** : ce point reste à confirmer, sans confondre la CAP avec le CST consulté sur le ratio.

**Transmission, motivation et recours**

- **Contrôle de légalité** : pour une commune, la nomination d’un titulaire par avancement de grade ne relève pas, pour ce seul motif, du **5° du I de l’article L. 2131-2 du CGCT**, qui concerne les agents non titulaires. Le délai de quinze jours ne doit donc pas être ajouté automatiquement. Une transmission volontaire ou une pratique locale doit être distinguée d’une obligation légale. Le préfet peut demander communication d’un acte hors liste. Sources : [liste actuelle des actes transmissibles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) et [demande préfectorale de communication](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), versions depuis le **1er juillet 2022**, consultations archivées du **11 octobre 2026**. Pour un autre employeur, vérifier son régime propre.
- **Motivation** : le texte fourni du CRPA vise certaines décisions individuelles **défavorables**. Il ne suffit pas à imposer une motivation obligatoire à toute promotion favorable. Le projet expose néanmoins ses fondements factuels. Si une décision défavorable distincte est envisagée, contrôler sa qualification et l’obligation de motivation écrite en droit et en fait. Sources : [décisions devant être motivées](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [contenu de la motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le **1er janvier 2016**, consultations archivées du **11 octobre 2026**.
- **Recours** : les extraits du CJA prévoient le délai de deux mois à compter de la notification ou de la publication ; son opposabilité au destinataire suppose la mention des voies et délais dans la notification. Le tribunal compétent et tout régime particulier restent à confirmer. Sources : [délai de recours](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le **1er janvier 2020**, et [opposabilité du délai](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le **1er janvier 2001**, consultations archivées du **11 octobre 2026**.

**Projet d’arrêté — à compléter et contrôler avant signature**

> **[COLLECTIVITÉ / ÉTABLISSEMENT]**  
> **Arrêté n° [numéro] portant nomination de [Prénom NOM] au grade de [grade cible] par avancement de grade**
>
> **[Le Maire / Le Président] de [employeur],**
>
> Vu le code général de la fonction publique, notamment ses dispositions relatives aux modalités de l’avancement de grade, au tableau d’avancement, à l’ordre des promotions et à l’acceptation de l’emploi assigné ;
>
> Vu [référence exacte et articles du statut particulier du cadre d’emplois — à vérifier dans leur version applicable à la date d’effet] ;
>
> Vu [les lignes directrices de gestion applicables, référence et date — pour l’avancement au choix] ;
>
> Vu [la délibération fixant le taux de promotion, référence et date, prise après avis du CST — visa à conserver uniquement si ce régime est applicable] ;
>
> Vu le tableau annuel d’avancement au grade de [grade cible] pour l’année [année], établi le [date], sur lequel figure [Prénom NOM] au rang [rang] ;
>
> Vu [la pièce relative à l’emploi d’affectation, sa référence et sa date — après contrôle de sa régularité] ;
>
> Vu l’acceptation par l’intéressé(e), en date du [date], de l’emploi de [intitulé] ;
>
> [Vu la délégation de signature du [date], référence [référence], si nécessaire ;]
>
> Considérant que [Prénom NOM], titulaire du grade de [grade actuel], remplit les conditions statutaires de l’avancement au grade de [grade cible] par la voie de [choix / examen professionnel / concours professionnel], conformément aux pièces vérifiées par la DRH ;
>
> Considérant que la présente nomination respecte l’ordre du tableau et [le plafond de promotions applicable / les dispositions particulières vérifiées] ;
>
> **ARRÊTE**
>
> **Article 1 — Nomination**  
> À compter du [date d’effet validée], [Prénom NOM] est nommé(e), par avancement de grade, au grade de [grade cible], au sein du cadre d’emplois de [cadre d’emplois].
>
> **Article 2 — Classement**  
> L’intéressé(e) est classé(e) au [échelon] avec une ancienneté conservée de [durée], conformément à [disposition statutaire exacte à vérifier].  
> [Indices à renseigner uniquement après validation du classement et de la grille applicable.]
>
> **Article 3 — Affectation**  
> L’intéressé(e) est affecté(e) à l’emploi de [intitulé], au sein de [service], selon [durée de l’emploi et, le cas échéant, quotité autorisée — données à valider].
>
> **Article 4 — Notification et formalités**  
> Le présent arrêté sera notifié à l’intéressé(e). Les formalités de publicité applicables seront accomplies selon [modalités à compléter après vérification du régime de l’employeur].  
> [Clause de transmission à conserver uniquement si une obligation applicable, une demande préfectorale ou une transmission volontaire est identifiée ; préciser laquelle.]
>
> **Article 5 — Recours**  
> Le présent arrêté peut faire l’objet d’un recours devant le tribunal administratif de [tribunal compétent à confirmer], dans un délai de deux mois à compter de sa notification.  
> [Mention à adapter avant notification si un régime particulier de recours est applicable.]
>
> **Article 6 — Exécution**  
> [Fonctions des responsables compétents] sont chargés, chacun en ce qui le concerne, de l’exécution du présent arrêté.
>
> Fait à [lieu], le [date].  
> [Qualité du signataire, prénom, nom et signature]
>
> **Notification à l’agent :** [date et preuve de réception].

**État final : possible sous conditions ; nomination individuelle non tranchable.** Les principaux points ouverts sont l’éligibilité statutaire, le classement, les pièces locales, l’emploi et les formalités applicables. Ne transmettre le dossier à la paie qu’après validation de ces éléments ; limiter les exemplaires diffusés aux données nécessaires.

**Confiance : stable pour les règles générales couvertes par les extraits officiels ; à vérifier pour leur application à l’agent et pour le projet avant signature.**
