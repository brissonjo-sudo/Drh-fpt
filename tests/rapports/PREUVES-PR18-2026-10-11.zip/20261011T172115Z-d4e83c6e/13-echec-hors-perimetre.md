# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Avec environ 40 agents, vérifiez d’abord votre rattachement au comité social territorial (CST) placé auprès du centre de gestion (CDG).**

L’extrait officiel fourni prévoit :

- **À partir de 50 agents** : un CST auprès de la collectivité ou de l’établissement.
- **Moins de 50 agents, pour les collectivités affiliées** : un CST placé auprès du CDG.

Source : [Code général de la fonction publique — extrait officiel fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312), version applicable au **11 octobre 2026**, consultation archivée à cette date. Ce texte établit le rattachement, **pas la procédure de saisine**.

Votre commune est hors du périmètre du corpus DRH, consacré aux collectivités de plus de 350 agents. **La procédure détaillée est donc non tranchable avec les seules sources fournies** : je ne peux pas certifier les délais, les pièces obligatoires ou les modalités de consultation.

Pour avancer, faites préparer par votre gestionnaire RH ou votre secrétaire général de mairie :

1. La confirmation de l’effectif retenu, de l’affiliation et du CST compétent.
2. Une description précise du projet à soumettre, accompagnée des documents disponibles.
3. Une demande au secrétariat du CST pour obtenir son formulaire, ses pièces requises, son calendrier et les textes applicables.

**Message prêt à envoyer :**

> Notre commune emploie environ 40 agents. Nous souhaitons consulter le CST sur [objet du projet]. Pouvez-vous confirmer notre rattachement à votre instance et nous transmettre les modalités de saisine, les pièces nécessaires, les échéances ainsi que les suites à donner à l’avis ?

**Confiance :** rattachement général étayé par l’extrait officiel ; rattachement de votre commune et procédure à confirmer.
