# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Vous pouvez envisager d’engager une procédure, sous conditions. En revanche, une exclusion de 5 jours ne peut pas être décidée sur les seuls soupçons : il faut établir les faits, respecter les droits de la défense et consulter préalablement le conseil de discipline.**

**Ma recommandation : préparer le dossier maintenant, sans arrêter définitivement la sanction.** L’ouverture formelle et le choix des 5 jours restent **non tranchables pour ce cas précis** tant que le statut territorial applicable, les faits et les dates ne sont pas précisés.

L’analyse ci-dessous porte sur le droit au **11 octobre 2026**, uniquement à partir des consultations officielles archivées fournies dans votre corpus.

**Ce que les sources permettent d’affirmer**

Pour un fonctionnaire territorial relevant du droit commun :

- **Une exclusion de 5 jours relève du deuxième groupe**, qui comprend les exclusions de quatre à quinze jours. Elle exige donc l’avis préalable du conseil de discipline. Cet avis ne remplace pas la décision de l’autorité compétente. Sources : [CGFP, article L. 533-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), version depuis le 01/03/2022, et [disposition relative à la consultation préalable](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), même date de version.
- **La procédure doit être engagée dans le délai de prescription de trois ans**, calculé à partir de la connaissance effective par l’administration de la réalité, de la nature et de l’ampleur des faits. Les poursuites pénales peuvent interrompre ce délai selon les conditions du texte. Il faut donc connaître cette date, qui peut différer de celle des faits. Source : [CGFP, article L. 532-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430), version applicable depuis le 01/03/2022.
- **L’agent doit être informé par écrit** de la procédure et des faits reprochés. Il bénéficie du dossier intégral et de ses annexes, de l’assistance de défenseurs de son choix et d’un temps suffisant pour préparer sa défense. Les pièces doivent être numérotées. Sources : [CGFP — droits de la défense](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000052323864), version depuis le 01/10/2025, et [décret du 18 septembre 1989 — information de l’agent](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836), version depuis le 11/12/2025.
- **La sanction doit être motivée par écrit, en droit et en fait.** Une formule générale telle que « comportement incompatible avec le service » ne suffit pas à exposer les faits et le fondement retenus. Sources : [CRPA, article L. 211-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [article L. 211-5](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le 01/01/2016.

**J’en déduis que** la procédure sert à examiner contradictoirement les faits ; son ouverture ne doit pas présenter la culpabilité ni la durée de sanction comme déjà acquises.

**Les actions à lancer, dans l’ordre**

| Ordre | Action et responsable | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : qualifier le dossier.** Confirmer l’employeur, le cadre d’emplois, un éventuel régime particulier et l’affiliation au centre de gestion si elle détermine le circuit. | Situation administrative de l’agent ; identification de l’instance compétente ; compétence du signataire et délégation éventuelle à vérifier avant tout acte. |
| **2** | **DRH : établir la chronologie et réunir les preuves.** Distinguer faits documentés, témoignages, soupçons et éléments favorables à l’agent. | Dates des faits, de leur connaissance effective, d’éventuelles poursuites pénales et de l’ouverture envisagée. Calcul documenté de la prescription. |
| **3** | **Autorité compétente, avec préparation DRH : décider de l’ouverture**, si les vérifications précédentes le permettent, puis informer l’agent par écrit. | Faits précisément décrits, droits au dossier et à l’assistance indiqués, preuve de remise du courrier. **Avant de recueillir ses observations, faire vérifier le régime applicable au droit de se taire** : les extraits officiels fournis ne permettent pas de le sécuriser. |
| **4** | **DRH : organiser la défense et compléter l’instruction.** Mettre à disposition un dossier intégral, numéroté, avec annexes ; recueillir et examiner les observations. | Inventaire des pièces, traçabilité de l’accès et des demandes de copie, temps réellement suffisant. Le renvoi relatif aux modalités de copie n’est pas entièrement documenté dans le corpus. |
| **5** | **Autorité compétente et secrétariat de l’instance : préparer la saisine du conseil de discipline**, si une sanction de deuxième groupe reste envisagée. | Composition et dossier de saisine à contrôler. Le président convoque le conseil ; l’autorité disciplinaire ne siège pas. L’agent doit être convoqué par le président, par lettre recommandée avec avis de réception, **au moins quinze jours avant la réunion**. |
| **6** | **Autorité compétente : réexaminer le dossier après l’avis**, puis décider. | Avis motivé, examen des arguments de défense, réalité des manquements et justification de la proportionnalité des 5 jours. Préparer une décision motivée ; organiser ensuite sa notification et son exécution. |

Les règles de présidence, de convocation et de communication de l’avis sont documentées par le décret de 1989 : [fonctionnement du conseil](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222), [convocation de l’agent](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372226) et [avis puis décision motivée](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042650806), dans leurs versions archivées applicables au 11/10/2026.

**Avant signature et notification**

Trois points restent à sécuriser expressément :

- **Recours :** vérifier les voies actuelles, leurs délais, le tribunal compétent et l’effet éventuel d’un recours gracieux. Le module métier signale la suppression de l’ancien conseil de discipline de recours, mais les textes officiels de suppression et de transition ne figurent pas dans les extraits : cette ancienne instance ne doit pas être proposée sans contrôle.
- **Contrôle de légalité :** pour une **commune**, la liste actuelle de [l’article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), applicable depuis le 01/07/2022, ne comporte pas de catégorie imposant la transmission de cette sanction disciplinaire d’un titulaire. Distinguer cela d’une transmission volontaire, des modalités locales et d’une [demande de communication du préfet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556). Pour un autre employeur territorial, vérifier le texte propre.
- **Mise en œuvre :** contrôler la date d’effet, les jours d’exclusion et les conséquences administratives et de paie avant paramétrage. Limiter la diffusion du dossier aux personnes nécessaires.

**Pour trancher l’ouverture dans votre dossier**, précisez en une réponse : quel employeur territorial et quel cadre d’emplois ; quels faits et quelles pièces ; quelles dates des faits et de leur connaissance effective, avec l’existence éventuelle de poursuites pénales.

**Confiance : stable sur le classement des 5 jours et les garanties citées ; décision individuelle non tranchable à ce stade.** Le risque principal serait de choisir la sanction avant d’avoir établi les faits et examiné la défense.
