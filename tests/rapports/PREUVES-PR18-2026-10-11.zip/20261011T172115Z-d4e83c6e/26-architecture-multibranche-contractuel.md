# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne donne pas au contractuel en CDI une carrière de fonctionnaire titulaire.** Son expérience peut justifier une réévaluation de rémunération, mais elle ne crée pas, à elle seule, un droit à reprendre toute son ancienneté ni à avancer de grade.

Analyse au **11 octobre 2026**, fondée exclusivement sur les extraits officiels archivés fournis.

### 1. Distinguer ses deux demandes

**Reprise de toute l’ancienneté : non tranchable sans examiner le contrat.**

La rémunération est fixée par l’autorité territoriale en tenant compte notamment des fonctions, des qualifications et de l’expérience. Le texte fourni ne prévoit pas une conversion obligatoire de toute l’ancienneté en échelons ou en points d’indice.

J’en déduis que l’agent peut demander que son expérience soit prise en compte dans sa rémunération. En revanche, une reprise intégrale selon les règles de classement des titulaires ne découle pas de son CDI. Il faut aussi vérifier si son contrat ou le cadre local prévoit un engagement particulier.

Source : [décret n° 88-145 du 15 février 1988 — disposition relative à la rémunération](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), version applicable depuis le **1er juillet 2026**, consultation archivée du **11 octobre 2026** — fonction : fixation et réévaluation de la rémunération.

**Avancement de grade comme un titulaire : impossible sur le seul fondement du CDI et de l’indice de référence.**

L’indice est ici une référence de rémunération ; il ne confère pas un grade. L’évolution salariale du contractuel relève de son régime propre et d’une décision de l’employeur, sans avancement automatique calqué sur celui d’un fonctionnaire.

J’en déduis que sa demande doit être instruite comme une **demande d’évolution de rémunération**, éventuellement liée à des fonctions plus importantes. Si son objectif est d’obtenir un grade de fonctionnaire, la voie d’accès au statut doit être examinée séparément, selon des conditions que les sources officielles fournies ne permettent pas de vérifier.

### 2. Ce que l’employeur doit examiner

Pour les agents en CDI, **la rémunération doit faire l’objet d’une réévaluation au moins tous les trois ans**, notamment au regard des entretiens professionnels ou de l’évolution des fonctions.

**Réévaluation obligatoire ne signifie pas augmentation automatique** : le texte impose un réexamen, sans fixer une hausse minimale ni une progression d’échelon.

Source : même disposition du décret n° 88-145. Le [Code général de la fonction publique — disposition relative à la rémunération des contractuels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), version applicable depuis le **1er mars 2022**, consultation archivée du **11 octobre 2026**, confirme les critères de fonctions, qualifications et expérience.

**Si l’agent est recruté sur un emploi permanent**, il bénéficie chaque année d’un entretien professionnel conduit par son supérieur hiérarchique direct. Cet entretien documente notamment ses résultats, son expérience, ses compétences et ses perspectives d’évolution.

Source : [décret n° 88-145 — entretien professionnel](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), version applicable depuis le **1er janvier 2023**, consultation archivée du **11 octobre 2026** — fonction : évaluation professionnelle.

### 3. Marche à suivre

1. **La DRH rassemble le dossier** : contrat et avenants, clauses de rémunération, fondement du recrutement, fiche de poste, justificatifs d’expérience, comptes rendus d’entretien, dernière réévaluation et délibération ou cadre local applicable.

2. **Elle vérifie les engagements existants** : indice fixe ou clause d’évolution, ancienneté déjà prise en compte, éventuelle promesse contractuelle et changements réels de fonctions. Elle contrôle aussi l’échéance du réexamen triennal.

3. **Le supérieur hiérarchique documente la demande** : responsabilités exercées, qualifications, expérience utile aux fonctions et résultats professionnels.

4. **L’autorité territoriale arbitre la rémunération**, sur une proposition argumentée de la DRH. Une hausse peut être envisagée sans être présentée comme un avancement de grade. Avant toute modification, la DRH vérifie les formalités contractuelles et locales applicables ; celles-ci ne sont pas établies par les extraits fournis.

5. **Une réponse écrite distingue les deux demandes** : absence de carrière statutaire attachée à l’indice de référence, puis résultat de l’examen salarial et motifs retenus.

**À préciser pour trancher individuellement :** quelles clauses d’évolution figurent au contrat, quand la rémunération a-t-elle été réévaluée et l’agent occupe-t-il un emploi fonctionnel de direction ? Pour certains de ces emplois, l’extrait prévoit un classement dérogatoire dont les textes de renvoi ne sont pas fournis.

**Confiance : stable sur les critères de rémunération et le réexamen triennal ; décision salariale individuelle à vérifier sur les pièces.** Aucun nouvel indice, montant ou rappel de rémunération ne peut être déterminé avec ce seul dossier.
