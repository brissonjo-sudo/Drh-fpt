# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Votre demande relève de la fonction publique hospitalière (FPH).** Le corpus fourni couvre la fonction publique territoriale (FPT) : l’effectif de 900 agents ne permet pas de transposer ses règles à un CHU.

**Mode dégradé : aucune source officielle n’a été consultée.** Je ne peux donc pas certifier le régime hospitalier du congé de longue maladie, sa durée, sa rémunération ou sa procédure d’attribution.

Les faits connus sont : un CHU de 900 agents, un fonctionnaire titulaire et un arrêt maladie depuis huit mois. La nature du congé actuellement accordé n’est pas précisée.

**Décision : non tranchable avec ce corpus.** Pour préparer la réponse, le service RH hospitalier doit réunir et contrôler :

- les décisions de congé déjà prises et leurs dates, pour identifier le congé actuel ;
- les dispositions du Code général de la fonction publique et les textes propres aux congés des fonctionnaires hospitaliers, dans leur version applicable ;
- les conditions médicales d’accès au congé de longue maladie, l’instance médicale compétente, les droits à rémunération et les modalités de renouvellement.

Les pièces médicales doivent suivre le circuit confidentiel approprié. **Niveau de confiance : abstention sur le régime demandé**, faute de sources hospitalières dans le corpus.
