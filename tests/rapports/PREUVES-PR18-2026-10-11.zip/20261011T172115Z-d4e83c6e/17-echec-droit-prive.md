# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non, pour un fonctionnaire titulaire territorial.** La présomption de démission prévue par la loi de 2022 concerne les salariés de droit privé. Elle ne s’applique pas à votre agent. La voie prévue par le statut est le **licenciement pour abandon de poste**, emportant radiation des cadres.

Sources du corpus : [Code du travail, art. L. 1237-1-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104), version depuis le 23/12/2022 ; [Code général de la fonction publique, art. L. 553-1, 1°](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184), version depuis le 01/03/2022. Versions applicables au 11/10/2026 selon les traces fournies.

**Plusieurs semaines d’absence injustifiée ne suffisent pas, à elles seules, à caractériser l’abandon de poste.** Avant toute radiation, l’administration doit adresser une mise en demeure :

- **écrite et effectivement notifiée** à l’agent ;
- lui demandant de reprendre son service dans un **délai approprié**, fixé selon sa situation ;
- l’avertissant expressément du risque de **radiation des cadres sans procédure disciplinaire préalable**.

Ces exigences sont établies par le [Conseil d’État, Section, 11 décembre 1998, nos 147511 et 147512, publié au Lebon](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335). Le [Conseil d’État, 26 septembre 2014, n° 365918](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000029504219) confirme que le délai approprié constitue une condition nécessaire, sans fixer de durée universelle.

À l’échéance, la DRH doit vérifier **la reprise effective**, puis examiner les réponses, intentions et éventuels justificatifs médicaux ou matériels. Une réponse refusant la reprise ne préserve pas automatiquement le lien avec le service ; inversement, la seule non-reprise ne dispense pas de cet examen ([CAA de Versailles, 14 avril 2026, n° 24VE00726, points 11–13](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000053906348), espèce concernant la fonction publique de l’État).

Il s’agit d’une voie **non disciplinaire** : pas de conseil de discipline ni de communication du dossier au titre des garanties disciplinaires.

**Décision : présomption de démission impossible ; radiation pour abandon de poste non tranchable en l’état.** Faites réunir par la DRH la chronologie des absences, les échanges et les preuves de notification. Avant signature, restent à contrôler la compétence, la motivation, la date d’effet, la notification, les recours et le régime de transmission ; les extraits fournis ne vérifient pas ces formalités.

**Avez-vous déjà notifié une mise en demeure ? Si oui, quel délai et quel avertissement contenait-elle, et l’agent a-t-il répondu ou repris ?**

Confiance : élevée sur la distinction des régimes et les garanties citées ; qualification individuelle encore ouverte. Réponse fondée sur les consultations officielles archivées fournies dans le corpus.
