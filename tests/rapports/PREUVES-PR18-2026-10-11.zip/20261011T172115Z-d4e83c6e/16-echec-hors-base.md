# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**L’indemnité de feu est fixée à 25 % du traitement soumis à retenue pour pension.** Le montant en euros dépend donc de l’assiette de chaque agent.

**Calcul : indemnité de feu = traitement soumis à retenue pour pension × 0,25.**

Le fondement est le **décret n° 90-850 du 25 septembre 1990 portant dispositions communes à l’ensemble des sapeurs-pompiers professionnels**. L’[extrait officiel fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025), dans sa version en vigueur depuis le **26 juillet 2020**, applicable au **11 octobre 2026**, dispose :

> « Les sapeurs-pompiers professionnels peuvent percevoir […] une indemnité de feu d’un taux de 25 % du traitement soumis à retenue pour pension. »

Cette source provient de la consultation officielle archivée dans votre corpus le 11 octobre 2026. Elle renvoie aux conditions fixées par l’article 17 de la loi n° 90-1067 du 28 novembre 1990, dont le contenu n’est pas fourni : ces conditions restent à vérifier avant de confirmer un droit individuel.

**Montant exact individuel : non tranchable avec les données actuelles.** Pour le calculer, indiquez la période de paie et le traitement soumis à retenue pour pension de chaque agent, sans donnée nominative. Si vous disposez seulement de l’indice majoré, il faudra aussi confirmer la valeur du point d’indice, la quotité rémunérée et l’assiette applicable à cette période.

**Confiance : stable sur le taux et l’assiette indiqués dans l’extrait ; montant individuel à déterminer.**
