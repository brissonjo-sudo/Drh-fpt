# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**La formation plénière est compétente lorsqu’un avis sur l’imputabilité est requis. La décision finale appartient à l’autorité territoriale** — maire ou président de l’employeur territorial — et non au conseil médical.

La saisine **n’est pas systématique du seul fait que l’accident est contesté**. Pour un accident de service, le texte prévoit la consultation lorsqu’une **faute personnelle ou une circonstance particulière est potentiellement de nature à détacher l’accident du service**. Il faut donc examiner le motif précis de la contestation.

Les extraits officiels fournis établissent ce circuit :

- **Déclenchement de la consultation** : [décret du 30 juillet 1987](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859), version en vigueur depuis le **18 avril 2024**.
- **Formation compétente : plénière**, pour la consultation relative à l’imputabilité ; la formation restreinte ne convient pas à cet objet : [même décret](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783), même date de version.
- **Décision finale** : « Au terme de l’instruction, l’autorité territoriale se prononce sur l’imputabilité au service » : [même décret](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843), même date de version.

**Action à retenir :** documenter les circonstances invoquées ; si elles correspondent au déclencheur ci-dessus, saisir la **formation plénière**, puis soumettre la décision à l’autorité territoriale après instruction et avis.

**Confiance : stable sur la compétence et le décideur**, d’après les consultations officielles archivées fournies, datées du **11 octobre 2026**. La nécessité de saisir dans votre dossier dépend du motif de contestation.
