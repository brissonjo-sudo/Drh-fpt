# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Vous pouvez conserver un cycle annualisé, mais son ancienneté ne garantit pas sa conformité.** Le maintien de votre organisation est **non tranchable en l’état** : il faut examiner la délibération applicable et les horaires réellement pratiqués.

Cette réponse porte sur le **droit commun de la fonction publique territoriale**, au **11 octobre 2026**, à partir des seules consultations officielles archivées fournies dans le corpus.

**Le socle national à respecter**

Le décret territorial du 12 juillet 2001 rend applicables les règles du décret du 25 août 2000, sous réserve des adaptations territoriales. Il faut donc utiliser ces deux textes ensemble, sans transposer directement les compétences ministérielles propres à l’État.  
Source : [décret n° 2001-623, article 1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version depuis le 14 juillet 2001.

Pour un agent à temps complet, la référence est **35 heures par semaine et 1 607 heures annuelles de travail effectif**, sans préjudice des heures supplémentaires. L’annualisation permet de répartir les horaires sur l’année : elle ne dispense pas de respecter les garanties ci-dessous. Les obligations individuelles doivent aussi tenir compte de la quotité de travail.  
Sources : décret n° 2000-815, [article 1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142) et [article 4](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560147), versions depuis le 1er janvier 2023.

| Garantie | Règle nationale |
|---|---|
| Travail effectif quotidien | **10 heures maximum** |
| Amplitude de la journée | **12 heures maximum** |
| Repos quotidien | **11 heures minimum** |
| Travail hebdomadaire, heures supplémentaires comprises | **48 heures maximum**, et **44 heures en moyenne** sur toute période de 12 semaines consécutives |
| Repos hebdomadaire | **35 heures minimum**, comprenant en principe le dimanche |
| Pause | **20 minutes minimum** : aucun temps de travail quotidien ne peut atteindre 6 heures sans cette pause |

Source : [décret n° 2000-815, article 3](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150), version depuis le 1er janvier 2023. **Une moyenne annuelle correcte ne compense pas un dépassement de ces garanties.**

Le travail effectif correspond au temps pendant lequel l’agent reste à disposition de l’employeur, suit ses directives et ne peut vaquer librement à ses occupations personnelles. Pour décompter une pause, il faut donc examiner ses conditions réelles.  
Source : [article 2 du même décret](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version depuis le 29 juin 2006.

**Ce qui dépend de votre collectivité**

- **Le cycle et ses modalités** sont déterminés par l’organe délibérant, après avis du **comité social territorial (CST)**. Il faut retrouver la délibération et vérifier que les plannings lui correspondent. Source : [décret n° 2001-623, article 4](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472), version depuis le 1er janvier 2023.
- **Une réduction de la durée annuelle** est possible pour des sujétions réelles liées aux missions et aux cycles : nuit, dimanche, horaires décalés, travail en équipes, travaux pénibles ou dangereux notamment. Elle relève d’une délibération après avis du CST ; elle n’est pas automatique. Source : [article 2 du même décret](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477), version depuis le 1er janvier 2023.
- **Les heures supplémentaires**, pour les agents relevant d’un décompte horaire, s’apprécient au dépassement des bornes du cycle. Le corpus ne permet pas de vérifier entièrement leur régime territorial de compensation ou d’indemnisation : ce contrôle reste à compléter.

Les dérogations aux garanties minimales sont encadrées par l’article 3 précité. **Une pratique ancienne ou une délibération locale ne suffit pas à les autoriser.**

**Ma recommandation : contrôler avant de modifier ou de reconduire**

1. **DRH** : réunir la délibération, ses modifications, l’avis du CST et les éventuelles réductions pour sujétions.
2. **Responsable de service et DRH** : comparer les plannings et les heures réalisées aux bornes du cycle, aux repos et au décompte annuel.
3. **Gestionnaire des temps** : vérifier que le système d’information RH reproduit ces règles, notamment pour les pauses et les dépassements.

**Maintien possible sous conditions** si ces contrôles concordent. Sinon, il faut corriger les horaires ou le cadre local, selon l’écart constaté. Si votre organisation conserve un ancien régime dérogatoire, son maintien demande une vérification supplémentaire : le corpus ne contient pas l’extrait officiel permettant de contrôler les effets de la réforme de 2019 sur ce point.

**Pour trancher, pouvez-vous préciser le type d’employeur et son effectif, les agents et quotités concernés, ainsi que le contenu de la délibération actuelle et les horaires du cycle ?**

**Confiance : stable sur les garanties nationales issues des extraits fournis ; conformité de votre organisation à vérifier.**
