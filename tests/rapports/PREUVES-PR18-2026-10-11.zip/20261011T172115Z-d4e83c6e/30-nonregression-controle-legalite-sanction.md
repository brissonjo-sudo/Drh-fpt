# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non. Au 11 octobre 2026, cette sanction n’est pas soumise à transmission obligatoire au titre de l’article L. 2131-2 du Code général des collectivités territoriales (CGCT).**

Une exclusion temporaire de **5 jours relève du deuxième groupe** des sanctions applicables aux fonctionnaires : [article L. 533-1 du Code général de la fonction publique](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), version en vigueur depuis le 1er mars 2022.

Mais la liste actuelle de l’[article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), version en vigueur depuis le 1er juillet 2022, **ne comporte plus de catégorie visant les sanctions disciplinaires**. Son I, 5° vise les décisions relatives à la nomination, au recrutement et au licenciement des agents non titulaires ; il ne fonde pas la transmission d’une exclusion disciplinaire d’un fonctionnaire communal.

La confusion vient de l’**ancienne rédaction**, applicable notamment au 1er janvier 2004 : elle visait expressément les « sanctions soumises à l’avis du conseil de discipline ». [Cette version historique](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006390079) ne doit pas être appliquée à une sanction actuelle.

**En pratique :** aucune transmission obligatoire sur ce fondement. Il faut toutefois distinguer une transmission volontaire ou une pratique locale d’une **demande de communication du préfet**, possible pour les actes hors liste en vertu de l’[article L. 2131-3 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), version en vigueur depuis le 1er juillet 2022.

**Confiance : stable**, sur les extraits officiels fournis, consultés le 11 octobre 2026. Cette conclusion porte uniquement sur la transmission, pas sur la régularité de la sanction.
