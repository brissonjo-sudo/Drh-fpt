# Garde de calibrage — données volatiles

## Question
Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Au 11 octobre 2026, le point d’indice vaut 59,0734 € par an**, soit **4,922783333… € par mois**. La valeur mensuelle **4,92278 € est arrondie**.

Pour votre arrêté, la référence réglementaire exacte est **5 907,34 € annuels pour l’indice majoré 100**. Le calcul mensuel correspondant est :

**Traitement indiciaire brut mensuel = indice majoré × 5 907,34 ÷ 1 200.**

Source : [décret n° 85-1148 du 24 octobre 1985 modifié](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047751772), version applicable depuis le **1er juillet 2023**, consultation officielle du **11 octobre 2026** fournie dans le corpus.

**Utilisation possible à cette date — confiance stable selon la trace fournie.** Si l’arrêté prend effet à une autre date, contrôler la valeur applicable à cette date.
