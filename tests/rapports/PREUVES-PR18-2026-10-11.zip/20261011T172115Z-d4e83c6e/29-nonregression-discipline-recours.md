# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non : une sanction prononcée en 2026 ne peut pas être contestée devant un conseil de discipline de recours.** Cette réponse concerne un **fonctionnaire territorial titulaire** ; le régime d’un stagiaire ou d’un contractuel doit être contrôlé séparément.

L’analyse repose exclusivement sur les consultations officielles archivées dans votre corpus, datées du **11 octobre 2026**.

Une exclusion de **5 jours appartient au deuxième groupe** : elle nécessite la consultation préalable du conseil de discipline. Ce **conseil préalable subsiste**, tandis que l’ancienne instance de recours a été supprimée. La structure consolidée du décret confirme l’abrogation du chapitre II « Des conseils de discipline de recours » et des articles 15 et 16.  
Sources : [échelle des sanctions du CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), [consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), [décret consolidé au 11 octobre 2026](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000335719/2026-10-11).

La réserve transitoire de l’article 94 XI de la loi du 6 août 2019 concerne les recours contre des **sanctions intervenues avant sa publication, le 7 août 2019**. Elle ne concerne donc pas votre sanction de 2026 et ne rouvre pas automatiquement les délais des dossiers anciens. [Source officielle archivée](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000038889235).

**Dans la notification, indiquez :**

- **Le recours contentieux direct** devant le tribunal administratif territorialement compétent, dans les **deux mois suivant la notification**.
- **La possibilité d’un recours gracieux** auprès de l’autorité territoriale ayant pris la décision. Présenté dans ce même délai, il **interrompt le délai de recours contentieux**. Il constitue une faculté, pas une étape préalable obligatoire.

Le délai de recours n’est opposable que si **les voies et délais figurent dans la notification**. Sources : [délai contentieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), [opposabilité du délai](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), [définition du recours gracieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367823) et [effet interruptif](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367829).

Vous pouvez utiliser cette **clause à compléter** :

> La présente décision peut faire l’objet d’un recours contentieux devant le tribunal administratif de **[ville — coordonnées]**, dans un délai de deux mois à compter de sa notification.
>
> Vous pouvez également, dans ce même délai, former un recours gracieux auprès de **[autorité ayant pris la décision — adresse]**. Ce recours interrompt le délai de recours contentieux.
>
> Le recours gracieux est facultatif : vous pouvez saisir directement le tribunal administratif.

**Recommandation — possible sous conditions :** la DRH complète le tribunal compétent et les coordonnées de l’auteur, retire toute mention du conseil de discipline de recours et conserve la preuve de notification. N’ajoutez pas un recours hiérarchique auprès du préfet : le corpus ne fournit aucun fondement à cette voie.

La décision doit aussi être motivée. La compétence du signataire, les garanties de défense et une éventuelle transmission au contrôle de légalité restent à contrôler séparément : les extraits fournis ne permettent pas de valider ces points.

**Confiance : stable** sur la suppression de l’instance de recours et les deux voies indiquées ; **à vérifier** pour le tribunal compétent et la régularité du dossier individuel.
