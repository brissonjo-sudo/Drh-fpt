# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**La formation plénière**, lorsque l’avis du conseil médical est requis pour examiner l’imputabilité au service. **La décision finale appartient à l’autorité territoriale** — maire ou président de l’employeur — et non au conseil médical.

La saisine **n’est pas systématique du seul fait que l’accident est contesté**. Pour un accident de service, le texte prévoit la consultation lorsqu’une faute personnelle ou une autre circonstance particulière est potentiellement de nature à détacher l’accident du service. Il faut donc préciser le motif de la contestation.

Le circuit est le suivant :

- **L’autorité territoriale instruit le dossier** et identifie les circonstances susceptibles de détacher l’accident du service.
- **Le conseil médical en formation plénière rend un avis**, si cette consultation est requise. La formation restreinte ne constitue pas la formation compétente pour cet examen d’imputabilité.
- **L’autorité territoriale se prononce au terme de l’instruction** sur l’imputabilité et, le cas échéant, place le fonctionnaire en congé pour invalidité temporaire imputable au service (**CITIS**).

Ces conclusions reposent sur les consultations officielles archivées fournies dans le corpus : décret du 30 juillet 1987, dispositions relatives à la [formation plénière](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783), aux [cas de consultation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859) et à la [décision de l’autorité territoriale](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843), versions en vigueur depuis le **18 avril 2024**, consultées le **11 octobre 2026**.

**État de décision : possible sous conditions** pour la saisine ; son caractère obligatoire dépend du motif précis de contestation. **Confiance : stable** sur la formation compétente et l’autorité décisionnaire.
