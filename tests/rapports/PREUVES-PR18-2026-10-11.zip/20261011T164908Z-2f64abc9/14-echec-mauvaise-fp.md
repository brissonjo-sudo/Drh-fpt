# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Votre question relève de la fonction publique hospitalière (FPH).** Le corpus fourni couvre uniquement la fonction publique territoriale : l’effectif de 900 agents ne change pas cette limite.

**Décision : non tranchable avec ce corpus.** Aucune source officielle hospitalière n’a été consultée. Je ne peux donc pas préciser les conditions, la durée ou la rémunération du congé de longue maladie applicable à votre agent.

Pour préparer la vérification, votre service RH doit réunir :

- **La situation actuelle** : corps et grade, décision de congé en cours, date initiale de l’arrêt et historique des congés. Les huit mois d’absence ne permettent pas, à eux seuls, d’identifier le congé juridiquement accordé.
- **Les pièces utiles** : éventuelle demande de congé de longue maladie et éléments médicaux destinés au circuit médical compétent, dans le respect du secret médical.
- **Les sources hospitalières** : dispositions du Code général de la fonction publique applicables à la FPH et textes hospitaliers sur les congés de maladie, dans leur version applicable.

Le contrôle devra porter sur l’éligibilité, l’articulation avec le congé actuel, les droits à rémunération, les renouvellements et les rôles respectifs de l’instance médicale et de l’autorité décisionnaire du CHU.

**Niveau de confiance : abstention sur le régime de fond, faute de sources hospitalières dans le corpus.**
