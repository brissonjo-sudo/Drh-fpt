# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Vous pouvez conserver un cycle annualisé s’il respecte les règles actuelles. Son ancienneté ne suffit pas à le valider.** En l’état, le maintien de votre organisation est **non tranchable** : il manque la délibération applicable et les horaires réellement pratiqués.

L’analyse ci-dessous concerne les **agents territoriaux relevant du droit commun**, au **11 octobre 2026**, à partir des extraits officiels archivés fournis.

**L’annualisation reste possible.** Le cycle peut aller de la semaine à l’année : la référence de **35 heures hebdomadaires** n’impose donc pas de travailler exactement 35 heures chaque semaine. Pour un agent à temps complet, le décompte annuel repose sur **1 607 heures**, sans préjudice des heures supplémentaires.  
Sources : décret du 25 août 2000, [durée du travail](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142) et [cycles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560147), versions depuis le 01/01/2023 ; application territoriale par le [décret du 12 juillet 2001](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version depuis le 14/07/2001.

**Les garanties nationales doivent être respectées pendant tout le cycle**, y compris les périodes de forte activité :

| Point à contrôler | Règle de droit commun |
|---|---|
| Travail effectif quotidien | **10 heures maximum** |
| Amplitude de la journée | **12 heures maximum** |
| Travail hebdomadaire, heures supplémentaires comprises | **48 heures maximum** sur une semaine |
| Moyenne hebdomadaire | **44 heures maximum** sur toute période de **12 semaines consécutives** |
| Repos quotidien | **11 heures minimum** |
| Repos hebdomadaire | **35 heures minimum**, comprenant en principe le dimanche |
| Pause | Au moins **20 minutes** : aucun temps de travail quotidien ne peut atteindre **6 heures** sans cette pause |

Source : décret du 25 août 2000, [garanties minimales et dérogations](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150), version depuis le 01/01/2023.

J’en déduis qu’un total annuel correct **ne compense pas** une journée trop longue ou un repos insuffisant. Une délibération locale ne suffit pas à autoriser une dérogation : les exceptions prévues par le texte doivent être examinées séparément.

Le décompte doit aussi refléter le **travail effectif** : temps pendant lequel l’agent reste à disposition de l’employeur, suit ses directives et ne peut vaquer librement à ses occupations personnelles. Le traitement d’une pause dépend donc de ses conditions réelles.  
Source : [définition officielle](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version depuis le 29/06/2006.

**La collectivité fixe l’organisation locale, dans ces limites.**

- **Cycles :** l’organe délibérant détermine leurs conditions de mise en place **après avis du comité social territorial (CST)**. Il faut vérifier que votre cycle actuel correspond bien à la délibération applicable. Source : [décret territorial, conditions des cycles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472), version depuis le 01/01/2023.
- **Sujétions :** une réduction de la durée annuelle est **possible**, par délibération après avis du CST, pour des contraintes réelles liées aux missions et aux cycles : nuit, dimanche, horaires décalés, équipes, forte modulation, travaux pénibles ou dangereux. Elle n’est pas automatique. Source : [décret territorial, réduction pour sujétions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477), version depuis le 01/01/2023.
- **Heures supplémentaires :** pour les agents relevant d’un décompte horaire, le texte les rattache au dépassement des bornes du cycle. Il faut donc contrôler ces bornes, sans attendre uniquement le bilan annuel. Les modalités territoriales précises de compensation restent à vérifier : le décret auquel elles renvoient n’est pas fourni.

**Je recommande de faire contrôler le cycle actuel avant de décider de le maintenir :**

1. **DRH :** réunir la délibération et ses modifications, l’avis du CST ou de l’instance compétente à l’époque, les populations concernées et leurs quotités.
2. **Responsable du service avec la DRH :** comparer les plannings réellement exécutés aux bornes du cycle, au décompte annuel et à toutes les garanties ci-dessus.
3. **Si une correction est nécessaire :** préparer les ajustements et la délibération correspondante, après avis du CST.

Si votre organisation repose sur un **ancien régime plus favorable**, son maintien demande un contrôle supplémentaire : les extraits officiels fournis ne documentent pas les dispositions ayant supprimé certains régimes historiques. Je ne peux donc pas valider cette exception.

**Pour trancher, pouvez-vous préciser votre employeur et son effectif, les agents concernés et leurs quotités, puis les caractéristiques du cycle : durée annuelle, horaires quotidiens, semaines hautes et éventuelle réduction pour sujétions ?**

**Confiance : stable sur le socle national fourni ; à vérifier sur votre organisation locale.** Les traces officielles sont datées du 11/10/2026 ; aucune consultation supplémentaire n’a été réalisée.
