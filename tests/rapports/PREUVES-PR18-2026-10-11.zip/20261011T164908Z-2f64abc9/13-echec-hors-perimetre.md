# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Avec environ 40 agents, vérifiez d’abord que le comité social territorial (CST) compétent est celui du centre de gestion (CDG).**

L’extrait officiel fourni prévoit :

- un **CST propre à partir de 50 agents** ;
- un **CST auprès du CDG pour les collectivités affiliées employant moins de 50 agents**.

Source : [Code général de la fonction publique — extrait officiel fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312), version applicable au 11 octobre 2026, consultation archivée à cette date. Ce texte établit le rattachement de l’instance, **pas la procédure de saisine**.

Le corpus DRH fourni couvre les collectivités de plus de 350 agents. Pour votre commune, je peux donc vous orienter, mais **je ne peux pas certifier une procédure détaillée avec les seules sources présentes**.

**Décision : procédure non tranchable en l’état.** Votre commune est-elle affiliée au CDG, et sur quel projet souhaitez-vous consulter le CST ?

En attendant, voici les démarches de préparation utiles :

1. **Votre gestionnaire RH confirme le rattachement**, avec l’effectif retenu et les pièces d’affiliation.
2. **Il contacte le secrétariat du CST compétent** pour obtenir les modalités de saisine, le calendrier et la liste des pièces.
3. **Il rassemble le projet et une note explicative** : objet, agents concernés, effets attendus et date de mise en œuvre envisagée.

Avant de mettre le projet en œuvre, faites confirmer par ce secrétariat les règles applicables à son objet : consultation obligatoire ou facultative, caractère préalable de l’avis, documents nécessaires et suites à donner.

**Confiance : stable pour le seuil figurant dans l’extrait ; abstention sur la procédure, absente des sources fournies.**
