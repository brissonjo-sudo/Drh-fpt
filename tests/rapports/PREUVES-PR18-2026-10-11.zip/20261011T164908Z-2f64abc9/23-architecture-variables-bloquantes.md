# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Le nom et le cadre d’emplois ne permettent pas de déterminer si l’agent remplit les conditions d’avancement, ni s’il peut être nommé cette année.

Pour avancer, transmettez ces **trois blocs d’informations**, sans son nom :

1. **Situation de carrière** : cadre d’emplois exact, grade actuel et grade visé, statut titulaire/stagiaire/contractuel, échelon, ancienneté et services retenus ; examen professionnel obtenu, s’il y en a un.
2. **Contexte** : type de collectivité, effectif, éventuel régime particulier et date de nomination envisagée en 2026.
3. **Pièces locales** : lignes directrices de gestion (**LDG**), délibération fixant le ratio promus/promouvables, tableau d’avancement déjà établi ou en préparation, et emploi disponible au grade visé.

Le cadre général ressort des **consultations officielles archivées fournies**, applicables au 11 octobre 2026 :

| Point | Règle établie par l’extrait fourni |
|---|---|
| Sélection | L’avancement peut intervenir au choix, après examen professionnel ou par concours professionnel. Au choix, le tableau repose sur la valeur professionnelle et l’expérience ; l’autorité tient compte des LDG. [Source CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), version depuis le 01/03/2022. |
| Nombre de promotions | Le maximum résulte des effectifs remplissant les conditions multipliés par le taux fixé par l’assemblée délibérante, après avis du **comité social territorial (CST)**. **Le cadre d’emplois des agents de police municipale est exclu de cette règle générale.** [Source CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), version depuis le 01/03/2022. |
| Nomination | L’autorité territoriale prononce l’avancement parmi les inscrits au tableau, dans l’ordre de celui-ci. [Source CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), version depuis le 01/03/2022. |
| LDG | Elles fixent les orientations et critères généraux de l’avancement au choix. [Source CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251), version depuis le 01/08/2026. |

**J’en déduis que remplir les conditions statutaires ne suffit pas, à lui seul, à garantir une nomination.** Il faut distinguer l’éligibilité, la sélection au tableau et la décision de nomination.

La prochaine action de la DRH consiste à réunir les pièces de carrière, puis à contrôler le **statut particulier du cadre d’emplois**, les conditions du grade cible et les règles locales avant de proposer une nomination. Le rôle actuel de la **commission administrative paritaire (CAP)** doit également être contrôlé : aucune consultation officielle fournie ici ne permet de certifier sa compétence sur ce dossier.

**Confiance : stable pour les règles générales citées ; abstention sur l’éligibilité individuelle et la nomination en 2026**, faute de données de carrière et de texte statutaire propre.
