# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Une procédure est envisageable sous conditions. En revanche, les éléments fournis ne permettent pas encore de recommander une exclusion de cinq jours.** Ma recommandation est de préparer le dossier, puis de décider de l’ouverture après les contrôles ci-dessous.

L’analyse porte sur le droit au **11 octobre 2026**, à partir des consultations officielles archivées fournies dans le corpus.

**Ce qui est établi juridiquement**

Pour un **fonctionnaire territorial titulaire**, une exclusion temporaire de **cinq jours relève du deuxième groupe** : celui-ci comprend les exclusions de quatre à quinze jours. Elle exige donc la **consultation préalable du conseil de discipline**. L’exemption prévue pour le premier groupe ne s’applique pas.

Sources : [CGFP, article L. 533-1 — échelle des sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) et [disposition imposant la consultation préalable](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), versions applicables depuis le 1er mars 2022, consultations archivées du 11 octobre 2026.

L’engagement est également soumis à la prescription : **trois ans à compter de la connaissance effective, par l’administration, de la réalité, de la nature et de l’ampleur des faits**. Le point de départ n’est donc pas automatiquement la date des faits. Des poursuites pénales peuvent interrompre ce délai dans les conditions du texte.

Source : [CGFP, article L. 532-2 — prescription](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430), version applicable depuis le 1er mars 2022, consultation archivée du 11 octobre 2026.

**Pour trancher l’ouverture dans votre dossier, pouvez-vous préciser :**

- l’employeur territorial, son effectif et son affiliation éventuelle au centre de gestion ;
- les faits reprochés, leurs dates, les pièces disponibles et la date de leur connaissance effective par l’administration ;
- l’existence de poursuites pénales et la date envisagée d’ouverture de la procédure.

Ces éléments conditionnent le régime, la prescription et le circuit du conseil. Le seul soupçon décrit ici ne permet pas d’arrêter la sanction.

**Décision recommandée**

- **Préparation du dossier : à lancer immédiatement.**
- **Engagement individuel : non tranchable** avant clarification des faits, dates et compétences.
- **Exclusion de cinq jours : non tranchable** avant examen des preuves, de la défense et de l’avis du conseil.

Les cinq jours doivent rester une **sanction envisagée**, sans être présentés comme une décision déjà acquise.

**Actions à lancer, dans l’ordre**

| Ordre | Action et responsable | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : qualifier le dossier.** Confirmer le statut territorial, le cadre d’emplois, l’employeur et les dates utiles. | Pièces statutaires ; chronologie datée ; contrôle de prescription et des versions applicables. Si les faits sont anciens, les extraits actuels ne suffisent pas à vérifier tout le droit applicable. |
| **2** | **DRH et encadrement : réunir les éléments factuels**, y compris ceux favorables à l’agent. | Rapport distinguant faits établis, témoignages et soupçons ; pièces identifiées ; contradictions signalées. Toute mesure d’investigation particulière nécessite son propre contrôle juridique. |
| **3** | **Autorité territoriale, avec la DRH : décider de l’ouverture**, si les contrôles précédents le permettent. | Compétence du signataire et délégation éventuelle vérifiées ; griefs précis, datés et rattachés aux pièces. La source primaire détaillant l’attribution du pouvoir disciplinaire n’est pas fournie : compléter ce contrôle avant signature. |
| **4** | **Autorité et DRH : informer l’agent par écrit et organiser sa défense.** | Information sur les faits reprochés ; accès au dossier intégral et aux annexes ; pièces numérotées ; assistance par les défenseurs de son choix ; temps suffisant pour préparer sa défense ; preuves de remise et d’accès. |
| **5** | **DRH : vérifier le droit de se taire avant de recueillir les observations.** | Le corpus métier exige ce contrôle, mais ne fournit pas le texte ou la décision officielle permettant d’en certifier les modalités. Ce point doit être vérifié avant une audition disciplinaire. |
| **6** | **DRH : préparer la saisine du conseil de discipline compétent**, si une sanction du deuxième groupe reste envisagée. | Contrôler le rattachement, la composition, les éventuelles règles spéciales et les pièces de saisine. Le président convoque le conseil ; l’autorité investie du pouvoir disciplinaire ne peut y siéger. |
| **7** | **Président du conseil : convoquer l’agent et tenir la séance.** | Convocation par lettre recommandée avec avis de réception **au moins quinze jours avant la réunion** ; possibilité d’observations écrites ou orales, de témoins et d’assistance. Conserver les preuves du respect du délai. |
| **8** | **Autorité territoriale : décider après l’avis et l’examen de la défense.** | Avis communiqué sans délai à l’agent et à l’autorité ; décision motivée en droit et en fait. Documenter pourquoi la sanction retenue correspond aux faits établis ; ne pas reprendre automatiquement les cinq jours. |
| **9** | **DRH : sécuriser puis notifier la décision.** | Contrôler la date d’effet, la notification traçable, les voies et délais de recours, puis les conséquences administratives et de paie. Les sources officielles relatives aux recours et à ces effets ne figurent pas dans le dossier : les compléter avant exécution. |

Les garanties des étapes 4, 6, 7 et 8 sont soutenues par les extraits officiels du décret disciplinaire fournis : [information et préparation de la défense](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836), [convocation du conseil et exclusion de l’autorité disciplinaire](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222), [convocation et droits devant le conseil](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372226), [avis et décision](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042650806). Toutes ces versions couvrent le 11 octobre 2026.

La motivation doit être **écrite et comporter les considérations de droit et de fait** fondant la sanction : [CRPA, article L. 211-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [article L. 211-5](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions applicables depuis le 1er janvier 2016.

**Deux contrôles à conserver avant notification**

- **Recours :** distinguer le conseil de discipline préalable de l’ancienne instance de recours. Le corpus métier signale la suppression de cette dernière, mais les sources officielles de suppression et de transition manquent. Vérifier les recours actuels ; ne pas reprendre un ancien modèle.
- **Transmission préfectorale :** pour une commune, la liste actuelle de [l’article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) ne prévoit pas de catégorie imposant la transmission des sanctions disciplinaires. Contrôler séparément la convention locale et une éventuelle demande du préfet, qui peut [demander communication d’un acte hors liste](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556).

**Confiance : stable** sur le classement des cinq jours, le conseil préalable et les garanties citées. **La décision individuelle reste non tranchable**, faute de faits et de dates. Le risque principal serait de sanctionner sur des soupçons insuffisamment étayés ou avant l’achèvement des garanties de défense. Limiter enfin la circulation du dossier aux personnes qui doivent le traiter.
