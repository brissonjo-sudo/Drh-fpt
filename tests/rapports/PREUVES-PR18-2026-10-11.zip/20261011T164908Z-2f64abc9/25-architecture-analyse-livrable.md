# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**La nomination est possible sous conditions, mais la situation individuelle reste non tranchable avec les informations fournies.** Le projet ci-dessous conserve les champs manquants ; il doit être complété et contrôlé avant signature.

Analyse au **11 octobre 2026**, fondée exclusivement sur les extraits officiels archivés dans le corpus. Aucune consultation supplémentaire n’a été réalisée.

**Les conditions de la nomination**

L’avancement de grade et la nomination ne constituent pas deux droits automatiques successifs : l’inscription au tableau permet à l’autorité territoriale de prononcer l’avancement, sous les conditions suivantes :

- **Conditions statutaires remplies** pour le grade cible : grade actuel, échelon, ancienneté, services et, le cas échéant, examen professionnel. Le statut particulier du cadre d’emplois n’est pas fourni : l’éligibilité reste à vérifier.
- **Inscription au tableau annuel d’avancement**, avec respect de son ordre pour les nominations.
- **Respect du nombre maximal de promotions** résultant du taux fixé par l’assemblée délibérante après avis du comité social territorial (CST). Le texte fourni exclut de ce mécanisme le cadre d’emplois des agents de police municipale : si l’agent en relève, vérifier son régime propre.
- **Prise en compte des lignes directrices de gestion (LDG)**, sans disparition du pouvoir d’appréciation de l’autorité territoriale.
- **Acceptation par l’agent de l’emploi assigné dans son nouveau grade**.

Ces règles sont établies par les extraits du Code général de la fonction publique (CGFP), dans leurs versions applicables au 11 octobre 2026 :

| Règle et fonction juridique | Trace officielle fournie |
|---|---|
| Modalités d’avancement et appréciation professionnelle — conditions | [CGFP, identifiant 000044425506](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), version depuis le 01/03/2022 |
| Taux de promotion, assemblée et avis du CST — plafond et compétence | [CGFP, identifiant 000044425500](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), version depuis le 01/03/2022 |
| Décision de l’autorité territoriale et ordre du tableau — compétence et procédure | [CGFP, identifiant 000044425498](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), version depuis le 01/03/2022 |
| Acceptation de l’emploi — condition de nomination | [CGFP, identifiant 000044425496](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496), version depuis le 01/03/2022 |
| Orientations et critères des LDG — cadre d’appréciation | [CGFP, identifiant 000054076251](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251), version depuis le 01/08/2026 |

Les consultations archivées de ces fiches datent du **11/10/2026**. Les numéros d’articles absents des extraits ne sont pas reconstitués.

**J’en déduis que** l’agent peut être nommé si son éligibilité, son inscription, son rang, la possibilité de promotion et son acceptation de l’emploi sont établis. La nomination envisagée relève de l’avancement dans le même cadre d’emplois ; un changement de cadre d’emplois demanderait une autre analyse.

**Les contrôles à terminer**

La direction des ressources humaines (DRH) doit réunir, avant présentation à l’autorité territoriale :

1. Le statut de l’agent, son cadre d’emplois, ses grades actuel et cible, sa quotité et la date d’effet souhaitée.
2. Le statut particulier applicable et une fiche établissant l’éligibilité.
3. Le tableau annuel, son rang, les LDG et, lorsque ce mécanisme s’applique, la délibération fixant le taux ainsi que le calcul des promotions disponibles.
4. Les pièces relatives à l’emploi d’affectation, à son adéquation au nouveau grade et à son acceptation par l’agent.
5. Une simulation de classement vérifiée : échelon, ancienneté conservée et indices. Les règles de classement et les grilles ne figurent pas dans les sources fournies.

Le corpus métier signale la suppression de la consultation préalable de la **commission administrative paritaire (CAP)** pour l’avancement. Toutefois, aucun extrait officiel relatif à sa compétence n’est fourni : ce point reste à confirmer. Aucun avis CAP n’est donc présumé dans le projet. La procédure d’adoption des LDG reste également à contrôler sur ses sources propres.

La compétence du signataire et son éventuelle délégation doivent être documentées. Si l’employeur est un établissement plutôt qu’une commune, les règles de transmission propres à cet employeur doivent être vérifiées.

**Projet d’arrêté — document de préparation, à compléter avant signature**

> **[COMMUNE / ÉTABLISSEMENT]**  
> **Arrêté n° [référence] portant nomination par avancement de grade de [identité de l’agent]**
>
> Le/La [Maire / Président·e] de [employeur],
>
> Vu le Code général de la fonction publique, notamment ses dispositions relatives à l’avancement de grade des fonctionnaires territoriaux [numéros d’articles à relever sur les fiches officielles] ;
>
> Vu [texte portant statut particulier du cadre d’emplois], dans sa version applicable au [date d’effet], notamment [dispositions d’accès au grade et de classement — à vérifier] ;
>
> Vu les lignes directrices de gestion applicables à la campagne [année], arrêtées le [date] ;
>
> Vu [si applicable] la délibération n° [référence] du [date] fixant le taux de promotion au grade de [grade cible], après avis du comité social territorial du [date] ;
>
> Vu le tableau annuel d’avancement au grade de [grade cible] établi le [date] pour l’année [année], sur lequel [identité] figure au rang [rang] ;
>
> Vu l’arrêté n° [référence] du [date] fixant la situation administrative actuelle de l’agent ;
>
> Vu [acte et pièce établissant l’existence de l’emploi correspondant au grade cible] ;
>
> Vu l’acceptation par l’agent, le [date], de l’emploi de [emploi] ;
>
> [Si nécessaire : Vu la délégation de signature régulièrement applicable, référence et date à vérifier ;]
>
> Considérant que [identité], fonctionnaire titulaire du grade de [grade actuel], remplit les conditions statutaires d’accès au grade de [grade cible], ainsi qu’il ressort de [pièces et éléments vérifiés] ;
>
> Considérant que la nomination respecte l’ordre du tableau annuel d’avancement ;
>
> Considérant [si applicable] qu’une possibilité de promotion demeure disponible au regard du taux fixé et des promotions déjà prononcées ;
>
> Considérant l’appréciation de la valeur professionnelle et des acquis de l’expérience de l’agent au regard des critères applicables [éléments factuels pertinents] ;
>
> **ARRÊTE**
>
> **Article 1 — Nomination**  
> [Identité] est nommé·e, par avancement de grade, au grade de [grade cible], au sein du cadre d’emplois de [cadre d’emplois], à compter du [date d’effet contrôlée].
>
> **Article 2 — Classement**  
> À cette date, l’agent est classé au [échelon], avec une ancienneté conservée de [durée], correspondant aux indices brut [indice] et majoré [indice], conformément à [disposition de classement vérifiée].
>
> **Article 3 — Affectation**  
> L’agent est affecté à l’emploi de [emploi], au sein de [service], à [temps complet / temps non complet : durée de l’emploi].  
> [Le cas échéant : préciser séparément l’autorisation de temps partiel applicable.]
>
> **Article 4 — Exécution et notification**  
> [Responsables désignés] sont chargés de l’exécution du présent arrêté, chacun pour ce qui le concerne. Celui-ci est notifié à l’agent et versé à son dossier individuel.
>
> **Article 5 — Transmission et publicité**  
> Le présent arrêté est transmis au représentant de l’État suivant le régime applicable à [employeur].  
> [Pour une commune : transmission dans les quinze jours suivant la signature.]  
> [Formalités de publicité complémentaires à préciser après vérification.]
>
> **Article 6 — Recours**  
> Le présent arrêté peut faire l’objet d’un recours devant le tribunal administratif de [juridiction territorialement compétente à vérifier], dans un délai de deux mois à compter de sa notification.  
> [Modalités de saisine à compléter après vérification.]
>
> Fait à [lieu], le [date de signature].  
> [Qualité, nom et signature de l’autorité compétente]

**Sécurisation du projet**

- **Date d’effet :** le CGFP autorise une date d’effet antérieure au caractère exécutoire de la décision. Cela ne suffit pas à valider toute rétroactivité : contrôler l’éligibilité, le tableau, le classement et les autres conditions à la date retenue. Source : [CGFP, identifiant 000044425494](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425494), version depuis le 01/03/2022, consultation archivée le 11/10/2026.
- **Motivation :** une nomination favorable n’est pas automatiquement soumise à l’obligation de motivation des décisions individuelles défavorables. Les considérants proposés documentent néanmoins ses conditions. Les sources fournies imposent, lorsque la motivation est requise, des considérations écrites de droit et de fait : [CRPA, identifiant 000031367505](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [000031367513](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le 01/01/2016, consultations archivées le 11/10/2026.
- **Contrôle de légalité :** pour une commune, la nomination relève de la transmission prévue par l’article L. 2131-2 du Code général des collectivités territoriales, avec un délai de quinze jours suivant la signature. Les modalités électroniques et la publicité complémentaire restent à contrôler. Source : [fiche officielle fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), version depuis le 01/07/2022, consultation archivée le 11/10/2026.
- **Recours :** les extraits du Code de justice administrative établissent le délai ordinaire de deux mois et exigent la mention des voies et délais dans la notification pour rendre ce délai opposable au destinataire. Cela ne supprime pas les droits éventuels des tiers. Sources : [identifiant 000039807005](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le 01/01/2020, et [000006449946](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le 01/01/2001 ; consultations archivées le 11/10/2026.

**Recommandation :** faire compléter le dossier et le classement par la DRH, puis contrôler l’arrêté avant signature, notification et mise en paie. Limiter les données personnelles aux informations nécessaires.

**Confiance : stable sur les règles générales documentées ; à vérifier sur l’éligibilité, le classement, les pièces locales et les formalités manquantes. La nomination individuelle reste non tranchable.**
