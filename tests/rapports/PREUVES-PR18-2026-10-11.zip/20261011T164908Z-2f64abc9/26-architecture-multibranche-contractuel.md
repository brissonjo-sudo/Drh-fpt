# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne donne pas au contractuel en CDI les droits de carrière d’un fonctionnaire titulaire.** Sa demande doit être examinée comme une demande de réévaluation de sa rémunération, en tenant compte de son expérience.

Cette analyse porte sur un **CDI de droit public dans la fonction publique territoriale**, au **11 octobre 2026**, à partir des consultations officielles archivées fournies.

**1. Ce qu’il peut demander**

Les textes prévoient que l’autorité territoriale fixe la rémunération en tenant compte notamment des fonctions, des qualifications et de l’expérience de l’agent. Ils permettent également de prendre en compte les résultats professionnels.

J’en déduis que :

- **L’ancienneté peut être valorisée comme expérience professionnelle**, mais ces dispositions n’imposent pas la reprise intégrale de tous les services selon les règles de classement d’un fonctionnaire.
- **L’indice constitue une référence de rémunération** : il ne confère pas, à lui seul, un grade ni un droit à l’avancement statutaire.
- Une évolution de rémunération reste envisageable, notamment si l’expérience, les responsabilités ou les résultats professionnels la justifient. Il faut aussi examiner les engagements contenus dans le contrat et ses avenants.

Sources — fonction juridique : **fixation et évolution de la rémunération** :

- [Code général de la fonction publique, disposition relative à la rémunération des contractuels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), version en vigueur depuis le **1er mars 2022**, consultation archivée du **11 octobre 2026**.
- [Décret du 15 février 1988, disposition relative à la rémunération](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), version en vigueur depuis le **1er juillet 2026**, consultation archivée du **11 octobre 2026**.

**2. La réévaluation est obligatoire ; l’augmentation n’est pas automatique**

Pour un **CDI**, la rémunération doit faire l’objet d’une **réévaluation au moins tous les trois ans**, notamment au vu des entretiens professionnels ou de l’évolution des fonctions. Cette obligation s’applique directement aux CDI : elle ne dépend pas de la condition particulière prévue pour certains contrats à durée déterminée.

**Réévaluer signifie réexaminer la rémunération**, sans garantir une augmentation ni un passage automatique à l’indice suivant. Si l’échéance est dépassée, l’employeur doit procéder à cet examen ; cela ne permet pas de calculer d’office un rappel de salaire.

Source : disposition du décret précitée, version du **1er juillet 2026** — fonction juridique : **obligation de réévaluation**.

**État de décision :**

- **Avancement de grade comme un titulaire : impossible en l’état du statut contractuel.**
- **Valorisation de l’expérience dans la rémunération : possible sous conditions.**
- **Droit individuel à une reprise déterminée ou à un montant précis : non tranchable sans les pièces contractuelles et locales.**

**3. Marche à suivre**

| Étape | Responsable | Action et preuve attendue |
|---|---|---|
| Examiner les droits existants | Direction des ressources humaines (DRH) | Lire le contrat, les avenants, le fondement du recrutement et le cadre local de rémunération ; identifier les clauses relatives à l’ancienneté et à l’évolution salariale. |
| Reconstituer la situation | DRH et agent | Réunir les justificatifs des services antérieurs, les fonctions réellement exercées, les qualifications, l’historique salarial et la date de la dernière réévaluation. |
| Apprécier l’évolution professionnelle | Supérieur hiérarchique direct | S’appuyer sur la fiche de poste et les comptes rendus d’entretien ; documenter les résultats et l’évolution des responsabilités. |
| Arbitrer la rémunération | Autorité territoriale | Décider d’un maintien ou d’une évolution sur des critères explicités ; conserver la trace du réexamen et répondre à la demande de l’agent. |
| Mettre en œuvre, si évolution | DRH et paie | Vérifier la formalisation contractuelle nécessaire, la date d’effet et les paramètres de paie avant application. |

L’entretien professionnel annuel est conduit par le **supérieur hiérarchique direct** ; il éclaire l’arbitrage, tandis que la rémunération est fixée par l’**autorité territoriale**.  
Source — fonction juridique : **évaluation professionnelle** : [décret du 15 février 1988, disposition relative à l’entretien](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), version depuis le **1er janvier 2023**, consultation archivée du **11 octobre 2026**.

**Pour trancher son droit individuel, quelles sont les clauses de rémunération du contrat et des avenants, la date de la dernière réévaluation et les règles locales applicables ?**

Avant tout chiffrage indiciaire, il faudra vérifier l’**indice majoré**, la **quotité de travail** et la **valeur du point à la date d’effet**. Le dossier fourni ne permet pas de fixer un montant, une rétroactivité ou de rédiger une décision individuelle définitive.

**Confiance : stable pour les critères de rémunération et l’obligation de réévaluation ; à vérifier pour les droits contractuels particuliers et leur mise en œuvre.**
