# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non. Une exclusion temporaire de fonctions de 5 jours infligée à un fonctionnaire communal n’est pas obligatoirement transmissible au titre de l’article L. 2131-2 du CGCT, dans sa rédaction applicable au 11 octobre 2026.**

La liste actuelle ne comprend plus les sanctions disciplinaires. Son 5° vise certaines décisions de nomination, de recrutement et de licenciement ; une exclusion disciplinaire n’entre pas dans ces catégories.  
Source : [art. L. 2131-2 CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), version en vigueur depuis le **1er juillet 2022**, consultation officielle archivée fournie du **11 octobre 2026**.

Deux distinctions utiles :

- **Ancienne rédaction** : au 1er janvier 2004, cet article mentionnait les « sanctions soumises à l’avis du conseil de discipline ». Cette ancienne liste ne doit pas être appliquée à une sanction actuelle. [Source historique fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006390079).
- **Demande du préfet** : l’absence de transmission obligatoire n’empêche pas le représentant de l’État de demander communication de l’acte. [Source officielle fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), version depuis le 1er juillet 2022.

**En pratique :** vérifier l’existence d’une demande préfectorale et les modalités locales de télétransmission, sans les confondre avec l’obligation légale de transmission.

**Confiance : stable**, sur les extraits officiels archivés du corpus, pour un acte actuel.
