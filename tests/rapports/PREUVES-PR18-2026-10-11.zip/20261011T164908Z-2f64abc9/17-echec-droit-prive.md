# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non : la présomption de démission créée en 2022 ne s’applique pas à votre agent titulaire.** Elle concerne les salariés de droit privé, y compris ceux employés par une personne publique. Votre agent relève du régime de la fonction publique.

**Décision : impossible d’utiliser cette présomption.** La voie à examiner est le **licenciement pour abandon de poste, emportant radiation des cadres**, prévu par l’article L. 553-1, 1° du Code général de la fonction publique. Plusieurs semaines d’absence sans justificatif ne permettent pas, à elles seules, de prononcer cette mesure.

Pour cette voie, le Conseil d’État impose une **mise en demeure préalable** réunissant quatre conditions :

- être écrite ;
- être notifiée à l’agent ;
- fixer un délai de reprise du service ;
- avertir explicitement du risque de **radiation des cadres sans procédure disciplinaire préalable**.

L’arrêt fourni a annulé une radiation parce que cet avertissement manquait. Cette voie se distingue donc d’une sanction disciplinaire : elle ne comporte pas de procédure disciplinaire préalable, ni de conseil de discipline ou de communication du dossier **au titre des garanties disciplinaires**.

**Pour votre dossier, la radiation reste non tranchable en l’état.** La DRH doit d’abord réunir les dates d’absence, les obligations de service, les échanges avec l’agent et les éventuelles pièces justifiant son absence ou expliquant son impossibilité de reprendre. Elle doit ensuite contrôler la mise en demeure et sa preuve de notification, puis examiner toute réponse avant de proposer une décision à l’autorité territoriale.

Avant signature, restent également à vérifier : compétence du signataire, motivation, date d’effet, notification, voies et délais de recours et régime de transmission au contrôle de légalité. Les extraits officiels fournis ne permettent pas de certifier ces points. **Ne fixez pas automatiquement la radiation au premier jour d’absence.**

**Une mise en demeure a-t-elle déjà été notifiée, avec quelle date de reprise et quel avertissement, et l’agent a-t-il répondu ?**

Sources : consultations officielles archivées dans le corpus le **11 octobre 2026** :

- [Code du travail — champ limité au personnel de droit privé](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006900781), version depuis le 1er mai 2008 ; [présomption de démission](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104), version depuis le 23 décembre 2022.
- [CGFP, article L. 553-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184), version depuis le 1er mars 2022 — fondement du licenciement.
- [CE, Section, 11 décembre 1998, nos 147511 et 147512, publié au Lebon](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335) — garanties de la mise en demeure.

**Confiance : stable sur l’exclusion de la présomption privée ; qualification individuelle d’abandon de poste à établir.**
