# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**L’indemnité de feu est fixée à 25 % du traitement soumis à retenue pour pension.** Son montant en euros varie donc selon le traitement de chaque sapeur-pompier professionnel.

Le fondement est le **décret n° 90-850 du 25 septembre 1990**, dans l’[extrait officiel fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025), version en vigueur depuis le **26 juillet 2020**, consultation archivée du **11 octobre 2026** :

> « Les sapeurs-pompiers professionnels peuvent percevoir […] une indemnité de feu d’un taux de 25 % du traitement soumis à retenue pour pension. »

Le calcul est donc :

**Indemnité mensuelle = traitement mensuel soumis à retenue pour pension × 25 %.**

L’assiette correspond au traitement indiqué par le texte ; le taux ne s’applique pas à l’ensemble de la rémunération brute.

**Montant exact en euros : non tranchable en l’état.** Pour le déterminer, il faut connaître le mois de paie et l’assiette mensuelle de chaque agent. Si cette assiette doit être reconstituée, l’**indice majoré**, la **valeur du point d’indice à la date utile** et les éléments inclus doivent être vérifiés.

Le décret renvoie également à l’**article 17 de la loi n° 90-1067 du 28 novembre 1990** : cet article n’est pas fourni, donc ses conditions ne peuvent pas être confirmées ici.

**Confiance élevée sur le taux et l’assiette cités**, d’après la trace officielle fournie.

Pour quel mois de paie souhaitez-vous le calcul, et quelle est l’assiette mensuelle soumise à retenue pour pension des agents concernés ?
