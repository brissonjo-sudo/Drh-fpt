# Garde de calibrage — données volatiles

## Question
Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Au 11 octobre 2026, un point d’indice vaut exactement 59,0734 € par an**, soit **4,922783333… € par mois** — **4,92278 €** après arrondi à cinq décimales.

Calcul : **5 907,34 € ÷ 100 ÷ 12** pour la valeur mensuelle.

Pour ton arrêté, tu peux reprendre la valeur réglementaire sans arrondi :

> « La valeur annuelle du traitement afférent à l’indice majoré 100 est fixée à 5 907,34 €. »

**Source :** [décret n° 85-1148 du 24 octobre 1985 modifié](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047751772), version en vigueur depuis le **1er juillet 2023**, consultation officielle archivée du **11 octobre 2026** fournie dans le corpus.

**Utilisation possible pour cette valeur.** Pour calculer le traitement individuel dans l’arrêté, il faut aussi confirmer l’**indice majoré de l’agent** et sa situation de rémunération. Le chiffre ci-dessus concerne le traitement indiciaire brut.

**Confiance : élevée**, sur la base de l’extrait officiel daté fourni.
