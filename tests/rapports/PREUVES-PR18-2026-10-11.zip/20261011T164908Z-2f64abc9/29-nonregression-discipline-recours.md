# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non, pour une sanction nouvelle de 2026 relevant du régime des fonctionnaires territoriaux : le conseil de discipline de recours a été supprimé.** L’agent peut contester la sanction devant le tribunal administratif.

Cette conclusion repose sur les extraits officiels archivés fournis, consultés le **11 octobre 2026**.

- **L’ancienne instance de recours est abrogée** : le décret du 8 décembre 2020 supprime le chapitre II du décret du 18 septembre 1989. La [structure consolidée en 2026](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000335719/2026-10-11) confirme cette abrogation.
- **L’exception transitoire concerne les recours anciens**, déjà en cours à l’entrée en vigueur de la loi du 6 août 2019 et non achevés. Elle ne permet pas d’engager un recours contre une sanction nouvelle de 2026. Voir la [disposition transitoire fournie](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000042625452).
- **Le conseil de discipline préalable demeure distinct** : une exclusion de cinq jours appartient au deuxième groupe, selon l’[article L. 533-1 du Code général de la fonction publique](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388). Elle exige donc sa consultation préalable ; l’avis et la sanction doivent être motivés, selon la [disposition officielle fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422).

**Dans la notification**, indiquez le tribunal administratif compétent et le délai de **deux mois à compter de la notification**. Le [Code de justice administrative](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005) fixe ce délai ; son [opposabilité exige la mention des voies et délais de recours dans la notification](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946).

Projet de clause, à compléter après identification du tribunal compétent :

> La présente décision peut faire l’objet d’un recours contentieux devant le tribunal administratif de **[ville]**, dans un délai de deux mois à compter de sa notification.

**Ne mentionnez pas le conseil de discipline de recours.** Pour ajouter un recours gracieux auprès de l’autorité territoriale, il faut vérifier son régime et ses effets sur le délai contentieux : les extraits officiels fournis ne documentent pas ces points. Je ne les présente donc pas comme établis.

**Décision : notification possible sous conditions.** La DRH doit confirmer le statut de l’agent, identifier le tribunal compétent, contrôler l’avis préalable et la motivation, puis conserver la preuve de notification. Cette réponse ne valide pas l’ensemble de la procédure disciplinaire.

Pour finaliser : **l’agent est-il titulaire, stagiaire ou contractuel ?** Les sources fournies ne permettent pas de transposer automatiquement cette clause et cette procédure aux autres statuts.

**Confiance : stable** sur la suppression de l’instance de recours et le délai contentieux ; **à vérifier** pour la finalisation individuelle et le recours gracieux.
