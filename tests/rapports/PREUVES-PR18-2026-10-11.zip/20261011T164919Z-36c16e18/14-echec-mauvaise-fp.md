# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Votre **CHU relève de la fonction publique hospitalière**, alors que le corpus fourni couvre uniquement la fonction publique territoriale. L’effectif de 900 agents ne change pas cette limite. Je ne peux donc pas appliquer à votre agent le régime territorial ni fournir les conditions, durées ou niveaux de rémunération du congé de longue maladie hospitalier.

**Décision : non tranchable avec ce corpus.** Les huit mois d’arrêt ne permettent pas, à eux seuls, de déterminer ici le congé applicable.

Pour préparer la vérification par votre service juridique ou votre référent statutaire :

- **Réunir les pièces** : décision de congé actuelle, date initiale de l’arrêt, prolongations, éventuelle demande de congé de longue maladie et avis médicaux déjà rendus. Ne transmettre les données médicales qu’aux interlocuteurs habilités.
- **Consulter les sources hospitalières** : dispositions du Code général de la fonction publique et textes propres aux congés de maladie des fonctionnaires hospitaliers, dans leur version applicable aux périodes concernées.
- **Faire contrôler** : conditions d’ouverture du congé, éventuelle prise en compte des mois déjà écoulés, durée des droits, rémunération, rôle de l’instance médicale et autorité compétente pour décider.

**Avant toute modification du congé ou de la paie**, obtenir cette vérification hospitalière : transposer le régime territorial risquerait de fausser les droits de l’agent.

**Niveau de confiance : abstention sur le régime demandé, hors périmètre du corpus.**
