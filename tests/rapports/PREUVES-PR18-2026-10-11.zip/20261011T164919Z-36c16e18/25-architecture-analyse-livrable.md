# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** La possibilité de nomination dépend de données individuelles, des décisions locales et des textes applicables qui ne sont pas vérifiés.

Le corpus interdit de livrer « aucun projet d’acte juridiquement engageant » sans cette vérification (*SKILL.md*, §3). Je fournis donc une **trame préparatoire de l’arrêté**, avec les champs et contrôles nécessaires. Elle ne constitue pas un acte à signer.

### Analyse : ce qui permettra de trancher

**Connu :** vous envisagez une nomination à la suite d’un avancement de grade. Aucun employeur, statut individuel, grade ou calendrier n’est précisé.

**Informations bloquantes à compléter :**

- **Employeur :** type de collectivité, effectif et éventuel statut particulier, pour confirmer le périmètre du corpus et le régime applicable.
- **Agent :** titulaire, stagiaire ou contractuel ; filière, cadre d’emplois, grades actuel et cible, échelon, ancienneté et services ; emploi à temps complet ou non complet, éventuel temps partiel.
- **Calendrier :** année du tableau d’avancement et date d’effet souhaitée.
- **Pièces locales :** tableau d’avancement, lignes directrices de gestion, délibération fixant le ratio promus-promouvables et situation de l’emploi envisagé.

Les références internes du dossier, le numéro de l’arrêté et les coordonnées du service gestionnaire sont **non bloquants** : ils peuvent rester en champs à compléter.

| Contrôle à faire vérifier | Pièces et sources nécessaires |
|---|---|
| Qualification du mouvement : avancement de grade, avancement d’échelon ou promotion interne | Situation administrative et décret statutaire du cadre d’emplois |
| Conditions d’accès au grade cible : ancienneté, services, éventuel examen et règles de classement | Dossier de carrière et textes officiels applicables à la date recherchée |
| Distinction entre éligibilité, inscription au tableau et nomination | Tableau annuel et dispositions applicables |
| Articulation du socle national avec les choix locaux | Code général de la fonction publique, décret statutaire, lignes directrices de gestion et délibération sur les ratios |
| Acteur compétent pour fixer le ratio, décider la nomination et signer ; rôle actuel de la commission administrative paritaire | Textes applicables, délégations et, si le circuit en dépend, affiliation au centre de gestion |
| Situation de l’emploi et conditions de mise en œuvre | Actes relatifs à l’emploi, pièces budgétaires et documents RH utiles |

**Recommandation :** préparer le dossier, puis faire contrôler ces points par le service carrière et le service juridique, avec l’appui du centre de gestion si pertinent. La preuve attendue est une fiche de validation associant chaque condition à sa pièce et à une source officielle dans sa version applicable. Aucun calendrier juridique ne peut être fixé ici.

### Trame préparatoire du projet d’arrêté

**Document de travail — validation juridique requise**

**[Collectivité / établissement]**  
**Référence : [à compléter]**

**Objet envisagé :** nomination de [identité de l’agent] au grade de [grade cible], à la suite d’un avancement de grade.

| Partie du futur arrêté | Contenu à préparer |
|---|---|
| **Signataire** | [Qualité du signataire] — compétence et éventuelle délégation à vérifier |
| **Visas nationaux** | [Dispositions du code et décret statutaire effectivement vérifiés] — références laissées ouvertes |
| **Pièces et décisions locales** | [Tableau d’avancement : année, date et référence] ; [délibération sur les ratios] ; [lignes directrices de gestion] ; [pièces relatives à l’emploi] |
| **Éléments justifiant la décision** | [Situation administrative] ; [conditions statutaires documentées] ; [inscription au tableau] ; [respect des paramètres locaux] |
| **Disposition de nomination à rédiger après validation** | [Grade cible], [cadre d’emplois], [date d’effet vérifiée] |
| **Disposition de classement à rédiger après validation** | [Échelon], [ancienneté conservée], [indices officiellement contrôlés] — aucun calcul fourni ici |
| **Mise en œuvre** | [Services destinataires], [modalités de notification], [publicité et transmission à vérifier] |
| **Recours** | [Mention à rédiger après contrôle des voies et délais applicables] |
| **Signature** | [Lieu], [date], [identité et qualité du signataire] |

**Avant signature ou paie :** contrôler la compétence, les conditions d’avancement, le tableau, le ratio, les règles de classement, la date d’effet, l’éventuelle motivation, les formalités et les recours. Limiter les données personnelles aux informations nécessaires.

**Risques résiduels :** nomination irrégulière, classement erroné ou formalités inadaptées. **Niveau de confiance : abstention sur la possibilité juridique de nomination et sur le contenu final de l’arrêté.**
