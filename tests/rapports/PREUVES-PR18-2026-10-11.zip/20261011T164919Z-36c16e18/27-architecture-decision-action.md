# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon « recherche-juridique » est indisponible : je peux préparer les contrôles, mais pas certifier une procédure disciplinaire exécutable.

**Décision : non tranchable en l’état.** L’agent est titulaire et une exclusion temporaire de **5 jours** est envisagée. Ces données ne permettent pas de confirmer juridiquement l’engagement de la procédure. Il reste notamment à vérifier les faits, leur chronologie, le régime applicable et les garanties procédurales.

**Ma recommandation : lancer immédiatement la préparation du dossier, puis faire valider juridiquement l’engagement formel.** Ne pas retenir dès maintenant les cinq jours comme sanction acquise : c’est une hypothèse à confronter aux éléments établis, aux observations de l’agent et au contrôle de proportionnalité.

Les informations à réunir sont :

- **Connues :** agent titulaire ; faits soupçonnés ; sanction envisagée.
- **Bloquantes pour conclure :** employeur et effectif — le corpus couvre les collectivités de plus de 350 agents —, cadre d’emplois et grade, faits précis et preuves, dates des faits et de leur connaissance effective par l’administration, éventuelles poursuites pénales, dates d’ouverture et de sanction envisagées. L’affiliation au centre de gestion est à préciser pour contrôler le circuit d’instance.
- **Non bloquantes pour préparer le dossier :** identité nominative et calendrier interne souhaité. Aucun nom n’est nécessaire ici ; ce calendrier ne peut pas remplacer les délais juridiques à vérifier.

Voici les **actions de préparation à lancer, dans l’ordre**. Ce tableau n’est pas une procédure disciplinaire validée.

| Ordre | Action et responsable | Contrôle et preuve attendue |
|---|---|---|
| 1 | **DRH et responsable du service :** constituer une chronologie et réunir rapports, pièces et témoignages disponibles. | Séparer faits établis, allégations et contradictions. Tracer la date de connaissance effective ; limiter les données personnelles aux éléments utiles. |
| 2 | **DRH :** qualifier le dossier statutaire et l’employeur. | Réunir situation administrative, cadre d’emplois, grade, affiliation au centre de gestion et éventuel régime particulier. Identifier le circuit à faire contrôler. |
| 3 | **Service juridique :** vérifier les sources officielles aux dates utiles. | Sur Légifrance : Code général de la fonction publique, textes de discipline territoriale et statut particulier. Contrôler prescription, incidence des poursuites pénales et dispositions transitoires. Conserver version, passage utile et conclusion. |
| 4 | **Service juridique et DRH :** contrôler la sanction envisagée et les acteurs. | Vérifier son classement dans l’échelle applicable au titulaire territorial, la nécessité d’un conseil de discipline préalable et la compétence de l’autorité territoriale signataire. Ne pas transposer l’échelle d’un contractuel ou celle de l’État. |
| 5 | **DRH, après validation juridique :** préparer les garanties de défense et le dossier d’instance éventuel. | Faire vérifier l’information de l’agent, l’accès au dossier intégral, l’assistance d’un conseil de son choix, le temps suffisant pour répondre et l’information sur le droit de se taire avant les observations. Contrôler les formalités de l’instance préalable si elle est requise. |
| 6 | **Autorité territoriale, avec la DRH :** réexaminer les suites après les observations et l’avis éventuellement requis. | Comparer faits retenus, éléments à décharge, gravité et proportionnalité. Selon le dossier validé : poursuivre, adapter la sanction envisagée ou abandonner la piste disciplinaire. |
| 7 | **Service juridique et DRH :** contrôler toute décision avant signature et notification. | Compétence et délégation, motivation en fait et en droit, date d’effet, conséquences administratives et financières, notification traçable, publicité éventuelle, voies et délais de recours. Aucun acte prêt à signer n’est fourni ici. |

Pour les recours, faire vérifier **la suppression de l’ancienne instance disciplinaire de recours et les éventuelles transitions**, en la distinguant du conseil préalable. Pour la transmission, confronter **la liste légale actuelle**, les anciennes versions, la convention locale de télétransmission et les éventuelles demandes du préfet : aucune obligation de transmission n’est certifiée ici.

Les textes nationaux et les documents locaux doivent être contrôlés séparément ; l’organisation interne ne suffit pas à valider les garanties statutaires.

**Risques résiduels :** faits insuffisamment établis, prescription, mauvais circuit, défaut de défense, sanction disproportionnée ou décision mal motivée. **Niveau de confiance : abstention sur la possibilité juridique d’engager et sur la sanction ; dossier de préparation uniquement.**
