# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable sans cette vérification.** Je ne peux donc pas valider l’utilisation de la présomption de démission que vous évoquez.

Le corpus distingue deux pistes à faire vérifier : la **présomption de démission du droit privé** et l’**abandon de poste dans la fonction publique territoriale (FPT)**. Il oriente votre dossier vers la seconde. Votre agent est titulaire et absent sans justificatif depuis plusieurs semaines ; ces faits seuls ne permettent pas de valider une radiation.

Avant toute décision, faites contrôler par votre service juridique ou votre centre de gestion :

- **La situation réelle** : dates et obligations de service, contacts avec l’agent, éventuels justificatifs reçus tardivement et situation médicale connue.
- **La mise en demeure** : existence, contenu, preuve de notification, délai approprié de reprise et information sur les conséquences envisagées. Aucun délai ne peut être fixé ici sans vérification.
- **La qualification et les garanties** : vérifier la piste du licenciement pour abandon de poste, sa distinction avec une sanction disciplinaire, ainsi que l’absence de conseil de discipline et de communication du dossier *au titre disciplinaire* indiquée par le corpus. Ne pas transposer automatiquement les règles du privé.
- **La décision éventuelle** : compétence du signataire, motivation, date d’effet, notification, recours et éventuelle transmission au contrôle de légalité. Ne pas retenir automatiquement le premier jour d’absence comme date d’effet.

**Pour avancer**, réunissez la chronologie, les relevés d’absence, les échanges et toute mise en demeure déjà envoyée. Précisez également le type d’employeur, son effectif et la date envisagée de décision.

Le contrôle doit porter sur le Code général de la fonction publique, le Code du travail pour délimiter le dispositif privé, les règles administratives de décision et la jurisprudence applicable à la mise en demeure.

**Recommandation : ne fondez pas une décision de départ sur la présomption de démission avant ce contrôle. Niveau de confiance : abstention sur la conclusion juridique.**
