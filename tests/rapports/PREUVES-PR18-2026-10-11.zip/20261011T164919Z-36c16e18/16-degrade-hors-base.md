# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable.** Je ne peux fournir ni montant exact, ni taux, ni référence réglementaire certifiée. Le corpus signale le régime spécifique des **sapeurs-pompiers professionnels**, mais ne contient pas le texte fixant leur indemnité de feu.

Pour répondre précisément, voici le dossier à faire contrôler par votre **service des ressources humaines ou de paie** :

- **Source officielle à consulter :** sur Légifrance, le texte réglementaire propre au régime indemnitaire des sapeurs-pompiers professionnels, notamment les dispositions relatives à l’indemnité de feu, dans leur version applicable à la période de paie.
- **Règles à confirmer :** bénéficiaires, taux, assiette, éventuelles limites et incidence de la quotité de travail. Distinguer les règles nationales des éventuels actes locaux pertinents.
- **Données à réunir :** employeur, période de paie, grade exact, échelon, quotité de travail et pièces de rémunération. Si l’assiette est indiciaire, contrôler l’**indice majoré** et la **valeur du point d’indice** à la date utile avant toute conversion en euros.

Le contrôle doit aboutir à une référence officielle traçable, au passage fixant l’indemnité et à un calcul rattaché à chaque situation individuelle. **En attendant, aucun chiffre issu de cette réponse ne doit être utilisé en paie.**

**Niveau de confiance : abstention sur le montant et son fondement juridique précis.**
