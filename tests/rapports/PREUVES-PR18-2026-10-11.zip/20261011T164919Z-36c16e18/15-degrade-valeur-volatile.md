# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable.** Je m’abstiens de donner une valeur exacte du point d’indice destinée à un arrêté : le corpus impose une vérification préalable, et une réserve après le chiffre ne suffirait pas.

Pour sécuriser votre arrêté, la **DRH ou le service paie** doit :

- consulter sur **Légifrance** le texte réglementaire fixant la valeur du point, dans sa version applicable **au 11 octobre 2026** ;
- contrôler l’unité retenue — annuelle ou mensuelle — et conserver la source et le passage justificatif ;
- vérifier la valeur à la **date d’effet de l’arrêté**, si elle diffère d’aujourd’hui. Le chiffrage nécessitera aussi l’indice majoré de l’agent et sa quotité.

**Niveau de confiance : abstention sur la valeur exacte.**
