# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Le corpus fournit les **pistes suivantes, à vérifier avant application** :

- **Formation plénière** : c’est la formation indiquée pour examiner l’imputabilité au service lorsqu’un avis du conseil médical est requis. La formation restreinte n’est pas celle indiquée pour cet objet.
- **Décision finale** : le corpus désigne l’**autorité territoriale** comme décisionnaire. Il faut distinguer l’avis du conseil médical de la décision d’imputabilité.

**État de décision : non tranchable quant à l’obligation de saisine dans votre dossier.** Le corpus précise qu’elle n’est pas systématique ; la seule mention d’un accident « contesté » ne suffit pas à établir le circuit applicable.

Pour lever ce point, le service RH devra réunir le statut exact du fonctionnaire, la date et les circonstances de l’accident, la déclaration, le certificat médical et les motifs de contestation. Il devra contrôler les dispositions du **Code général de la fonction publique** et les textes territoriaux relatifs au conseil médical et au congé pour invalidité temporaire imputable au service, dans leur version applicable aux faits.

**Niveau de confiance : abstention sur la validation juridique ; orientation documentaire issue du corpus.**
