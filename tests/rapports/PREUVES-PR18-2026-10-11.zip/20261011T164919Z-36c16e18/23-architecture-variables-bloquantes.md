# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** Le nom et le cadre d’emplois ne suffisent pas à apprécier une nomination au grade supérieur en 2026. Je m’abstiens donc de conclure sur l’éligibilité de cet agent.

Les informations connues orientent vers un **avancement de grade**. Il faudra vérifier que le grade visé appartient bien au même cadre d’emplois, pour distinguer cette voie d’une promotion interne.

Pour préparer l’examen du dossier, réunissez en une fois :

- **Situation de l’agent** : intitulé exact du cadre d’emplois, grade actuel, grade visé, statut — titulaire, stagiaire ou contractuel —, échelon et date d’accès à cet échelon.
- **Parcours** : état des services et ancienneté, éventuel examen professionnel obtenu et justificatif.
- **Calendrier** : date de nomination envisagée en 2026.
- **Cadre employeur** : type de collectivité et confirmation de son effectif supérieur à 350 agents. L’affiliation au centre de gestion sera à préciser si elle intervient dans le circuit concerné.

**Le nom de l’agent n’est pas nécessaire pour cette première analyse.**

La DRH pourra ensuite constituer ce dossier de contrôle, sans préjuger du résultat :

| Contrôle à faire vérifier | Pièce ou source attendue |
|---|---|
| Conditions nationales d’accès au grade et date à laquelle elles doivent être remplies | Décret statutaire particulier et Code général de la fonction publique, dans leurs versions applicables |
| Ratio promus-promouvables et rôle de l’assemblée délibérante | Délibération locale |
| Orientations de sélection | Lignes directrices de gestion et éléments d’appréciation professionnelle |
| Tableau annuel et distinction entre inscription et nomination | Projet de tableau et règles applicables |
| Rôle actuel de la commission administrative paritaire, compétence de nomination et formalités de l’acte | Sources officielles à contrôler avant décision |
| Possibilité concrète de nomination | Situation de l’emploi et pièces budgétaires |

**Recommandation : compléter d’abord la fiche individuelle, puis faire vérifier ensemble les conditions statutaires et le cadre local.** Ne considérez pas une inscription envisagée au tableau comme une nomination acquise.

Le risque principal est de retenir un agent sans avoir établi les conditions d’accès ou les possibilités locales de nomination. **Niveau de confiance : abstention sur l’éligibilité et la nomination ; dossier préparatoire uniquement.**
