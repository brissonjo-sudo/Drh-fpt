# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Votre commune compte environ **40 agents** : elle est hors du périmètre du corpus DRH fourni, limité aux collectivités de plus de 350 agents. Je ne peux donc pas vous donner une procédure juridiquement validée.

**État de décision : non tranchable en l’état.** Le premier contrôle consiste à identifier le **comité social territorial (CST) compétent** : vérifier le rattachement éventuel au CST placé auprès du **centre de gestion (CDG)**, ainsi que le seuil et les conditions d’un CST propre. Je ne certifie ici ni ce seuil ni ce rattachement.

Pour avancer, voici le **dossier de préparation**, sans valeur de procédure exécutable :

| Point à faire vérifier | Pièces ou informations utiles |
|---|---|
| Instance compétente et secrétariat à contacter | Effectif exact, affiliation au CDG, documents de rattachement |
| Nécessité et moment de la consultation | Objet du projet, agents concernés, date de mise en œuvre envisagée |
| Modalités de saisine et de séance | Règlement intérieur, calendrier, formulaire de saisine, pièces demandées ; délais, quorum et vote à contrôler |
| Suites de l’avis | Conditions d’une éventuelle nouvelle consultation, autorité compétente pour décider, acte à adopter et formalités applicables |

**Action recommandée :** demandez à votre gestionnaire RH de réunir ces éléments et d’obtenir du secrétariat pressenti une confirmation du rattachement et des modalités applicables. La vérification doit porter sur le **Code général de la fonction publique**, les textes réglementaires relatifs aux CST et, pour la décision finale, le **Code général des collectivités territoriales**, dans leur version applicable à la date du projet.

Il faudra distinguer le cadre national des modalités locales, puis contrôler les garanties de consultation et, selon l’acte final, la motivation, la publicité ou notification, la transmission et les recours. Limitez les données individuelles aux informations nécessaires.

**Quel projet souhaitez-vous soumettre au CST, à quelle date, et votre commune est-elle affiliée au CDG ?**

**Niveau de confiance : abstention sur la procédure juridique.** Le risque principal est de saisir une instance incompétente ou de décider avant d’avoir satisfait les consultations requises.
