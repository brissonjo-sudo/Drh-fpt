# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable sans cette vérification.** Le corpus oriente vers la **suppression de l’ancien conseil de discipline de recours**, mais cette piste doit être confirmée avant de répondre définitivement ou de finaliser la notification.

Pour votre dossier, voici les contrôles utiles :

- **Fait connu :** une exclusion temporaire de fonctions de 5 jours a été prononcée en 2026.
- **Variables bloquantes :** l’agent est-il titulaire, stagiaire ou contractuel ? Quelles sont les dates d’ouverture de la procédure et de la décision ? Ces éléments permettent de rechercher le régime disciplinaire applicable et d’écarter un éventuel régime transitoire.
- **Distinction essentielle à vérifier :** le conseil de discipline intervenant **avant la sanction** et l’ancien conseil de discipline **de recours** sont deux instances différentes. Le contrôle de la suppression du second ne dispense pas de contrôler la consultation préalable éventuellement requise pour cette sanction.

**Pour les voies à mentionner dans la notification**, faites vérifier par le service juridique :

| Point à contrôler | Résultat attendu avant envoi |
|---|---|
| Recours administratif éventuellement ouvert, notamment gracieux | Autorité destinataire, délai et effet éventuel sur le délai contentieux |
| Recours contentieux | Tribunal administratif compétent, délai applicable, point de départ et modalités de saisine |
| Ancien conseil de discipline de recours | Confirmation de sa suppression et de l’absence de disposition transitoire applicable au dossier |

Je ne fournis donc **ni délai chiffré ni clause de recours prête à envoyer**.

Le contrôle documentaire doit porter sur le **Code général de la fonction publique**, le texte disciplinaire propre au statut de l’agent et, si celui-ci est fonctionnaire territorial, le **décret n° 89-677 — référence à confirmer en version consolidée**. Il faut confronter sa structure actuelle aux textes de suppression et de transition, en distinguant le chapitre relatif à l’ancien recours du conseil préalable.

**Action recommandée :** transmettre au service juridique la décision, les dates de procédure, le statut de l’agent et le projet de notification ; obtenir une validation des voies et délais avant envoi. Faire également contrôler la motivation, les garanties de défense et les formalités de notification. Pour la transmission au contrôle de légalité, vérifier séparément la liste légale actuelle, la convention locale et les éventuelles demandes du préfet.

**Risque principal :** mentionner une instance supprimée ou des voies et délais inadaptés. **Niveau de confiance : abstention sur la conclusion juridique et la rédaction exécutable.**
