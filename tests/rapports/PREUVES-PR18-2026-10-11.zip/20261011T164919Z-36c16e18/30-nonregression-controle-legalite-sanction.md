# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** Je ne peux certifier ni l’obligation ni l’absence d’obligation de transmission de cette exclusion de **5 jours**, donnée de votre question.

Le corpus invite à **ne pas appliquer automatiquement une ancienne liste d’actes transmissibles** à une sanction actuelle. Il distingue la liste légale applicable, les anciennes versions, la convention locale de télétransmission et les éventuelles demandes du préfet. Ce sont des pistes de contrôle, pas une vérification officielle.

Pour trancher, la DRH ou le service juridique doit :

- relever la **date de la sanction** et disposer de l’arrêté ;
- consulter sur Légifrance l’**article L. 2131-2 du Code général des collectivités territoriales (CGCT), à confirmer en version consolidée applicable à cette date**, puis contrôler si cet acte entre dans une catégorie légalement transmissible ;
- examiner séparément la convention locale de télétransmission et une éventuelle demande préfectorale, sans les confondre avec le fondement légal demandé.

Le contrôle doit porter sur **la transmission**, distinctement de la question d’un éventuel avis préalable du conseil de discipline.

**Risque principal :** décider à partir d’une version ancienne du texte.  
**Niveau de confiance : abstention sur la conclusion juridique**, conformément au mode dégradé imposé.
