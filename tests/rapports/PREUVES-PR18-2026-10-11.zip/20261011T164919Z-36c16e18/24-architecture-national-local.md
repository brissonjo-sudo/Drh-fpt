# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je peux préparer le contrôle de votre organisation, mais pas certifier les règles applicables ni valider son maintien.

**Décision : non tranchable en l’état.** L’ancienneté de votre cycle ne permet, à elle seule, de conclure ni à sa conformité actuelle ni à la nécessité de le modifier. L’analyse doit porter sur les textes applicables **au 11 octobre 2026** et sur votre cadre local.

Les informations se répartissent ainsi :

- **Connues :** le service fonctionne selon un cycle annualisé établi depuis plusieurs années.
- **Non bloquantes à ce stade :** le logiciel utilisé et l’organisation interne du contrôle des horaires.
- **Bloquantes :** le type d’employeur et son effectif, les statuts et quotités des agents, la délibération applicable, le contenu précis du cycle et les éventuelles sujétions invoquées.

**Pour déterminer les règles à appliquer aujourd’hui, voici les contrôles à préparer :**

| Point à contrôler | Vérification attendue |
|---|---|
| **Cadre national** | Confirmer la durée annuelle de référence, son champ d’application et les conséquences des réformes sur les anciens régimes plus favorables. Aucun volume horaire n’est certifié ici. |
| **Garanties de travail et de repos** | Contrôler les limites quotidiennes et hebdomadaires, les pauses, l’amplitude et les repos, y compris pendant les périodes de forte activité. Un total annuel ne suffit pas à examiner ces garanties. |
| **Organisation locale** | Vérifier la délibération et ses annexes : agents concernés, cycle, annualisation, périodes hautes et basses, modalités de décompte et modifications intervenues. |
| **Sujétions particulières** | Examiner si les contraintes invoquées — nuit, dimanche, horaires décalés, pénibilité ou danger — peuvent justifier un aménagement, sur quel fondement et avec quelles preuves. |
| **Décompte réel** | Rapprocher les plannings des heures réalisées ; contrôler le traitement des congés, absences, jours fériés, récupérations et de la journée de solidarité. |
| **Acteurs et régimes** | Faire vérifier la compétence de l’autorité territoriale et de l’assemblée délibérante, ainsi que la consultation du comité social territorial (CST). Identifier les éventuels régimes particuliers et éviter toute transposition automatique des règles de l’État. |

**Votre organisation actuelle reste une option à examiner**, sous réserve de ce contrôle. Deux scénarios doivent être étudiés :

- Si le cadre local, le décompte annuel et les garanties sont reconnus conformes après vérification, le maintien pourra être envisagé.
- Si des écarts sont identifiés, il faudra déterminer s’ils appellent une correction ciblée ou une révision du cycle, puis vérifier les actes et consultations nécessaires.

La **Direction des ressources humaines (DRH)** peut d’abord réunir la délibération initiale, ses modifications, les avis du CST, le règlement du temps de travail, un planning annuel représentatif et les relevés d’heures. Le service juridique devra ensuite comparer ces pièces au Code général de la fonction publique et aux textes réglementaires officiels relatifs au temps de travail territorial, dans leur version applicable. Le résultat attendu est un tableau écrit des conformités, écarts et corrections proposées, avant toute validation.

Les risques à examiner sont notamment un décompte annuel erroné, des repos insuffisants ou une organisation locale devenue incompatible avec les textes. **Niveau de confiance juridique : abstention.**

Pour préciser ce dossier : **quel est votre type de collectivité, son effectif, et disposez-vous de la délibération ainsi que du détail du cycle actuel ?**
