# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je fournis un cadrage et les contrôles à réaliser, sans certifier de droit à reprise d’ancienneté ni de procédure d’avancement.

**Décision : non tranchable en l’état.** Il faut examiner séparément la demande de rémunération et la demande de carrière.

L’agent est en contrat à durée indéterminée (CDI), avec une rémunération référencée à un indice. L’analyse ci-dessous suppose un contrat de droit public territorial ; l’employeur, son effectif et le régime exact restent à confirmer.

**Les deux demandes à distinguer**

| Demande | Piste du corpus à vérifier officiellement |
|---|---|
| **Reprise de toute l’ancienneté** | Examiner si les services antérieurs peuvent être valorisés dans la rémunération au regard du contrat, du cadre local et des règles applicables. Distinguer cette valorisation d’un classement statutaire de fonctionnaire. Le caractère intégral de la reprise ne peut pas être reconnu ici. |
| **Avancement de grade comme un titulaire** | Contrôler la distinction entre indice de rémunération et détention d’un grade. Le corpus décrit une évolution contractuelle par décision expresse, distincte de l’avancement statutaire du titulaire. Cette distinction doit être confirmée avant de répondre juridiquement à l’agent. |

Pour la comparaison avec le titulaire, les contrôles portent sur les conditions du statut particulier, le tableau d’avancement, le ratio local, les lignes directrices de gestion et le rôle actuel de la commission administrative paritaire. **Ces mécanismes ne doivent pas être transposés au contractuel sans fondement vérifié.**

Il faut aussi contrôler si une **réévaluation périodique de sa rémunération** est requise : vérifier son champ, sa périodicité et les critères applicables, en distinguant l’examen de la rémunération d’une augmentation ou d’une reprise intégrale d’ancienneté.

**Marche à suivre — dossier de préparation**

1. **La DRH réunit les pièces déterminantes** : contrat et avenants, fondement du recrutement, clauses de rémunération, dernière réévaluation, fonctions exercées, catégorie de référence, quotité de travail et cadre local de rémunération. L’agent fournit ses justificatifs de services antérieurs : employeurs, dates, interruptions, fonctions et catégories. Préciser la date d’effet demandée.

2. **Le service juridique vérifie les sources officielles** : Code général de la fonction publique et dispositions réglementaires applicables aux contractuels territoriaux, en tenant compte des éventuelles recodifications. Il contrôle séparément la portée de la référence indiciaire, la valorisation des services antérieurs, la réévaluation et l’autorité compétente pour décider.

3. **La DRH prépare un arbitrage documenté** : selon les résultats, examiner une revalorisation contractuelle motivée par l’expérience et les fonctions, ou le maintien de la rémunération avec une réponse expliquée. Si l’objectif est une carrière de fonctionnaire, examiner séparément les voies d’accès statutaires et leurs conditions, sans promettre de titularisation.

4. **Après validation**, préparer la réponse à l’agent et, si nécessaire, le document contractuel adapté. Avant tout chiffrage, le service paie contrôle l’indice, la valeur du point à la date utile et la quotité.

**Point de vigilance :** ne pas transformer une référence indiciaire en grade, ni valoriser des services sans base identifiée. Toute décision défavorable nécessitera un contrôle de sa motivation, de sa notification et des recours applicables.

**Niveau de confiance : abstention sur les droits individuels ; cadrage documentaire uniquement.**
