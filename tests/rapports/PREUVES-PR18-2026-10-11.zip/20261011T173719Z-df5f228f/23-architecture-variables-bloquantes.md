# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable en l’état.** Le nom et le cadre d’emplois ne suffisent pas pour déterminer si l’agent peut être nommé au grade supérieur en **2026**. Il faut distinguer son **éligibilité statutaire**, son **inscription au tableau** et la **décision de nomination**.

Pouvez-vous réunir une fiche anonymisée avec :

- son **statut**, son **grade actuel** et le **grade visé** ;
- son **échelon**, les dates utiles d’ancienneté et ses états de services ;
- l’éventuel **examen professionnel obtenu**, avec sa date ;
- la **date de nomination envisagée**, les lignes directrices de gestion applicables et la délibération fixant le taux de promotion, si ce régime s’applique ?

**Inutile de transmettre son nom.** Précisez aussi l’employeur et son effectif pour confirmer le périmètre territorial concerné.

Les extraits officiels fournis permettent déjà de poser trois règles générales :

- **Remplir les conditions ne suffit pas à imposer une nomination.** Pour l’avancement au choix, le tableau repose sur la valeur professionnelle et les acquis de l’expérience ; l’autorité territoriale conserve son appréciation en tenant compte des lignes directrices de gestion. [CGFP — modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506).
- **Le taux de promotion fixe un maximum**, calculé sur les fonctionnaires remplissant les conditions. Il est fixé par l’assemblée délibérante après avis du **comité social territorial (CST)**. L’extrait exclut expressément le cadre d’emplois des **agents de police municipale** : ne pas lui appliquer automatiquement ce calcul. [CGFP — plafond de promotions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500).
- **L’autorité territoriale prononce l’avancement parmi les inscrits**, en respectant l’ordre du tableau. [CGFP — nomination](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498).

Ces trois versions sont applicables au **11 octobre 2026**, d’après les consultations archivées fournies.

**Prochaine action :** demander au service carrière de contrôler d’abord les conditions du statut particulier, puis le plafond applicable, les critères locaux et le classement envisagé. Les conditions propres au cadre d’emplois et les pièces locales sont absentes : aucune nomination individuelle ne peut encore être validée.

Avant la décision, restent aussi à vérifier le rôle actuel de la **commission administrative paritaire (CAP)**, les formalités de l’acte et les garanties d’un éventuel refus : motivation applicable, notification et voies/délais de recours.

**Confiance : stable sur le socle cité ; abstention sur l’éligibilité et la nomination de cet agent.**
