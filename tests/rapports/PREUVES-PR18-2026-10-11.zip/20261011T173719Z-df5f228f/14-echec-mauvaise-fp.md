# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
Votre demande concerne la **fonction publique hospitalière (FPH)**. Le corpus fourni couvre uniquement la fonction publique territoriale : **l’effectif de 900 agents ne change pas cette limite**.

**Faits connus :** employeur CHU, agent titulaire, arrêt maladie depuis huit mois. Cette durée seule ne permet pas, avec ce corpus, de déterminer son régime de congé de longue maladie (CLM).

**Décision : non tranchable avec le corpus fourni.** Aucune source officielle hospitalière n’a été consultée ; je ne peux donc certifier les conditions d’accès au CLM, sa durée, sa rémunération ou son renouvellement.

Pour préparer la vérification par votre service RH hospitalier, réunissez :

- la date exacte de début de l’arrêt et les décisions de congé déjà prises ;
- la nature du congé actuel : congé de maladie ou CLM déjà accordé ;
- l’existence d’une demande de CLM et des pièces médicales requises, accessibles uniquement aux personnes habilitées.

Le contrôle devra porter sur les dispositions du **Code général de la fonction publique applicables à la FPH** et les textes hospitaliers relatifs aux congés de maladie, dans leur version applicable aux dates concernées. Il devra distinguer les conditions médicales, le rôle de l’instance médicale et celui de l’autorité décisionnaire, puis vérifier rémunération, renouvellement, motivation éventuelle, notification et recours.

**Niveau de confiance : abstention sur le régime juridique demandé, faute de sources hospitalières dans le corpus.**
