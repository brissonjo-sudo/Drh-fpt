# Garde de calibrage — données volatiles

## Question
Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
Au **11 octobre 2026**, la valeur d’un **point d’indice majoré** est :

- **59,0734 € bruts par an** — valeur exacte.
- **4,922783333… € bruts par mois** — décimale périodique, obtenue par `5 907,34 ÷ 100 ÷ 12`.

**Pour ton arrêté**, retiens la base réglementaire exacte : **5 907,34 € annuels pour l’indice 100 majoré**. Évite d’utiliser **4,92 €** pour calculer le traitement : cet arrondi réduit la précision.

Source : [décret n° 85-1148 du 24 octobre 1985 modifié](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047751772), version en vigueur depuis le **1er juillet 2023**, consultation officielle archivée fournie du **11 octobre 2026**.

**Confiance : stable sur la base de cette source fournie.**
