# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Avec environ 40 agents, faites d’abord confirmer votre rattachement au comité social territorial (CST) du centre de gestion (CDG).**

L’extrait officiel fourni distingue :

- **Au moins 50 agents** : CST propre à la collectivité.
- **Moins de 50 agents, pour une collectivité affiliée** : CST placé auprès du CDG.

Source : [Code général de la fonction publique](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312), version applicable depuis le 1er janvier 2023, consultation archivée du 11 octobre 2026. Cette source établit le rattachement de l’instance, **pas la procédure de saisine**.

Le corpus DRH fourni couvre les collectivités de **plus de 350 agents** : votre commune est hors de ce périmètre. Je ne peux donc pas dérouler une procédure détaillée à partir de cette base.

**État de décision : non tranchable en l’état pour la procédure exacte.** L’objet de la consultation manque et les textes procéduraux ne figurent pas dans les sources officielles fournies.

Pour préparer votre démarche, demandez au service chargé du CST de votre CDG :

- de confirmer l’instance dont relève votre commune ;
- de préciser si votre projet nécessite sa consultation ;
- de vous transmettre les modalités de saisine, les pièces attendues et le calendrier applicable.

Votre secrétariat de mairie peut préparer le projet concerné, une courte présentation de ses effets sur les agents et la date de mise en œuvre envisagée. Il s’agit d’un **dossier de préparation**, pas d’une liste réglementaire certifiée.

**Sur quel projet souhaitez-vous consulter le CST : organisation des services, temps de travail, rémunération ou autre sujet ?**

Confiance : **stable sur le seuil et le rattachement sous condition d’affiliation ; abstention sur la procédure détaillée.**
