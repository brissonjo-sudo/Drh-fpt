# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**L’engagement d’une procédure est possible sous conditions. En revanche, les éléments fournis ne permettent pas de recommander dès maintenant une exclusion de cinq jours.** Je recommande d’abord une instruction des faits, puis une décision sur l’ouverture de la procédure après contrôle de la prescription.

L’analyse ci-dessous repose uniquement sur les extraits officiels fournis, dans leurs versions applicables au **11 octobre 2026**.

**Ce que les textes permettent d’établir**

Pour un fonctionnaire territorial titulaire, **une exclusion de cinq jours appartient au deuxième groupe** : celui-ci comprend les exclusions de quatre à quinze jours. Elle exige donc **la consultation préalable du conseil de discipline avant son prononcé**. Cette consultation concerne la sanction ; elle n’est pas présentée par le texte comme un préalable à l’engagement de la procédure.

Sources : [CGFP, article L. 533-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), fonction : échelle des sanctions ; [disposition imposant le conseil préalable](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), fonction : garantie procédurale. Versions depuis le 1er mars 2022, consultations archivées du 11 octobre 2026.

L’engagement doit respecter la **prescription de trois ans**, calculée à partir de la connaissance effective par l’administration de **la réalité, de la nature et de l’ampleur des faits**. Des poursuites pénales peuvent interrompre ce délai selon les conditions du texte. Une simple date de rumeur ne permet donc pas, à elle seule, de fixer le point de départ.

Source : [CGFP, article L. 532-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430), fonction : prescription ; version depuis le 1er mars 2022, consultation archivée du 11 octobre 2026.

**Pour trancher le dossier, peux-tu préciser ces trois ensembles d’informations ?**

- **Employeur et agent** : type de collectivité, effectif, affiliation au centre de gestion, cadre d’emplois et éventuel emploi fonctionnel.
- **Faits et preuves** : faits reprochés, dates, pièces disponibles et éventuelles poursuites pénales.
- **Calendrier** : date de connaissance effective par l’administration, procédure déjà ouverte ou non, date envisagée de sanction.

Ces informations conditionnent notamment la prescription, le circuit du conseil et l’appréciation de la sanction.

**Ma recommandation**

**Ne pas arrêter dès maintenant la durée de cinq jours.** La retenir comme une hypothèse à examiner, puis apprécier les faits établis, leur gravité, les circonstances et les observations de l’agent.

L’état de décision est donc :

- **Engagement : possible sous conditions**, après vérification du régime applicable et de la prescription.
- **Exclusion de cinq jours : non tranchable en l’état**, faute de faits établis, de défense recueillie et d’avis préalable.

Voici les actions à lancer, dans l’ordre. Les étapes disciplinaires restent conditionnées aux contrôles de départ.

| Ordre | Action et responsable | Contrôle et preuve à conserver |
|---|---|---|
| **1** | **DRH : établir une chronologie et réunir les pièces.** Distinguer soupçons, faits documentés et points contestés. | Tableau dates–faits–pièces ; origine des documents ; date et circonstances de la connaissance effective. Vérifier la prescription et les éventuelles poursuites pénales. |
| **2** | **DRH et service juridique : confirmer le régime et le circuit.** Identifier l’autorité disciplinaire, le signataire habilité, la catégorie et les éventuelles particularités de l’emploi. | Compétence et délégation ; affiliation au centre de gestion ; conseil compétent et composition. L’extrait fourni ne permet pas de vérifier intégralement la composition ordinaire du conseil. |
| **3** | **Autorité disciplinaire : décider de l’ouverture, si les contrôles précédents le permettent.** Informer l’agent par écrit de la procédure et préciser les faits reprochés. | Courrier et preuve de remise. Mentionner l’accès au dossier intégral et aux annexes, ainsi que l’assistance par un ou plusieurs conseils de son choix. |
| **4** | **DRH : organiser effectivement la défense.** Préparer le dossier, rendre les pièces accessibles et laisser un délai suffisant pour les examiner et préparer les observations. | Pièces et annexes numérotées ; preuve d’accès ; demandes et réponses ; calendrier permettant réellement la défense. **Avant toute audition ou recueil d’observations, vérifier les règles d’information sur le droit de se taire : leur source officielle manque au dossier fourni.** |
| **5** | **Autorité disciplinaire et secrétariat : préparer la saisine du conseil**, si une sanction du deuxième groupe demeure envisagée après instruction. | Vérifier les modalités de saisine et le contenu du rapport, non intégralement documentés ici. Le président convoque le conseil et l’agent ; l’autorité disciplinaire ne peut pas siéger. |
| **6** | **Président du conseil : convoquer l’agent et tenir la séance.** | Convocation par lettre recommandée avec avis de réception **au moins quinze jours avant la réunion**. L’agent peut présenter des observations écrites ou orales, citer des témoins et se faire assister. Conserver les preuves de convocation et l’avis motivé. |
| **7** | **Autorité disciplinaire : réexaminer le dossier après l’avis**, puis décider de la suite et, éventuellement, de la sanction. | Motivation écrite en droit et en fait ; examen des observations et justification de la durée retenue. L’avis est communiqué sans délai à l’agent et à l’autorité. |
| **8** | **DRH : préparer la notification et l’exécution.** | Notification traçable ; dates précises d’exclusion ; effets administratifs et financiers à contrôler. Vérifier les voies et délais de recours, le tribunal compétent et les formalités applicables avant envoi. Ne pas fixer une date d’effet rétroactive. |

Les garanties des étapes 3 et 4 reposent sur la [disposition du CGFP relative au dossier intégral et aux défenseurs](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000052323864), version depuis le 1er octobre 2025, et sur l’[extrait du décret disciplinaire relatif à l’information et à la préparation de la défense](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836), version depuis le 11 décembre 2025.

Pour les étapes 5 à 7 : [convocation du conseil et absence de l’autorité disciplinaire](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222), [convocation et droits devant le conseil](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372226), [communication de l’avis et décision motivée](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042650806). Ces extraits ont été consultés officiellement le 11 octobre 2026.

La motivation doit exposer les **considérations de droit et de fait** fondant la décision : [CRPA, article L. 211-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [disposition relative au contenu de la motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le 1er janvier 2016.

**Deux contrôles finaux à ne pas oublier**

- **Recours** : distinguer le conseil de discipline préalable de l’ancienne instance de recours. Le corpus métier signale la suppression de cette dernière, mais les textes modificatifs et transitoires ne figurent pas dans les consultations fournies. Leur concordance avec le décret consolidé, ainsi que les recours actuels et leurs délais, restent à vérifier avant notification.
- **Contrôle de légalité** : **si l’employeur est une commune**, l’exclusion disciplinaire d’un fonctionnaire ne relève pas, en tant que telle, d’une catégorie de transmission obligatoire dans la liste actuelle de [l’article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560). Distinguer cette liste d’une ancienne version, d’une pratique locale de télétransmission et d’une demande du préfet. Celui-ci peut demander communication d’un acte hors liste selon [l’article L. 2131-3](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556). Pour un autre employeur, vérifier son régime propre.

**Confiance : stable sur le classement des cinq jours, le conseil préalable et les garanties expressément documentées ; décision individuelle non tranchable à ce stade.** Les principaux risques restent la prescription, une défense incomplète, une composition irrégulière du conseil et une durée insuffisamment justifiée. Limiter la circulation du dossier aux personnes ayant besoin d’en connaître.
