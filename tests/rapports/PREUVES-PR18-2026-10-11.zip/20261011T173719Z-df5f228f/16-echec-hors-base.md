# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**L’indemnité de feu est fixée à 25 % du traitement soumis à retenue pour pension.** C’est un taux : le montant en euros varie selon l’assiette de chaque sapeur-pompier professionnel.

Son fondement est le **décret n° 90-850 du 25 septembre 1990**, portant dispositions communes à l’ensemble des sapeurs-pompiers professionnels. L’extrait officiel fourni indique :

> « Les sapeurs-pompiers professionnels peuvent percevoir […] une indemnité de feu d’un taux de 25 % du traitement soumis à retenue pour pension. »

[Source Légifrance — LEGIARTI000042155025](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025), version en vigueur depuis le **26 juillet 2020**, consultation archivée au **11 octobre 2026**.

Le calcul est donc :

**Indemnité de feu = traitement soumis à retenue pour pension × 25 %.**

L’assiette prévue n’est pas l’ensemble de la rémunération brute, primes comprises.

**Le montant exact en euros est non tranchable avec les données fournies.** Il faut connaître l’assiette individuelle de paie, en contrôlant notamment l’indice majoré, la valeur du point applicable et la quotité rémunérée.

Enfin, le décret renvoie aux conditions de **l’article 17 de la loi n° 90-1067 du 28 novembre 1990** : ce renvoi n’est pas documenté dans les sources fournies et reste à vérifier avant de valider une attribution individuelle.

**Confiance : taux établi par l’extrait officiel fourni ; montant individuel et conditions d’attribution à compléter.**
