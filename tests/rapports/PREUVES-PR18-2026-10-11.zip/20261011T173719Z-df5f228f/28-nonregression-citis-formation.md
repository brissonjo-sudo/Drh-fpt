# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Formation plénière, lorsqu’un avis est requis ; décision finale de l’autorité territoriale.** La formation restreinte n’est pas compétente pour l’avis sur l’imputabilité au service.

La saisine n’est toutefois **pas automatique du seul fait que l’accident est contesté**. Pour un accident de service, le texte fourni prévoit la consultation lorsqu’une faute personnelle ou une circonstance particulière est potentiellement de nature à détacher l’accident du service. Il faut donc identifier précisément le motif de contestation.  
*Source : décret n° 87-602, [extrait relatif aux cas de consultation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859), version depuis le 18 avril 2024 ; [compétence de la formation plénière](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783), même date de version.*

Le conseil médical **rend un avis**. Au terme de l’instruction, **l’autorité territoriale — maire ou président selon l’employeur — se prononce sur l’imputabilité** et, le cas échéant, place le fonctionnaire en congé pour invalidité temporaire imputable au service (CITIS). L’avis médical et la décision administrative sont donc deux étapes distinctes.  
*Source : décret n° 87-602, [extrait relatif à la décision finale](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843), version depuis le 18 avril 2024.*

Concrètement, la DRH doit :

- réunir la déclaration, le certificat médical, les circonstances de l’accident et les éléments précis de contestation ;
- saisir la **formation plénière** si le motif relève du cas de consultation précité, en respectant les droits de l’agent au dossier et aux observations ;
- préparer ensuite la décision de l’autorité territoriale. En cas de refus, faire vérifier la motivation, la notification et les voies et délais de recours, dont les textes ne sont pas fournis ici.

Cette réponse concerne le **fonctionnaire territorial** ; le régime du contractuel doit être examiné séparément.

**Confiance : stable sur la formation compétente et l’autorité décisionnaire**, d’après les consultations officielles archivées fournies au 11 octobre 2026. La nécessité de saisir dans le dossier individuel dépend du motif concret de contestation.
