# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Votre cycle annualisé peut être conservé, sous conditions.** L’annualisation reste autorisée. En revanche, **la conformité de votre organisation actuelle est non tranchable sans examiner la délibération et les horaires réellement pratiqués** : son ancienneté ne suffit pas à la justifier.

Ce cadre concerne les agents de la **fonction publique territoriale de droit commun**. L’analyse est arrêtée au **11 octobre 2026**, à partir des extraits officiels et des traces de consultation fournis dans le corpus.

**Les règles nationales à respecter**

Pour un agent à temps complet, la référence est **35 heures par semaine et 1 607 heures annuelles de travail effectif**, sans préjudice des heures supplémentaires. Un cycle annualisé peut répartir différemment les heures selon les périodes : chaque semaine n’a donc pas nécessairement la même durée.

Le travail effectif correspond au temps pendant lequel l’agent reste à la disposition de l’employeur, suit ses directives et ne peut pas vaquer librement à ses occupations personnelles. Il faut donc examiner les conditions réelles des pauses pour déterminer leur décompte.

Sources : décret du 25 août 2000, [durée de référence](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142), version depuis le 01/01/2023 ; [définition du travail effectif](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version depuis le 29/06/2006 ; consultations archivées le 11/10/2026.

L’annualisation doit aussi respecter **toutes** les garanties suivantes :

| Garantie | Limite nationale |
|---|---:|
| Travail effectif quotidien | 10 heures maximum |
| Amplitude de la journée | 12 heures maximum |
| Travail hebdomadaire, heures supplémentaires comprises | 48 heures maximum |
| Moyenne sur toute période de 12 semaines consécutives | 44 heures maximum |
| Repos quotidien | 11 heures minimum |
| Repos hebdomadaire | 35 heures minimum, comprenant en principe le dimanche |
| Pause | Au moins 20 minutes avant que le travail quotidien atteigne 6 heures |

Ces limites s’appliquent simultanément : une moyenne annuelle correcte ne corrige pas une journée trop longue ou un repos insuffisant. Les dérogations prévues par le texte sont encadrées ; **aucun fondement permettant d’en bénéficier n’est établi dans votre dossier**.

Source : décret du 25 août 2000, [garanties minimales et dérogations](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150), version depuis le 01/01/2023, consultation archivée le 11/10/2026.

**Ce qui relève de votre collectivité**

Deux points doivent être distingués :

- **Le cycle annualisé** : ses conditions de mise en place sont déterminées par l’organe délibérant, après avis du **comité social territorial (CST)**. La durée du cycle, les horaires, les repos et les pauses doivent être identifiables.
- **Une durée annuelle réduite** : elle est possible pour des sujétions réelles liées aux missions et aux cycles — nuit, dimanche, horaires décalés, équipes, travaux pénibles ou dangereux, notamment. Elle doit être justifiée et décidée par l’organe délibérant après avis du CST. Elle n’est pas automatique.

Le décret territorial adapte ainsi le dispositif de l’État : **les décisions locales relèvent de l’organe délibérant et du CST**, et non des autorités ministérielles mentionnées dans le décret de l’État.

Sources : décret du 12 juillet 2001, [renvoi au cadre national](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version depuis le 14/07/2001 ; [cycles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472) et [réduction pour sujétions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477), versions depuis le 01/01/2023 ; consultations archivées le 11/10/2026.

**Ma recommandation : contrôler le cycle avant de décider de le maintenir ou de le modifier.**

1. **DRH** : réunir la délibération, ses annexes, les modifications et les avis de l’instance consultée à l’époque.
2. **Responsable du service et gestionnaire des temps** : comparer les plannings et les heures réellement effectuées aux garanties ci-dessus ; contrôler aussi le paramétrage du système d’information des ressources humaines.
3. **DRH et autorité territoriale** : documenter les éventuelles sujétions et corriger les écarts. Si le cycle doit être modifié, préparer la consultation du CST puis la délibération ; vérifier les formalités de publicité et de transmission avant mise en œuvre.

**Pour trancher votre cas**, pouvez-vous préciser le type d’employeur, les agents concernés et leurs quotités, puis fournir le contenu de la délibération applicable et un planning représentatif des périodes chargées ?

**Confiance : stable sur les règles nationales citées ; à vérifier sur votre organisation locale et tout éventuel régime particulier.** Le corpus ne permet pas de certifier le maintien d’un ancien régime dérogatoire ni de déterminer vos obligations individuelles.
