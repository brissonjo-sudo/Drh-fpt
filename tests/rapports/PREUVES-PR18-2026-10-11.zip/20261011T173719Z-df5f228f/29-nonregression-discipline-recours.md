# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non : pour un fonctionnaire territorial sanctionné en 2026, le conseil de discipline de recours n’est plus une voie ouverte.** Indiquez le recours devant le tribunal administratif et la possibilité d’un recours gracieux auprès de l’autorité qui a pris la sanction.

Analyse au **11 octobre 2026**, fondée exclusivement sur les consultations officielles archivées fournies.

Une exclusion de **5 jours relève du deuxième groupe** : elle nécessite donc la consultation préalable du conseil de discipline. **Ce conseil préalable subsiste ; c’est l’ancienne instance de recours qui a été supprimée.** Sources : [échelle des sanctions du CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) et [consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), versions applicables depuis le 1er mars 2022.

La suppression résulte de l’article 32 de la loi du 6 août 2019 et des textes réglementaires de 2020. Elle concorde avec la [structure consolidée du décret du 18 septembre 1989 au 11 octobre 2026](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000335719/2026-10-11) : le chapitre Ier relatif au conseil préalable demeure en vigueur ; le chapitre II relatif aux conseils de discipline de recours est abrogé depuis le **10 décembre 2020**. Le régime transitoire de l’[article 94 XI de la loi](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000038889235) vise les recours contre des sanctions intervenues **avant le 7 août 2019** : votre sanction de 2026 n’en relève pas.

Les voies à mentionner sont :

- **Recours contentieux** devant le tribunal administratif territorialement compétent, dans les **deux mois suivant la notification**. Ce délai n’est opposable que si les voies et délais de recours figurent dans la notification. Sources : [délai contentieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le 1er janvier 2020 ; [opposabilité du délai](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le 1er janvier 2001.
- **Recours gracieux facultatif**, adressé à l’autorité auteure de la décision. Présenté dans le délai contentieux, il **interrompt ce délai**. Ne désignez pas automatiquement un supérieur hiérarchique ou le préfet. Sources : [définition du recours gracieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367823) et [effet interruptif](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367829), versions depuis le 1er janvier 2016.

Formulation à intégrer, après complément des champs :

> **Voies et délais de recours**  
> La présente décision peut faire l’objet d’un recours contentieux devant le tribunal administratif de **[nom et adresse]**, dans un délai de deux mois à compter de sa notification.  
> Elle peut également faire l’objet d’un recours gracieux auprès de **[autorité ayant pris la décision et adresse]**, présenté dans ce même délai. Ce recours gracieux interrompt le délai de recours contentieux.

**Avant envoi**, la DRH doit compléter la juridiction compétente, contrôler la motivation de la sanction et conserver la preuve de notification. L’avis du conseil et la sanction doivent être motivés ; [l’article 14 du décret de 1989](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042650806), version depuis le 10 décembre 2020, confirme la décision motivée de l’autorité territoriale. La transmission au contrôle de légalité reste à vérifier séparément : le texte applicable du CGCT n’est pas fourni.

**Confiance : stable** sur l’absence de recours devant l’ancienne instance et sur les voies indiquées, pour un fonctionnaire territorial de droit commun. Cette réponse ne valide pas l’ensemble de la procédure disciplinaire.
