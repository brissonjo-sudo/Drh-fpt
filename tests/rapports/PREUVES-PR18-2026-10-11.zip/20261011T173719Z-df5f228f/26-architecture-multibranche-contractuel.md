# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne donne pas au contractuel un grade ni les droits à avancement d’un fonctionnaire titulaire.** Elle sert à déterminer sa rémunération. En revanche, son expérience doit être prise en compte et sa rémunération doit être réexaminée périodiquement.

Analyse au **11 octobre 2026**, fondée exclusivement sur les extraits officiels et les traces de consultation fournis dans le corpus.

**Ce qui peut être décidé**

- **Avancement de grade comme un titulaire : impossible en l’état sur le seul fondement du CDI et de l’indice de rémunération.** Les textes fournis organisent une rémunération fixée par l’autorité territoriale selon les fonctions, les qualifications et l’expérience. J’en déduis que l’utilisation d’une grille comme référence ne confère pas le grade correspondant ni son déroulement de carrière.
- **Reprise intégrale de toute l’ancienneté : non tranchable sans examiner l’emploi et le contrat.** Le régime général impose de prendre en compte l’expérience ; il ne prévoit pas, dans l’extrait fourni, sa conversion intégrale et automatique en ancienneté d’échelon.
- **Réexamen de la rémunération : possible et obligatoire au moins tous les trois ans pour un CDI.** Cette obligation porte sur le réexamen ; elle ne garantit ni une hausse ni une augmentation correspondant à toute l’ancienneté revendiquée.

Ces conclusions reposent sur la disposition relative à la rémunération du **décret n° 88-145 du 15 février 1988**, version applicable depuis le **1er juillet 2026**, [LEGIARTI000054242039](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), consultation archivée du **11 octobre 2026**. Fonction juridique : fixation et réévaluation de la rémunération.

**Une exception doit être contrôlée avant de répondre définitivement.** Le même extrait prévoit, pour les agents nommés aux emplois mentionnés à l’article **L. 343-1 du Code général de la fonction publique**, un classement à un échelon selon la durée et le niveau de leurs expériences antérieures. Si l’agent occupe un tel emploi de direction, il faut examiner les textes particuliers auxquels cette disposition renvoie. Leurs règles détaillées ne sont pas fournies : aucune reprise précise ne peut être calculée ici.

**Les informations à réunir**

Pour trancher sa demande, il faut préciser en une fois :

1. **L’emploi exact et le fondement du recrutement**, notamment l’éventuelle nomination sur un emploi de direction relevant du régime dérogatoire.
2. **Les clauses du CDI et des avenants**, ainsi que le cadre local de rémunération : simple indice de référence ou dispositions particulières sur l’expérience et les réexamens ?
3. **Les justificatifs des expériences revendiquées**, leurs dates, fonctions et responsabilités, la date de fixation initiale de la rémunération et celle du dernier réexamen.

L’absence de ces pièces suspend la décision individuelle, sans remettre en cause l’obligation générale de réévaluation du CDI.

**La marche à suivre**

| Étape | Responsable | Action et preuve attendue |
|---|---|---|
| Qualifier la demande | Ressources humaines | Distinguer reprise d’expérience, réévaluation salariale et accès à un grade ; contrôler l’emploi et les clauses contractuelles. |
| Examiner le parcours | Ressources humaines et supérieur direct | Comparer les expériences justifiées aux fonctions actuelles, qualifications requises et responsabilités ; conserver une analyse écrite. |
| Réexaminer la rémunération | Autorité territoriale, sur dossier RH | Vérifier l’échéance triennale et apprécier une éventuelle évolution au regard du parcours, des fonctions et des résultats professionnels. |
| Formaliser et répondre | Autorité territoriale et RH | Expliquer séparément la réponse sur le grade et celle sur la rémunération ; faire vérifier le support juridique nécessaire à une éventuelle modification avant la paie. |

Le Code général de la fonction publique confirme que la rémunération peut tenir compte des résultats professionnels et collectifs : version depuis le **1er mars 2022**, [LEGIARTI000044424781](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), consultation archivée du **11 octobre 2026**. Fonction juridique : critères de rémunération.

**L’entretien professionnel appuie ce réexamen.** Pour un CDI recruté sur un emploi permanent, il est annuel, conduit par le supérieur hiérarchique direct et donne lieu à un compte rendu visé par l’autorité territoriale. La **commission consultative paritaire (CCP)** peut proposer une modification du compte rendu après une demande préalable de révision ; cette compétence ne lui attribue pas la fixation du salaire.

Source : disposition relative à l’entretien professionnel du décret précité, version depuis le **1er janvier 2023**, [LEGIARTI000043498480](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), consultation archivée du **11 octobre 2026**.

**Recommandation :** instruire une demande de réévaluation argumentée de la rémunération. Si l’objectif est d’obtenir la qualité de fonctionnaire, examiner séparément les voies d’accès et leurs conditions ; l’indice et le CDI ne suffisent pas à produire cet effet.

Avant notification d’une décision ou d’un refus, **faire vérifier les obligations de motivation, les modalités de notification et les voies et délais de recours propres à cette décision**. Les extraits fournis ne permettent pas de les certifier pour un refus salarial ; ne pas leur transposer les recours du compte rendu d’entretien.

**Confiance : stable sur les règles générales documentées ; décision individuelle et éventuel montant à vérifier sur les pièces et, si nécessaire, les textes particuliers.**
