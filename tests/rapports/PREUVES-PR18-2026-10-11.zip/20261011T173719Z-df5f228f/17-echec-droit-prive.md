# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non, pour un fonctionnaire titulaire territorial.** La présomption de démission instaurée en 2022 concerne les salariés de droit privé, y compris ceux employés par une personne publique. Elle ne s’applique pas à votre agent titulaire : voir les extraits officiels du [champ d’application du Code du travail](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006900781) et de la [présomption de démission](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104), dans leurs versions applicables au 11 octobre 2026.

**La voie à examiner est le licenciement pour abandon de poste, emportant radiation des cadres.** Ce fondement figure à l’article L. 553-1, 1° du Code général de la fonction publique, [version en vigueur depuis le 1er mars 2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184).

Mais **plusieurs semaines d’absence injustifiée ne suffisent pas, à elles seules, à autoriser la radiation**. Il faut notamment :

- une **mise en demeure écrite et notifiée**, demandant la reprise du service ;
- un **délai approprié**, fixé par l’administration ;
- un avertissement explicite sur le risque de **radiation des cadres sans procédure disciplinaire préalable**.

Ces exigences résultent de [CE, Section, 11 décembre 1998, nos 147511 et 147512, publié au Lebon](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335). Le délai approprié est une condition nécessaire à la caractérisation de l’abandon, et non une simple formalité : [CE, 26 septembre 2014, n° 365918](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000029504219).

**À l’échéance, la DRH doit constater si l’agent a repris**, puis examiner ses réponses, son intention de reprendre et ses éventuels justificatifs médicaux ou matériels. Une réponse refusant la reprise ne préserve pas automatiquement le lien avec le service ; inversement, la seule non-reprise ne dispense pas d’examiner les circonstances. L’[arrêt de la CAA de Versailles du 14 avril 2026, n° 24VE00726, points 11 à 13](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000053906348), illustre cette appréciation dans une affaire concernant une fonctionnaire de l’État ; son délai de 48 heures ne constitue pas une règle générale transposable.

Il s’agit d’une **voie non disciplinaire** : pas de conseil de discipline ni de communication du dossier **au titre des garanties disciplinaires**. Cela ne supprime pas les conditions préalables ci-dessus.

**Décision : présomption de démission impossible ; radiation non tranchable en l’état.** Faites réunir par la DRH la chronologie des absences, les échanges et les preuves de notification. Avant tout arrêté, restent à vérifier la compétence du signataire, la motivation, la date d’effet, la notification, les voies et délais de recours et l’éventuelle transmission au contrôle de légalité. Le dossier officiel fourni ne permet pas de certifier ces derniers points ; aucune date d’effet ne doit être automatiquement fixée au premier jour d’absence.

**Une mise en demeure a-t-elle déjà été notifiée ?** Si oui, précisez son contenu, sa date de notification, l’échéance fixée et les éventuelles réponses de l’agent.

Confiance élevée sur l’exclusion du dispositif privé ; appréciation individuelle suspendue aux pièces manquantes. Analyse fondée uniquement sur les consultations officielles archivées dans le corpus.
