# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non, pour une sanction prononcée au 11 octobre 2026.** L’article **L. 2131-2 du Code général des collectivités territoriales (CGCT)**, dans sa version applicable depuis le **1er juillet 2022**, ne comprend plus les sanctions disciplinaires dans la liste des actes obligatoirement transmis. Son I, 5° vise certaines décisions de nomination, de recrutement et de licenciement, sans mentionner les sanctions disciplinaires. [Source officielle archivée fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560).

L’exclusion de **5 jours relève du deuxième groupe**, selon l’échelle des sanctions du Code général de la fonction publique. **Ce classement ne crée pas une obligation de transmission.** [Source officielle archivée fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388).

La confusion vient de l’ancienne version de L. 2131-2 : **au 1er janvier 2004**, elle visait expressément les « sanctions soumises à l’avis du conseil de discipline ». Cette liste historique ne s’applique pas à une sanction actuelle.

**En pratique :** aucune transmission obligatoire sur ce fondement. Il faut toutefois distinguer une transmission volontaire ou une pratique locale d’une **demande de communication du préfet**, possible pour les actes hors liste. [Source officielle archivée fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556).

**Confiance : stable**, sur les extraits officiels et versions fournis pour cette date.
