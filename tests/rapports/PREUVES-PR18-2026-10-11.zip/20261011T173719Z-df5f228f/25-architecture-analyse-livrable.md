# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Décision : non tranchable pour l’agent concerné ; nomination possible sous conditions.** Le projet ci-dessous conserve les informations manquantes sous forme de champs. Il doit être complété et contrôlé avant signature.

Analyse au **11 octobre 2026**, fondée uniquement sur les extraits officiels archivés fournis, sans nouvelle consultation. L’employeur, le statut de l’agent, les grades et la date d’effet ne sont pas renseignés.

**Conditions de nomination**

Pour un fonctionnaire territorial, l’avancement de grade suppose notamment :

- **Une voie d’avancement ouverte et les conditions statutaires remplies.** Il faut identifier le cadre d’emplois, le grade actuel, le grade cible et vérifier le statut particulier : ancienneté, services, échelon et, selon la voie, examen ou concours professionnel. Le corpus confirme les différentes modalités d’avancement, mais ne contient pas les statuts particuliers permettant de vérifier l’éligibilité individuelle. [CGFP — modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), version depuis le 01/03/2022, consultation archivée du 11/10/2026.
- **L’inscription au tableau d’avancement et le respect de son ordre.** L’autorité territoriale prononce l’avancement parmi les fonctionnaires inscrits ; elle doit respecter l’ordre du tableau. L’inscription ne vaut donc pas, à elle seule, nomination. [CGFP — décision et ordre du tableau](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), même version et date de consultation.
- **Le respect du nombre maximal de promotions.** Hors cadre d’emplois des agents de police municipale, ce maximum résulte des effectifs remplissant les conditions multipliés par le taux fixé par l’assemblée délibérante après avis du **comité social territorial (CST)**. Le taux local et le calcul restent à fournir. L’exception concernant la police municipale impose de vérifier son régime propre. [CGFP — taux de promotion](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), même version et date de consultation.
- **La prise en compte des lignes directrices de gestion (LDG)** pour l’avancement au choix, sans renonciation au pouvoir d’appréciation de l’autorité territoriale. Les LDG locales doivent être jointes au dossier. Leur contenu national est confirmé par l’[extrait relatif aux promotions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251), version depuis le 01/08/2026, consultation archivée du 11/10/2026.
- **L’acceptation de l’emploi assigné dans le nouveau grade.** Elle conditionne l’avancement. [CGFP — acceptation de l’emploi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496), version depuis le 01/03/2022, consultation archivée du 11/10/2026.

Le rôle actuel de la **commission administrative paritaire (CAP)** est un contrôle restant à effectuer : le corpus métier indique l’absence de consultation préalable sur l’avancement, mais aucune trace officielle fournie ne permet ici de certifier ce point. Aucun avis de CAP n’est donc prérempli dans le projet.

**Recommandation :** faire compléter par le service carrière la fiche d’éligibilité, le tableau et son ordre, les LDG, le taux applicable, l’emploi d’affectation et son acceptation, puis vérifier le classement et la compétence du signataire. La preuve attendue est un dossier réunissant les textes applicables et les pièces locales avant signature.

**Projet d’arrêté**

*Modèle communal pour un fonctionnaire territorial titulaire. Si l’employeur ou le statut diffère, le modèle doit être adapté.*

---

**[COMMUNE DE …]**  
**Arrêté n° [ … ] portant avancement de grade de [nom et prénom] au grade de [grade cible]**

Le maire de [commune],

Vu le code général de la fonction publique, notamment ses dispositions relatives à l’avancement de grade des fonctionnaires territoriaux ;

Vu le code général des collectivités territoriales ;

Vu [le texte statutaire applicable au cadre d’emplois, référence et articles à compléter après vérification] ;

Vu [les textes applicables au classement dans le nouveau grade, références à compléter après vérification] ;

Vu [l’acte établissant les lignes directrices de gestion applicables, date et référence — si pertinent pour la voie retenue] ;

Vu [la délibération fixant le taux de promotion applicable, date et référence, et l’avis préalable du CST — à retenir uniquement si ce régime s’applique] ;

Vu le tableau annuel d’avancement au grade de [grade] pour l’année [année], établi le [date], sur lequel [nom et prénom] figure au rang [rang] ;

Vu [l’acte relatif à l’emploi d’affectation et les pièces établissant sa disponibilité, à compléter] ;

Vu l’arrêté n° [référence] du [date] fixant la situation administrative actuelle de l’intéressé(e) ;

Vu [la pièce établissant la réussite à l’examen ou au concours professionnel, si nécessaire] ;

Vu l’acceptation, en date du [date], par l’intéressé(e), de l’emploi de [intitulé] qui lui est assigné dans son nouveau grade ;

Considérant que les conditions statutaires d’avancement sont remplies, ainsi qu’il ressort de [pièces justificatives et dates] ;

Considérant que la nomination respecte l’ordre du tableau et [le nombre maximal de promotions applicable / les dispositions propres au cadre d’emplois] ;

[Pour l’avancement au choix : considérant l’appréciation de la valeur professionnelle et des acquis de l’expérience professionnelle de l’intéressé(e), au regard des LDG applicables, selon les éléments établis dans son dossier ;]

**ARRÊTE**

**Article 1 — Avancement de grade**

[Nom et prénom], fonctionnaire titulaire du grade de [grade actuel], relevant du cadre d’emplois de [cadre d’emplois], est nommé(e), par avancement de grade, au grade de [grade cible], à compter du [date d’effet vérifiée].

**Article 2 — Classement**

À cette date, l’intéressé(e) est classé(e) au [échelon] du nouveau grade, avec une ancienneté conservée de [durée].

[Indices brut et majoré à compléter uniquement après vérification des règles de classement et de la grille applicable à la date d’effet.]

**Article 3 — Affectation**

L’intéressé(e) est affecté(e) à l’emploi de [intitulé], au sein de [service], à compter du [date].

Cet emploi est à [temps complet / temps non complet : durée de l’emploi à préciser].  
[Le cas échéant : préciser séparément l’autorisation de temps partiel applicable.]

**Article 4 — Notification et formalités**

Le présent arrêté sera notifié à l’intéressé(e).

Les autres formalités de publicité applicables seront accomplies selon [modalités à compléter après vérification].

[Clause de transmission au représentant de l’État à retenir seulement si une obligation applicable ou une demande préfectorale est identifiée ; préciser alors son fondement.]

**Article 5 — Recours**

Le présent arrêté peut faire l’objet d’un recours devant le tribunal administratif de [juridiction territorialement compétente], dans un délai de deux mois à compter de sa notification.

**Article 6 — Exécution**

[Responsables compétents à désigner] sont chargés, chacun pour ce qui le concerne, de l’exécution du présent arrêté.

Fait à [lieu], le [date].

[Nom, qualité et signature de l’autorité compétente]  
[Si signature par délégation : référence de la délégation vérifiée]

---

**Contrôles avant signature et notification**

- **Classement, emploi et compétence :** les sources nécessaires au reclassement, à la disponibilité de l’emploi, aux formalités propres au cadre d’emplois et à une éventuelle délégation ne figurent pas dans le dossier. Les champs correspondants restent ouverts ; aucune donnée de paie ne doit être déduite du projet.
- **Date d’effet :** le corpus autorise une date d’effet antérieure au caractère exécutoire d’une décision individuelle d’avancement. Cela ne permet pas de choisir librement une date rétroactive sans contrôler les conditions à cette date. [CGFP — date d’effet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425494), version depuis le 01/03/2022, consultation archivée du 11/10/2026.
- **Contrôle de légalité :** pour une commune, l’avancement de grade d’un titulaire ne relève pas, pour ce seul motif, de la catégorie du recrutement des agents non titulaires prévue au I, 5° de l’article L. 2131-2. Il ne faut donc pas lui appliquer automatiquement le délai de transmission de quinze jours. Distinguer obligation légale, transmission volontaire ou pratique locale, et demande préfectorale de communication. [CGCT, L. 2131-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) et [communication des actes non soumis à transmission obligatoire](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), versions depuis le 01/07/2022, consultations archivées du 11/10/2026.
- **Motivation et éventuel refus :** une nomination favorable ne doit pas être automatiquement assimilée à une décision défavorable soumise à motivation. Pour un refus, vérifier s’il entre dans une catégorie de l’article L. 211-2 du CRPA ; notamment, ne pas assimiler automatiquement l’avancement au choix à un avantage constituant un droit. Lorsque la motivation est obligatoire, elle doit exposer par écrit les considérations de droit et de fait. [CRPA, L. 211-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [L. 211-5](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le 01/01/2016, consultations archivées du 11/10/2026.
- **Recours et données personnelles :** conserver la preuve de notification et mentionner les voies et délais de recours pour rendre le délai opposable au destinataire. La clause proposée repose sur les articles [R. 421-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005) et [R. 421-5](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946) du CJA, versions fournies applicables au 11/10/2026. Limiter les données personnelles aux éléments nécessaires et contrôler les modalités de diffusion.

**Confiance :** règles générales étayées par les traces officielles fournies ; **nomination individuelle et arrêté à vérifier**, faute de pièces statutaires et locales. Le risque principal serait de signer malgré une inéligibilité, un ordre de tableau non respecté ou un classement erroné.
