# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée. Le compagnon « recherche-juridique » étant indisponible, je peux préparer le dossier et les contrôles, mais **pas confirmer juridiquement l’ouverture de la procédure ni fournir une procédure disciplinaire exécutable**.

**Faits connus :** l’agent est titulaire ; les faits sont encore soupçonnés ; la sanction envisagée est une exclusion temporaire de **5 jours**. L’employeur, les faits précis et leurs dates ne sont pas renseignés.

**État de décision : non tranchable.** Il manque la qualification complète du dossier et la vérification des textes applicables. Cela ne signifie pas que la procédure est interdite.

Pour pouvoir trancher, il faut préciser en une fois :

- **L’employeur :** type de collectivité, effectif, éventuel statut particulier, affiliation au centre de gestion et cadre d’emplois de l’agent.
- **Les faits :** actes reprochés, dates, éléments disponibles, date de connaissance effective par l’administration et éventuelles poursuites pénales.
- **Le calendrier :** procédure déjà ouverte ou non, date d’ouverture éventuelle et date envisagée de sanction.

L’identité nominative de l’agent n’est pas nécessaire à ce premier cadrage.

**Ma recommandation : préparer l’instruction du dossier, sans arrêter dès maintenant la sanction.** Les cinq jours restent une hypothèse à examiner après établissement des faits, examen des observations de l’agent et contrôle de proportionnalité. L’ouverture d’une procédure et le choix final d’une sanction sont deux décisions à distinguer.

Le corpus fournit les **pistes juridiques suivantes, toutes à vérifier** avant leur utilisation :

- Le classement de l’exclusion envisagée dans l’échelle des sanctions des fonctionnaires territoriaux, son rattachement au deuxième groupe et la nécessité d’un avis préalable du **conseil de discipline**, formation de la **commission administrative paritaire (CAP)**.
- Le pouvoir disciplinaire de l’autorité territoriale et la compétence du signataire ; distinguer le rôle consultatif de l’instance du pouvoir de décision.
- La prescription, son point de départ et l’incidence d’éventuelles poursuites pénales.
- Les garanties : information de l’agent, accès au dossier intégral, assistance par un conseil de son choix, temps suffisant pour préparer sa défense et information sur le droit de se taire avant le recueil des observations.
- La distinction entre le conseil de discipline préalable et l’ancienne instance de recours : vérifier les textes de suppression et tout régime transitoire, sans proposer automatiquement cette ancienne voie de recours.

Les règles nationales doivent être contrôlées séparément des modalités locales : une convention de gestion ou de télétransmission ne suffit pas à établir une compétence ou une obligation légale.

**Actions à lancer, dans l’ordre : dossier de préparation, sans mise en œuvre disciplinaire avant validation juridique.**

| Ordre | Action et responsable | Pièces et contrôle attendu |
|---|---|---|
| 1 | **DRH : qualifier l’employeur et l’agent.** | Situation statutaire, cadre d’emplois, affiliation et documents d’organisation. Confirmer le régime applicable et le circuit des instances. |
| 2 | **DRH et encadrement : réunir les éléments existants.** | Chronologie, rapports, documents et témoignages disponibles. Séparer faits établis, allégations et contradictions ; identifier la date de connaissance effective. Préserver les pièces sans préjuger de la culpabilité. |
| 3 | **Service juridique ou conseil compétent : vérifier les sources officielles.** | Code général de la fonction publique, textes disciplinaires territoriaux et statut particulier, dans leur version applicable aux dates utiles. Produire une note traçable sur la prescription, l’échelle des sanctions, les garanties et l’instance préalable. |
| 4 | **DRH et autorité territoriale : arbitrer l’ouverture après cette validation.** | Évaluer la consistance des éléments et les investigations encore nécessaires. Documenter les raisons de poursuivre, de compléter le dossier ou de ne pas engager la procédure. |
| 5 | **DRH : préparer les garanties et le circuit d’instance à faire valider.** | Inventaire du dossier intégral, modalités d’accès, information sur l’assistance et le droit de se taire, temps de défense ; identification du secrétariat et des pièces de saisine si un avis est requis. Faire contrôler le calendrier avant tout envoi. |
| 6 | **Autorité compétente, avec la DRH et le service juridique : réexaminer la décision.** | Après accomplissement du circuit validé, examiner les observations et l’avis éventuel, la matérialité des faits et la proportionnalité. Ne pas considérer les cinq jours comme acquis. |
| 7 | **DRH et service juridique : contrôler l’acte et ses suites avant signature.** | Compétence, motivation en fait et en droit, date d’effet, notification traçable, recours actuels et effets administratifs ou de paie. Vérifier séparément publicité et transmission éventuelles. |

Pour la transmission, faire contrôler **la liste légale applicable à la date de l’acte**, sans reprendre une ancienne version ; examiner séparément la convention locale de télétransmission et les éventuelles demandes du préfet. Pour les recours, vérifier les voies administratives utiles et le recours contentieux, sans inventer un supérieur hiérarchique de l’autorité territoriale.

Les principaux risques sont une sanction fondée sur des faits insuffisamment établis, une prescription mal appréciée, une garantie de défense omise, une instance incorrecte ou une sanction disproportionnée. Limiter l’accès aux données personnelles aux personnes nécessaires au traitement du dossier.

**Niveau de confiance : abstention sur la possibilité juridique d’engager la procédure et sur la sanction.** Le livrable ci-dessus prépare la décision ; il ne vaut ni autorisation juridique, ni acte, ni notification prête à envoyer.
