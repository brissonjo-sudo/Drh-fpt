# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre agent est titulaire et absent sans justificatif depuis plusieurs semaines. Le type d’employeur et les dates exactes ne sont pas précisés.

**Décision : non tranchable en l’état.** Ne fondez pas une décision de sortie sur la présomption de démission sans vérification préalable. Le corpus distingue deux pistes : la présomption de démission du **droit privé** et l’abandon de poste dans la **fonction publique territoriale**. Pour votre titulaire, c’est cette seconde piste qu’il propose d’examiner, sous réserve de confirmation officielle.

L’absence prolongée, à elle seule, ne permet pas ici de certifier un abandon de poste. Le dossier de préparation doit couvrir :

- **Les faits et justificatifs :** dates d’absence, obligations de service, tentatives de contact, réponses reçues et éventuels éléments médicaux, y compris tardifs.
- **La mise en demeure :** faire vérifier sa nécessité, son contenu, sa notification, le délai approprié de reprise et l’avertissement sur les conséquences possibles. Réunir toute lettre déjà envoyée et sa preuve de réception.
- **La qualification et les garanties :** contrôler la distinction entre licenciement pour abandon de poste et sanction disciplinaire, notamment ses conséquences sur le conseil de discipline et la communication du dossier au titre disciplinaire.
- **L’éventuelle décision :** vérifier l’autorité compétente, la motivation, la date d’effet, la notification, les recours et l’éventuelle transmission au contrôle de légalité. Ne pas retenir automatiquement le premier jour d’absence comme date d’effet.

**Prochaine action :** confiez à la DRH ou au juriste ce dossier pour contrôle du Code général de la fonction publique, du Code du travail, des règles de décision administrative et de la jurisprudence sur l’abandon de poste, dans leurs versions applicables. Une qualification ou une notification mal contrôlée expose la décision à contestation.

Pour préparer ce contrôle, précisez en une fois : **quel employeur territorial, quelles dates d’absence et une mise en demeure a-t-elle déjà été reçue par l’agent ?**

**Niveau de confiance : abstention sur la solution juridique ; cadrage documentaire uniquement.**
