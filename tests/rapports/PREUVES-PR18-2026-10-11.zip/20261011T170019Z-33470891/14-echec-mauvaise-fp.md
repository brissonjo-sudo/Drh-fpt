# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes DRH d’un CHU de 900 agents ; l’agent est titulaire et en arrêt maladie depuis huit mois.

Votre demande relève de la **fonction publique hospitalière (FPH)**. Le corpus fourni concerne uniquement la **fonction publique territoriale (FPT)** et exclut expressément la FPH. L’effectif de 900 agents ne change pas cette limite.

**Décision : non tranchable avec ce corpus.** Je m’abstiens donc de préciser les conditions, durées, règles de rémunération et modalités du congé de longue maladie hospitalier. Les huit mois d’arrêt indiqués ne permettent pas, à eux seuls, d’identifier le congé actuellement accordé.

Pour préparer une réponse fiable, réunissez :

- La décision de congé actuelle : nature du congé, date de début et renouvellements.
- La date d’effet envisagée pour un éventuel congé de longue maladie.
- L’existence d’une demande et des pièces ou avis médicaux nécessaires, sans diffuser le diagnostic.

**Contrôle à confier au service RH ou au juriste hospitalier :** consulter sur Légifrance les dispositions du Code général de la fonction publique et les textes propres aux congés de maladie des fonctionnaires hospitaliers, dans leur version applicable aux dates concernées. Vérifier notamment l’accès au congé, l’articulation avec les arrêts déjà accordés, la rémunération, les acteurs compétents et les conditions de renouvellement.

Ne transposez pas les règles territoriales pour prendre une décision ou paramétrer la paie.

**Niveau de confiance : abstention sur le régime juridique demandé.**
