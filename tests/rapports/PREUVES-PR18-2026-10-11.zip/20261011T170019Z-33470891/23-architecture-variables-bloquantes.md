# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous préparez un tableau d’avancement de grade pour cette année. Vous disposez uniquement du nom de l’agent et de son cadre d’emplois.

**Décision : non tranchable.** Ces informations ne permettent pas d’établir son éligibilité ni de sécuriser une nomination. Je m’abstiens donc de conclure sur ses droits.

Pour poursuivre, pouvez-vous préciser, **sans communiquer son nom** :

- le type d’employeur et son effectif ;
- son statut : titulaire, stagiaire ou contractuel ;
- son **grade actuel**, le **grade visé**, son échelon et les dates correspondantes ;
- son ancienneté et ses services, ainsi que l’éventuelle réussite à un examen professionnel ;
- la date d’effet souhaitée pour la nomination ?

La quotité de travail et l’historique de carrière seront également à réunir pour contrôler le décompte des services.

**Dossier de préparation à confier au service carrière :**

| Contrôle à faire vérifier | Pièces et sources nécessaires |
|---|---|
| Conditions nationales d’accès au grade visé, à la date souhaitée | Code général de la fonction publique et décret statutaire du cadre d’emplois, dans leur version applicable ; arrêtés de carrière et justificatif d’examen éventuel |
| Qualification de l’opération | Vérifier qu’il s’agit bien d’un avancement de grade, et distinguer cette voie de l’avancement d’échelon ou de la promotion interne |
| Cadre local de sélection | Délibération fixant le ratio promus-promouvables, lignes directrices de gestion et éléments d’appréciation de la valeur professionnelle |
| Acteurs et instances | Vérifier les rôles respectifs de l’assemblée délibérante, de l’autorité territoriale, du comité social territorial et le rôle actuel de la commission administrative paritaire |
| Possibilité effective de nomination | Contrôler séparément l’éligibilité, l’inscription au tableau et la nomination ; réunir les données sur l’emploi et les possibilités locales |
| Formalités avant mise en œuvre | Faire vérifier compétence, date d’effet, notification, publicité, transmission éventuelle et recours applicables |

**Recommandation :** ouvrez une fiche de contrôle avec ces pièces, puis faites valider les conditions nationales et le cadre local avant de proposer une nomination. Le risque principal serait de confondre un agent remplissant certaines conditions avec un agent effectivement nommable.

**Niveau de confiance : abstention sur l’éligibilité et la nomination**, faute de données déterminantes et de vérification officielle.
