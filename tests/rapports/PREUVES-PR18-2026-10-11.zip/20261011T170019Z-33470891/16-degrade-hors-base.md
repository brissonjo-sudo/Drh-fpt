# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre demande concerne l’indemnité de feu de sapeurs-pompiers professionnels et son fondement juridique.

**Décision : non tranchable en l’état.** Je ne peux fournir ni montant exact, ni taux, ni référence précise non vérifiés. Le corpus signale un régime indemnitaire spécifique aux sapeurs-pompiers professionnels, mais ne contient pas le texte fixant cette indemnité.

Pour établir une réponse utilisable en paie, le service RH/paie doit réunir :

- **Le champ applicable :** employeur, statut et grade exacts des agents, fonctions exercées.
- **La date et les données de paie :** période concernée, indice majoré, valeur du point à cette date et quotité de travail.
- **Le fondement officiel :** sur Légifrance, le texte régissant le régime indemnitaire des sapeurs-pompiers professionnels, dans sa version applicable, avec l’article relatif à l’indemnité de feu et ses éventuels renvois.
- **L’assiette et les modalités :** vérifier la base de calcul, le taux, les conditions de versement et les éventuelles proratisations ; distinguer les règles nationales des actes locaux pertinents.

**Recommandation :** demander au service paie une fiche de calcul accompagnée de l’article officiel applicable. Une référence issue d’un ancien paramétrage ne suffit pas à confirmer le montant actuel.

**Niveau de confiance : abstention sur le montant et le fondement juridique précis.**
