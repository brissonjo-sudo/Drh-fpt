# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je ne peux donc pas certifier la compétence de l’instance ni celle du décideur.

**Faits connus :** fonctionnaire territorial, accident de service contesté, question portant sur la formation du conseil médical et la décision finale d’imputabilité.

La **piste documentaire à vérifier**, indiquée par le corpus, est la suivante :

- **Formation plénière** pour l’examen de l’imputabilité au service lorsqu’un avis du conseil médical est requis ; la formation restreinte doit être distinguée de ce circuit.
- **Autorité territoriale** pour la décision finale d’imputabilité : l’avis médical et la décision administrative sont deux éléments distincts.
- Le caractère contesté de l’accident ne permet pas, à lui seul, de certifier que la saisine est obligatoire dans votre dossier.

**Décision : non tranchable sans vérification officielle.** Avant toute saisine, faites contrôler par le service RH ou juridique les dispositions applicables du Code général de la fonction publique et des textes territoriaux relatifs au conseil médical et aux accidents de service, dans leur version à la date pertinente.

Réunissez la déclaration d’accident, le certificat médical, les circonstances et dates, les éléments précis de contestation et le statut exact — titulaire ou stagiaire. Le régime contractuel constitue un contrôle distinct.

**Niveau de confiance : abstention sur la conclusion juridique ; orientation documentaire issue du corpus uniquement.**
