# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon « recherche-juridique » étant indisponible, je fournis un cadrage et les contrôles à effectuer, sans certifier les règles applicables.

**Faits connus :** votre service fonctionne selon un cycle annualisé défini il y a plusieurs années. Sa durée, son acte fondateur et ses éventuelles modifications ne sont pas fournis. La date de référence est aujourd’hui, **11 octobre 2026**.

**Décision : non tranchable en l’état.** L’ancienneté du cycle ne permet, à elle seule, ni de valider son maintien ni de conclure qu’il faut l’abandonner. Le contrôle doit distinguer **l’organisation des horaires** du **volume annuel de travail** et des **garanties de repos**.

Les points à faire vérifier sont les suivants :

| Point | Contrôle nécessaire avant de décider |
|---|---|
| **Socle national** | Confirmer la durée annuelle de référence applicable, les règles de décompte et les garanties de travail et de repos : limites quotidiennes, hebdomadaires et moyennes, repos quotidien et hebdomadaire. Je ne fournis aucun seuil non vérifié. |
| **Ancien régime local** | Rechercher si le cycle repose sur un régime historique plus favorable et vérifier les effets des textes ayant imposé leur mise en conformité. Une ancienne délibération ne constitue pas, à elle seule, une preuve de conformité actuelle. |
| **Sujétions particulières** | Si une durée annuelle réduite est pratiquée, contrôler son fondement, les contraintes réellement supportées — nuit, dimanche, horaires décalés, pénibilité ou danger — et leur justification dans les documents locaux. |
| **Organisation annualisée** | Vérifier la délibération applicable, les consultations requises du comité social territorial (CST), les périodes hautes et basses, ainsi que les modalités de décompte des congés et absences. |
| **Application réelle** | Comparer les plannings et heures réalisés avec le cycle adopté ; contrôler le paramétrage du système d’information des ressources humaines (SIRH). |

**Pour lever les variables bloquantes**, réunissez en une fois :

- le type d’employeur, son effectif et le statut des personnels concernés, afin de confirmer le périmètre territorial et de repérer un régime particulier ;
- la délibération initiale, ses modifications, le règlement du temps de travail et les avis d’instance disponibles ;
- la durée annuelle pratiquée, les quotités de travail, un planning représentatif et les éventuelles sujétions invoquées.

La date exacte de création du cycle peut être retrouvée dans ces pièces : elle n’a pas à être supposée.

**La suite utile est un contrôle documentaire, pas encore une modification du cycle :**

1. **Le service et la direction des ressources humaines** rassemblent les actes et décrivent le fonctionnement réel. Résultat attendu : un tableau comparant cycle adopté et cycle pratiqué.
2. **Le référent juridique**, avec le centre de gestion si une assistance est prévue, vérifie sur Légifrance le Code général de la fonction publique, les textes territoriaux sur le temps de travail et les textes propres aux populations concernées, dans leur version applicable.
3. **La DRH** fait confirmer les rôles respectifs de l’assemblée délibérante, de l’autorité territoriale et du CST, puis présente les écarts et les adaptations nécessaires au décideur.

Deux scénarios restent à examiner : **conserver le cycle si sa conformité est établie**, ou **adapter les éléments identifiés comme irréguliers**, sans présumer qu’une refonte complète serait nécessaire.

Le risque principal est de conserver une organisation dont le volume annuel, les repos ou le fondement local ne sont plus conformes. Avant toute mise en œuvre, faire valider les règles, les actes et les paramètres de gestion concernés.

**Niveau de confiance : abstention sur la conformité et le maintien de votre cycle ; contrôles ci-dessus à réaliser.**
