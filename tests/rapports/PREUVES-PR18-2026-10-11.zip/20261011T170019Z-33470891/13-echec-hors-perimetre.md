# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes maire d’une commune d’environ 40 agents et souhaitez consulter un comité social territorial (CST).

Votre commune est **hors du périmètre du corpus DRH fourni**, qui couvre les collectivités de plus de 350 agents. Je ne peux donc pas vous fournir une procédure détaillée ou certifier les délais et formalités.

**Décision : non tranchable en l’état.** Le premier contrôle porte sur le rattachement au CST : il faut vérifier auprès du centre de gestion (CDG) si votre projet relève du CST placé auprès de celui-ci ou d’un autre rattachement applicable. Je ne certifie ici aucun seuil réglementaire.

Pour préparer la consultation, confiez au secrétariat de mairie ou au service RH ce dossier de vérification :

| À faire vérifier | Pièces ou informations à réunir |
|---|---|
| CST compétent et interlocuteur chargé du dossier | Affiliation au CDG, documents de rattachement |
| Nécessité de la consultation et caractère préalable de l’avis | Objet précis du projet, agents concernés, projet de décision ou de délibération |
| Modalités de saisine | Règlement intérieur de l’instance, formulaire, calendrier, pièces et délais demandés |
| Suites de l’avis | Autorité compétente pour décider, éventuelle nouvelle consultation, formalités d’information, de publicité ou de transmission et recours pertinents |

**Sources à contrôler :** le Code général de la fonction publique et ses dispositions réglementaires applicables à la date du projet, puis le règlement intérieur du CST concerné. Les instructions du CDG aideront à constituer le dossier ; leur conformité aux textes reste à contrôler.

Le risque principal est de saisir la mauvaise instance ou d’adopter le projet avant une consultation éventuellement requise.

**Pour préciser l’orientation : quel projet souhaitez-vous soumettre au CST, à quelle date voulez-vous le mettre en œuvre, et votre commune est-elle affiliée au CDG ?**

**Niveau de confiance : abstention sur la procédure juridique ; dossier de préparation uniquement.**
