# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je ne peux donc certifier les voies ouvertes ni fournir une clause de recours prête à envoyer.

**Faits connus :** agent territorial ; exclusion temporaire de fonctions de 5 jours prononcée en 2026. Son statut exact et les dates d’ouverture de la procédure, de décision et de notification ne sont pas précisés.

**Décision : non tranchable sans vérification officielle.** Le corpus oriente vers la **suppression de l’ancien conseil de discipline de recours** pour les sanctions nouvelles. Cette piste doit être confirmée dans les textes applicables avant de finaliser la notification. Il faut distinguer cette ancienne instance du **conseil de discipline préalable**, dont le rôle est à contrôler selon le statut de l’agent et la sanction.

Pour préparer la notification, faites contrôler par le service juridique les points suivants :

| Point | Vérification nécessaire |
|---|---|
| Ancien conseil de discipline de recours | Confronter les textes de suppression et de transition au décret consolidé relatif à la discipline territoriale. Ne pas reprendre automatiquement une ancienne clause. |
| Recours gracieux | Vérifier le recours auprès de **l’auteur de la décision**, ses modalités et son effet sur le délai contentieux. Ne pas inventer un supérieur hiérarchique de l’autorité territoriale. |
| Recours contentieux | Confirmer le **tribunal administratif compétent**, le délai, son point de départ et les modalités de saisine à mentionner. |
| Régime applicable | Confirmer si l’agent est titulaire, stagiaire ou contractuel : ne pas transposer automatiquement les règles d’une population à une autre. |

**Pièces à réunir :** décision signée et motivée, statut de l’agent, dates d’ouverture et de sanction, projet de notification et modalités prévues pour prouver sa remise.

**Sources à consulter :** Code général de la fonction publique, textes consolidés de discipline territoriale et de suppression/transitions, Code des relations entre le public et l’administration et Code de justice administrative.

Avant envoi, le service juridique devra aussi contrôler la compétence du signataire et la motivation. La transmission préfectorale doit être examinée séparément : liste légale actuelle, anciennes versions, convention locale et éventuelles demandes du préfet.

**Risque principal :** utiliser une clause ancienne ou un délai non confirmé. **Niveau de confiance : abstention sur la réponse juridique définitive et la formulation exécutable.**
