# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon recherche-juridique étant indisponible, je fournis un cadrage et un dossier de contrôle, sans certifier les droits de l’agent ni une procédure applicable.

**Faits connus :** l’agent est contractuel en contrat à durée indéterminée (CDI), rémunéré par référence à un indice. Il demande la reprise de toute son ancienneté et un avancement de grade selon le régime des fonctionnaires titulaires.

**État de décision : non tranchable en l’état.** Il manque le contrat, le cadre local de rémunération et la vérification des textes applicables. La demande doit être examinée en distinguant ses deux objets.

**1. Ancienneté et rémunération : ce que le corpus invite à vérifier**

La piste centrale est de **distinguer une référence indiciaire d’un classement statutaire dans un grade**. Il faut contrôler si l’indice sert uniquement à fixer la rémunération ou si le contrat prévoit une évolution particulière, puis vérifier la portée juridique de cette clause.

La « reprise de toute l’ancienneté » doit aussi être précisée : l’agent demande-t-il une augmentation pour l’avenir, une correction de son positionnement initial ou un rappel de rémunération ? Ces demandes ne supposent pas les mêmes contrôles.

Le corpus oriente vers l’examen :

- des clauses du contrat et des avenants concernant l’expérience et l’ancienneté ;
- des fonctions exercées, qualifications et expériences professionnelles pertinentes ;
- du régime de réévaluation applicable au CDI, de son historique et des évaluations professionnelles.

**Point à vérifier :** une obligation de réexaminer la rémunération ne doit pas être assimilée sans contrôle à une augmentation automatique, ni à la reprise intégrale de tous les services antérieurs.

**2. Avancement de grade : une demande à distinguer de l’évolution salariale**

Le corpus invite à contrôler la distinction entre **régime contractuel et carrière du fonctionnaire titulaire** : le CDI et l’indice de référence ne doivent pas être assimilés, sans fondement vérifié, à une titularisation ou à la détention d’un grade.

Pour éviter cette confusion, la DRH devra vérifier les mécanismes propres à l’avancement du titulaire — conditions statutaires, tableau d’avancement, ratios, lignes directrices de gestion et rôle actuel de la commission administrative paritaire — sans les transposer au contractuel.

L’alternative à instruire est une **réévaluation contractuelle de la rémunération**, éventuellement liée à l’expérience ou à l’évolution des fonctions. Si l’objectif est réellement une carrière de fonctionnaire, les voies d’accès correspondantes constituent un examen distinct.

**Marche à suivre : préparer la décision**

| Action de préparation | Responsable et preuve attendue |
|---|---|
| Confirmer l’employeur, son effectif, le régime de droit public, les fonctions et le fondement du recrutement ; préciser la date d’effet et l’éventuelle période réclamée. | DRH : fiche de qualification. |
| Réunir contrat, avenants, justificatifs des services antérieurs, évaluations, décisions salariales et cadre local de rémunération. | Gestionnaire RH : dossier complet, limité aux données utiles. |
| Contrôler les règles nationales et leur éventuelle recodification, puis leur articulation avec les clauses et choix locaux. | Juriste RH : sources officielles et versions applicables, notamment CGFP et dispositions relatives aux contractuels territoriaux. |
| Présenter séparément la réponse à la demande d’ancienneté, à celle de grade et les possibilités de réévaluation. | DRH : note d’arbitrage fondée sur les contrôles précédents. |

Les choix locaux et contractuels restent à examiner dans les limites du cadre national. Avant toute décision ou modification de paie, faire contrôler la compétence du décideur, la formalisation nécessaire, la date d’effet, les conséquences budgétaires et, pour une réponse défavorable, la motivation, la notification et les recours applicables.

**Risque principal :** traiter une rémunération indiciaire comme une carrière statutaire, ou promettre une reprise intégrale sans fondement établi.

**Niveau de confiance : abstention sur les droits individuels ; pistes documentaires à vérifier.**
