# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Le compagnon `recherche-juridique` est indisponible. Je peux préparer le dossier, mais pas conclure juridiquement ni rédiger un arrêté engageant sans les vérifications requises.

**Faits connus**

Vous envisagez une nomination après avancement de grade et demandez un projet d’arrêté. L’employeur, le statut de l’agent, les grades concernés et les dates ne sont pas renseignés. Aucun tableau d’avancement ni document local n’est fourni.

**État de décision : non tranchable.** Des champs à compléter permettent de préparer le document ; ils ne remplacent pas la vérification des conditions de nomination.

**Contrôles nécessaires pour analyser la possibilité de nommer**

| Point | Informations et pièces à réunir | Vérification attendue |
|---|---|---|
| Employeur et agent | Type de collectivité, effectif, éventuel statut particulier ; statut de l’agent et quotité de travail | Confirmer le champ territorial et le régime applicable ; ne pas transposer au contractuel les règles du fonctionnaire |
| Nature de l’évolution | Cadre d’emplois, grade actuel et grade cible | Vérifier qu’il s’agit d’un avancement de grade et distinguer cette voie de la promotion interne et de l’avancement d’échelon |
| Conditions statutaires | Situation de carrière, ancienneté, services retenus, éventuel examen professionnel | Contrôler les conditions dans le statut particulier applicable à la date d’effet envisagée |
| Cadre collectif | Tableau annuel d’avancement, lignes directrices de gestion, délibération fixant le ratio promus-promouvables, données permettant son application | Vérifier séparément les exigences nationales et les choix locaux ; contrôler la portée de l’inscription au tableau pour la nomination |
| Emploi d’accueil | Délibération relative à l’emploi, situation de disponibilité de l’emploi, crédits | Vérifier les conditions permettant une nomination sur cet emploi |
| Acteurs et instances | Documents locaux de compétence et de délégation ; affiliation au centre de gestion si elle influe sur le circuit | Contrôler le rôle respectif de l’autorité territoriale, de l’assemblée et des instances ; vérifier le rôle actuel de la commission administrative paritaire sans présumer une consultation |
| Effet et classement | Date souhaitée, grade et échelon actuels, ancienneté conservée, situation administrative | Vérifier la date admissible et les règles de classement avant toute rédaction ou traduction en paie |

La direction des ressources humaines rassemble ces pièces. Le service juridique ou le centre de gestion sollicité contrôle ensuite le Code général de la fonction publique, le statut particulier et les textes de classement sur Légifrance, dans leur version applicable à la date envisagée. La preuve attendue est le passage officiel pertinent, sa version et la conclusion qu’il soutient.

**Préparation du projet d’arrêté — document non signable**

Le corpus interdit un projet d’acte juridiquement engageant en mode dégradé. Voici donc la fiche de rédaction la plus avancée possible, à transformer en arrêté après validation.

| Élément du futur arrêté | Champ à compléter et contrôle associé |
|---|---|
| Objet | Nomination de `[agent]` au grade de `[grade cible]` par avancement de grade — qualification à valider |
| Employeur et signataire | `[collectivité]` ; `[autorité signataire]` ; `[délégation éventuelle]` — compétence à vérifier |
| Fondements | `[dispositions officielles vérifiées]` ; `[statut particulier]` ; `[textes de classement]` — aucun visa à inventer |
| Pièces locales | `[tableau annuel : année et référence]` ; `[ratio applicable]` ; `[lignes directrices de gestion]` ; `[acte relatif à l’emploi]` |
| Situation antérieure | `[grade]`, `[échelon]`, `[ancienneté]`, `[position et quotité]` |
| Décision envisagée | `[grade cible]`, `[emploi concerné]`, `[date d’effet validée]` |
| Classement | `[échelon d’accueil]`, `[ancienneté conservée]`, `[références indiciaires vérifiées]` — aucun calcul à ce stade |
| Justification | `[éléments établissant les conditions et le choix de nomination]` ; exigences de motivation à contrôler |
| Formalités | `[notification]`, `[publicité applicable]`, `[transmission éventuelle au contrôle de légalité]` — chacune à vérifier |
| Recours | `[mentions applicables après vérification]` — aucune formule prête à notifier à ce stade |

**Avant signature et paie :** valider l’éligibilité, le tableau, le ratio, l’emploi, la compétence, la date d’effet, le classement et les formalités. Les risques à examiner sont une nomination irrégulière et un classement ou une rémunération erronés. Limiter les données personnelles aux informations nécessaires.

**Niveau de confiance : Abstention sur la possibilité juridique de nommer et sur l’arrêté final.**
