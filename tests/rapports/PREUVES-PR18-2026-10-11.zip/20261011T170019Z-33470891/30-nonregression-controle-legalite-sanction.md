# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** fonctionnaire communal, exclusion temporaire de fonctions de 5 jours, question limitée à la transmission au contrôle de légalité. La date de la sanction n’est pas précisée.

**Décision : non tranchable sans vérification.** Je ne peux donc pas certifier un « oui » ou un « non ».

Le corpus invite à vérifier une distinction déterminante : **l’ancienne liste des actes transmissibles visait les sanctions soumises à l’avis du conseil de discipline**, tandis qu’il indique que cette catégorie ne figure plus dans la liste actuelle. Cette indication interne reste une **piste documentaire**, sans valeur de confirmation officielle. La durée de l’exclusion ne suffit donc pas à établir l’obligation de transmission.

Pour trancher, le service juridique ou la direction des ressources humaines doit contrôler :

- la **date de la sanction** et la version de l’article **L. 2131-2 du Code général des collectivités territoriales (CGCT)** applicable à cette date — référence **à confirmer en version consolidée sur Légifrance** ;
- la qualification exacte de l’acte au regard de cette liste ;
- séparément, la convention locale de télétransmission et une éventuelle demande du préfet, sans les confondre avec l’obligation légale invoquée.

**Recommandation :** ne pas fonder la réponse sur une ancienne liste ou sur la seule intervention du conseil de discipline ; faire consigner le passage applicable et le résultat du contrôle.

**Niveau de confiance : abstention sur l’obligation juridique de transmission.**
