# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous demandez la valeur exacte du point d’indice au **11 octobre 2026**, pour l’utiliser dans un arrêté.

**Décision : non tranchable.** Je m’abstiens de donner un chiffre : le corpus impose de vérifier cette valeur avant tout usage dans un acte. Une valeur de mémoire, même accompagnée d’une réserve, ne satisfait pas ce contrôle.

Pour compléter le dossier, le service ressources humaines ou paie devra :

- consulter sur **Légifrance** le texte officiel fixant la valeur du point, dans sa version applicable à la date d’effet de l’arrêté ;
- contrôler l’unité retenue — valeur annuelle ou mensuelle — et conserver la référence, la version et le passage utile ;
- vérifier l’**indice majoré** de l’agent et les paramètres nécessaires avant toute conversion en euros.

Si la date d’effet de l’arrêté diffère d’aujourd’hui, c’est cette date qu’il faudra retenir pour le contrôle.

**Niveau de confiance : abstention sur la valeur exacte.** Le chiffre destiné à l’arrêté reste à compléter après vérification officielle.
