# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable en l’état.** Le nom et le cadre d’emplois ne permettent de confirmer ni l’éligibilité de l’agent, ni sa nomination en **2026**. Il faut distinguer **remplir les conditions**, **être inscrit au tableau** et **être effectivement nommé**.

Pour avancer, pouvez-vous réunir ces trois blocs d’informations ? Le nom n’est pas nécessaire pour cette analyse.

- **Situation de l’agent :** statut — titulaire, stagiaire ou contractuel —, grade actuel, grade visé, échelon et date d’accès à cet échelon, ancienneté et services accomplis, éventuel examen professionnel.
- **Nomination envisagée :** date d’effet souhaitée en 2026 et voie d’avancement envisagée.
- **Cadre local :** type d’employeur et effectif, lignes directrices de gestion applicables, délibération fixant le ratio de promotion, nombre de promouvables et promotions déjà prononcées pour le grade concerné.

Les **extraits officiels archivés fournis**, consultés le **11 octobre 2026**, établissent les règles suivantes :

| Point | Règle établie et conséquence |
|---|---|
| Sélection | L’avancement peut intervenir au choix, après examen professionnel ou par concours professionnel. Au choix, la valeur professionnelle, l’expérience et les lignes directrices de gestion sont prises en compte. [Source](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506) |
| Capacité de promotion | Le maximum de promotions résulte des effectifs promouvables multipliés par le taux fixé par l’assemblée délibérante après avis du **comité social territorial (CST)**. **Ce mécanisme exclut expressément le cadre d’emplois des agents de police municipale** : son régime propre doit alors être vérifié. [Source](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500) |
| Nomination | L’autorité territoriale prononce l’avancement parmi les fonctionnaires inscrits au tableau, **dans l’ordre du tableau**. [Source](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498) |

**J’en déduis que l’éligibilité seule ne garantit pas une nomination cette année.**

La **DRH** doit maintenant :

1. Vérifier le statut particulier du cadre d’emplois, dans sa version applicable à la date envisagée, pour contrôler les conditions exactes d’avancement.
2. Examiner les dossiers selon les **lignes directrices de gestion (LDG)** et contrôler la capacité locale de promotion. Leur rôle en matière de critères d’avancement est confirmé par l’[extrait applicable depuis le 1er août 2026](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251).
3. Avant toute décision, contrôler l’emploi disponible, les formalités du tableau et le rôle actuel de la **commission administrative paritaire (CAP)**. Le corpus métier indique l’absence de consultation préalable pour l’avancement, mais la source officielle correspondante n’est pas fournie.

Pour une nomination ou un éventuel refus, restent également à vérifier les exigences de motivation, notification, voies et délais de recours, publicité et transmission.

**Confiance : règles générales étayées par les extraits fournis ; décision individuelle suspendue aux pièces et vérifications manquantes.** Aucune nouvelle consultation n’a été effectuée.
