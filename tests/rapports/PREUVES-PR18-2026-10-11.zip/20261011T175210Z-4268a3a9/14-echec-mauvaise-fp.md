# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Le corpus fourni ne permet pas de déterminer ce régime : votre CHU relève de la fonction publique hospitalière, tandis que le corpus DRH couvre la fonction publique territoriale.** L’effectif de 900 agents ne change pas cette limite.

Mode dégradé : aucune source officielle n’a été consultée pour cette réponse.

**Faits connus :** employeur hospitalier, agent titulaire, arrêt maladie depuis 8 mois. Cette durée seule ne permet pas de déterminer le congé applicable.

**Décision : non tranchable avec ce corpus.** Je ne peux pas vous donner les conditions du congé de longue maladie, sa durée, sa rémunération ou sa procédure en transposant les règles territoriales.

Pour préparer la réponse, le service chargé de la carrière doit réunir :

- le corps et le statut exacts de l’agent ;
- la date de début de l’arrêt et les décisions de congé déjà prises ;
- la nature du congé actuellement accordé et l’existence éventuelle d’une demande de congé de longue maladie.

Il devra ensuite consulter les dispositions du **Code général de la fonction publique propres au versant hospitalier** et les textes applicables aux congés des titulaires hospitaliers, dans leur version aux dates utiles. Le contrôle devra porter sur l’éligibilité, les droits à rémunération, le circuit médical et l’autorité décisionnaire, puis les garanties de notification et de recours.

**Niveau de confiance : abstention sur le régime juridique demandé**, faute de sources hospitalières dans le corpus.
