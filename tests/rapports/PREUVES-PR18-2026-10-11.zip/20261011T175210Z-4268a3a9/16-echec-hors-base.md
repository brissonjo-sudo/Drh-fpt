# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**L’indemnité de feu est fixée à 25 % du traitement soumis à retenue pour pension.** Le montant en euros dépend donc du traitement de chaque sapeur-pompier professionnel.

**Fondement :** [décret n° 90-850 du 25 septembre 1990 portant dispositions communes aux sapeurs-pompiers professionnels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025), disposition dans sa version en vigueur depuis le **26 juillet 2020**, applicable au **11 octobre 2026** selon la consultation officielle archivée fournie.

Le passage précise qu’ils « peuvent percevoir […] une indemnité de feu d’un taux de 25 % du traitement soumis à retenue pour pension ».

**Calcul :**

> Indemnité de feu = traitement soumis à retenue pour pension × 0,25

L’assiette est ce traitement, pas la rémunération totale avec toutes les primes. Pour une conversion à partir de l’indice, il faut connaître **l’indice majoré et la valeur du point applicable à la période concernée**.

**Montant individuel en euros : non tranchable en l’état.** Quel est le traitement soumis à retenue pour pension figurant sur le bulletin de paie pour la période concernée ?

Le taux est établi par l’extrait fourni. Les conditions d’attribution restent à contrôler : le décret renvoie à l’article 17 de la loi du 28 novembre 1990, dont le contenu n’est pas fourni dans ce dossier.
