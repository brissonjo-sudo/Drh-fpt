# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Pour une commune d’environ 40 agents, commencez par identifier le comité social territorial (CST) compétent auprès de votre centre de gestion (CDG).**

Le texte officiel fourni prévoit :

- un CST propre pour chaque collectivité employant **au moins 50 agents** ;
- un CST auprès du CDG pour les collectivités **affiliées employant moins de 50 agents**.

Votre rattachement doit donc être confirmé : votre affiliation au CDG n’est pas indiquée, et l’effectif annoncé est approximatif.

**État de décision : non tranchable pour la procédure précise.** Votre commune est hors du périmètre du corpus DRH fourni, consacré aux collectivités de plus de 350 agents. Je peux vous orienter grâce au texte officiel disponible, mais ce dossier ne permet pas de détailler une procédure de consultation applicable à votre commune.

Pour avancer, **demandez au secrétariat du CDG** de confirmer :

- le CST compétent pour votre commune ;
- si votre projet nécessite sa consultation ;
- le formulaire de saisine, les pièces nécessaires et le calendrier ;
- les règles actuelles de présentation du dossier, de recueil de l’avis et les suites à donner avant votre décision.

Préparez pour cette demande **l’objet exact du projet, son document préparatoire et la date de mise en œuvre envisagée**. Il s’agit de pièces de préparation, sans certification ici des formalités obligatoires.

Source : [extrait du Code général de la fonction publique fourni au dossier](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312), version applicable depuis le 01/01/2023, consultation officielle archivée le 11/10/2026.

**Confiance : stable sur le seuil et l’orientation générale ; procédure détaillée non vérifiable avec ce corpus.**
