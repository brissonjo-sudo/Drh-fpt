# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne donne pas à cet agent une carrière de fonctionnaire titulaire.** Sa demande doit être examinée comme une demande d’évolution de sa rémunération contractuelle, en distinguant reprise d’expérience, réévaluation et avancement de grade.

Analyse au **11 octobre 2026**, fondée uniquement sur les extraits officiels et les traces de consultation fournis.

**1. Ce que l’agent peut demander**

- **La prise en compte de son expérience professionnelle.** L’autorité territoriale fixe sa rémunération en tenant compte notamment des fonctions, des qualifications et de l’expérience. Ces critères ne prévoient pas une reprise automatique, année pour année, de toute son ancienneté. Il faut examiner les services accomplis, leur rapport avec les fonctions actuelles et les clauses du contrat.
- **Une réévaluation de sa rémunération.** Pour un agent en contrat à durée indéterminée (CDI), elle est obligatoire **au moins tous les trois ans**, notamment au regard des entretiens professionnels ou de l’évolution des fonctions. **Cette obligation d’examen ne garantit pas une augmentation.**
- **Un avancement de grade “comme un titulaire”.** J’en déduis que la seule référence indiciaire ne permet pas de lui appliquer le déroulement de carrière d’un fonctionnaire : elle fixe une référence de rémunération, sans lui conférer un grade. Une hausse peut être étudiée dans son régime contractuel, sans la qualifier d’avancement statutaire.

Sources : [disposition du CGFP relative à la rémunération des contractuels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), version applicable depuis le 01/03/2022 ; [disposition du décret n° 88-145 relative à la rémunération et à sa réévaluation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), version applicable depuis le 01/07/2026. Consultations archivées fournies du 11/10/2026 — fonctions juridiques : critères de fixation et obligation de réévaluation.

**Attention à une exception :** le second extrait prévoit un classement particulier pour certains emplois de direction mentionnés à l’article L. 343-1 du CGFP. Si l’agent occupe un tel emploi, les textes spécifiques auxquels il renvoie doivent être vérifiés avant de conclure sur son classement.

**2. État de décision**

**Possible sous conditions :** instruire une évolution de rémunération fondée sur l’expérience, les fonctions et les résultats professionnels.

**Non tranchable en l’état :** le niveau de rémunération à retenir, une éventuelle obligation contractuelle de reprise d’ancienneté et la date d’effet. Les pièces individuelles et le cadre local manquent. Aucun avancement de grade de titulaire ne peut être accordé sur le seul motif d’une rémunération indiciaire.

**3. Marche à suivre**

1. **La DRH rassemble le dossier :** contrat et avenants, fondement du recrutement, emploi occupé, quotité de travail, clause indiciaire exacte, cadre local de rémunération, justificatifs des expériences antérieures, date et contenu de la dernière réévaluation.  
   Point de contrôle : confirmer le régime de droit public territorial et identifier un éventuel emploi de direction particulier.

2. **Le supérieur hiérarchique documente les fonctions et les résultats :** responsabilités actuelles, évolutions du poste, qualifications et expérience utile. Pour un agent recruté sur un emploi permanent en CDI, l’entretien professionnel est annuel et donne lieu à un compte rendu établi par le supérieur hiérarchique direct.  
   Source : [disposition relative à l’entretien professionnel](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), version applicable depuis le 01/01/2023, consultation archivée du 11/10/2026 — fonction juridique : évaluation professionnelle.

3. **La DRH prépare une proposition argumentée pour l’autorité territoriale**, qui fixe la rémunération : maintien après examen, revalorisation ou adaptation liée à des fonctions nouvelles. Elle distingue l’obligation nationale de réévaluation des possibilités ouvertes par le contrat et le cadre local.

4. **Avant toute signature ou mise en paie**, vérifier le support juridique de la modification, sa date d’effet et, si une conversion en euros est nécessaire, l’indice retenu et la valeur du point applicable. Le corpus ne permet pas de chiffrer cette évolution.

5. **Notifier une réponse individualisée.** Avant un éventuel refus, faire vérifier les règles de motivation applicables, la notification et les voies et délais de recours : les sources fournies ne permettent pas de les certifier. La commission consultative paritaire mentionnée dans l’extrait intervient pour la révision du compte rendu d’entretien ; cet extrait ne démontre pas une consultation préalable obligatoire sur la rémunération.

**Pièces à préciser pour trancher :** pouvez-vous fournir les clauses de rémunération du contrat et des avenants, l’emploi occupé, l’historique des services et la date de dernière réévaluation ?

**Confiance : stable** sur les critères de rémunération et l’obligation triennale établis par les extraits ; **à vérifier** sur les droits individuels issus du contrat, le régime particulier éventuel et les formalités de décision.
