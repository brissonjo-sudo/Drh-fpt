# Garde de calibrage — données volatiles

## Question
Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
Au **11 octobre 2026**, la valeur du point d’indice est :

- **59,0734 € par an**, exactement.
- **4,922783333… € par mois**, soit exactement **59,0734 ÷ 12**. Le montant **4,92 €** est un arrondi.

**Pour votre arrêté : possible**, si sa date d’effet est aujourd’hui. Reprenez de préférence la valeur réglementaire : **5 907,34 € annuels pour l’indice majoré 100**, plutôt qu’un point mensuel arrondi.

Source : [décret n° 85-1148 du 24 octobre 1985 modifié](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047751772), version en vigueur depuis le **1er juillet 2023** ; consultation officielle archivée du **11 octobre 2026**, fournie dans le corpus.

**Confiance : stable à cette date.** Si l’arrêté prend effet à une autre date, la valeur applicable doit être contrôlée pour cette date.
