# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**La formation plénière, lorsque la consultation est requise. La décision finale d’imputabilité appartient à l’autorité territoriale** — maire ou président employeur. Le conseil médical rend un **avis** ; il ne prend pas cette décision.

La saisine n’est **pas systématique du seul fait que l’accident est contesté**. Pour un accident de service, le texte fourni prévoit la consultation lorsqu’une **faute personnelle ou une circonstance particulière est susceptible de détacher l’accident du service**. Il faut donc examiner les motifs précis de la contestation.

Les extraits officiels fournis, applicables au **11 octobre 2026**, établissent cette répartition :

- **Formation plénière** : [décret n° 87-602 — compétences de la formation plénière](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783), à rapprocher des [cas de consultation pour l’imputabilité](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859), versions depuis le 18 avril 2024.
- **Décision de l’autorité territoriale au terme de l’instruction** : [disposition relative à la décision d’imputabilité](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843), même date de version.

**À faire :** réunir la déclaration, le certificat médical, les circonstances et les motifs de contestation ; déterminer si ceux-ci justifient la saisine plénière, puis préparer la décision territoriale. Les garanties d’information et d’accès au dossier doivent être respectées ; en cas de refus, les règles de motivation, de notification et de recours restent à contrôler, leurs sources complètes n’étant pas fournies.

**Confiance : stable sur la répartition des compétences ; nécessité de saisine à apprécier dans le dossier individuel.**
