# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**L’avancement de grade est possible sous conditions. La nomination de cet agent reste non tranchable tant que son éligibilité et les pièces locales ne sont pas renseignées.** Le projet ci-dessous est donc une trame à compléter, **non prête à signer**.

Analyse au **11 octobre 2026**, fondée exclusivement sur les extraits officiels et leurs traces de consultation fournis dans le corpus. Aucune consultation supplémentaire n’a été effectuée.

**Conditions à réunir**

Le dossier doit confirmer qu’il s’agit d’un **fonctionnaire territorial titulaire**, préciser son employeur, son cadre d’emplois, ses grades actuel et cible, son ancienneté et la date d’effet souhaitée. Le projet concerne un avancement de grade ; si l’opération change de cadre d’emplois, sa qualification et son fondement doivent être réexaminés.

Les extraits officiels permettent d’établir les points suivants :

- **Tableau annuel d’avancement** : selon la voie applicable, l’avancement repose sur le choix, un examen professionnel ou un concours professionnel. Au choix, l’autorité apprécie la valeur professionnelle et les acquis de l’expérience, en tenant compte des lignes directrices de gestion — **LDG**.
- **Ratio de promotion** : le nombre maximal de promotions résulte du nombre de fonctionnaires remplissant les conditions, multiplié par le taux fixé par l’assemblée délibérante après avis du **comité social territorial — CST**. Le texte exclut expressément le **cadre d’emplois des agents de police municipale** : son régime doit être vérifié séparément.
- **Décision individuelle** : l’autorité territoriale prononce l’avancement parmi les agents inscrits au tableau, **dans l’ordre de celui-ci**. L’inscription ne constitue donc pas, à elle seule, une nomination.
- **Emploi assigné** : l’agent doit accepter l’emploi qui lui est attribué dans son nouveau grade.
- **Date d’effet** : la décision peut prévoir une date antérieure à son caractère exécutoire. Cette possibilité ne permet pas de contourner les autres conditions d’avancement.

Sources : CGFP, extraits [tableau et modalités](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), [ratio et CST](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), [autorité et ordre du tableau](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), [acceptation de l’emploi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496), [date d’effet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425494), versions depuis le **1er mars 2022**, consultations archivées du **11 octobre 2026**.

Les LDG déterminent les orientations et critères généraux de promotion et de valorisation des parcours : [extrait réglementaire du CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251), version depuis le **1er août 2026**, consultation archivée du **11 octobre 2026**.

**Ce qui reste à vérifier avant signature**

La DRH doit réunir, dans cet ordre :

1. **Le statut particulier applicable** : conditions d’ancienneté, d’échelon et, le cas échéant, d’examen ; pièces établissant que l’agent les remplit à la date utile.
2. **Les pièces collectives** : LDG applicables, tableau annuel signé et rang de l’agent, délibération sur le ratio et avis du CST lorsque ce régime s’applique.
3. **Les contrôles de procédure** : rôle actuel de la commission administrative paritaire — **CAP** — et modalités d’établissement des LDG. Le corpus métier indique l’absence de consultation préalable de la CAP sur l’avancement, mais les extraits officiels fournis ne permettent pas de confirmer ce point.
4. **L’emploi et le classement** : situation de l’emploi au tableau des effectifs, financement, acceptation par l’agent, règles de reclassement, échelon et ancienneté conservée.
5. **L’acte** : compétence du signataire et délégation éventuelle, date d’effet, notification, publicité applicable et traitement en paie.

Aucun échelon, indice ou calcul de rémunération ne peut être fixé avec le présent dossier.

**Contrôle de légalité et garanties**

Pour une **commune**, j’en déduis que la nomination d’un titulaire par avancement de grade **n’est pas soumise à transmission obligatoire pour ce seul motif** : elle ne doit pas être assimilée au recrutement d’un agent non titulaire. Le délai de quinze jours ne doit donc pas être appliqué automatiquement.

Source : [CGCT, art. L. 2131-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), fonction : catégories d’actes transmissibles ; version depuis le **1er juillet 2022**, consultation archivée du **11 octobre 2026**.

Il faut distinguer cette liste légale d’une transmission volontaire ou d’une pratique locale. Le préfet peut également demander communication d’un acte hors liste : [extrait du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), même version et date de consultation. Pour un autre employeur territorial, le régime de transmission reste à vérifier.

La motivation obligatoire doit être appréciée selon la nature exacte de la décision. **Un refus d’avancement ne relève pas automatiquement du refus d’un avantage constituant un droit.** S’il entre dans une catégorie imposant une motivation, celle-ci doit exposer par écrit les considérations de droit et de fait.

Sources : CRPA, [catégories de décisions à motiver](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [contenu de la motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le **1er janvier 2016**, consultations archivées du **11 octobre 2026**.

---

**Projet d’arrêté — champs et fondements à compléter**

**[COLLECTIVITÉ / ÉTABLISSEMENT]**  
**Arrêté n° [référence] portant avancement au grade de [grade cible] de [identité de l’agent]**

**[Autorité territoriale compétente]**,  

Vu le code général de la fonction publique, notamment ses dispositions relatives aux modalités de l’avancement de grade, au tableau d’avancement, à l’ordre des promotions et à l’acceptation de l’emploi assigné ;

Vu **[texte statutaire particulier du cadre d’emplois : référence et dispositions applicables, à vérifier]** ;

Vu les lignes directrices de gestion applicables, arrêtées le **[date]** ;

Vu **[si applicable : délibération fixant le taux de promotion, référence et date, après avis du CST du …]** ;

Vu le tableau annuel d’avancement au grade de **[grade cible]**, établi pour l’année **[année]** le **[date]**, sur lequel figure **[identité]** au rang **[rang]** ;

Vu **[actes ou pièces relatifs à l’emploi d’affectation, à préciser après vérification]** ;

Vu l’acceptation de cet emploi par l’agent, établie le **[date et pièce]** ;

Considérant que **[identité]**, fonctionnaire titulaire du grade de **[grade actuel]**, remplit les conditions statutaires d’avancement au **[date utile]**, ainsi qu’il ressort de **[pièces justificatives]** ;

Considérant que la nomination respecte l’ordre du tableau et **[le contingent de promotions applicable / le régime particulier vérifié]** ;

**ARRÊTE**

**Article 1 — Avancement de grade**

À compter du **[date d’effet vérifiée]**, **[identité]** est nommé(e), par avancement de grade selon la voie **[choix / examen professionnel / concours professionnel]**, au grade de **[grade cible]**, dans le cadre d’emplois de **[cadre d’emplois]**.

**Article 2 — Classement**

L’agent est classé au **[échelon]**, avec **[ancienneté conservée]**, conformément à **[dispositions de classement vérifiées]**.

Les indices applicables sont : **[indice brut]** et **[indice majoré]**.

*Ces champs sont à renseigner uniquement après contrôle du statut particulier, de la grille et de la fiche de classement.*

**Article 3 — Affectation**

L’agent est affecté à l’emploi de **[intitulé]**, au sein de **[service]**, selon les caractéristiques suivantes : **[temps complet / durée de l’emploi à temps non complet ; autres éléments utiles]**.

**Article 4 — Notification et formalités**

Le présent arrêté est notifié à l’agent. Les formalités de publicité applicables sont accomplies selon **[modalités à vérifier]**.

**[Clause de transmission à retenir après contrôle de l’employeur et de la nature exacte de l’acte ; ne pas inscrire automatiquement une transmission obligatoire.]**

**Article 5 — Recours**

Le présent arrêté peut faire l’objet d’un recours devant le tribunal administratif de **[juridiction compétente]**, dans un délai de **deux mois à compter de sa notification**.

**Article 6 — Exécution**

**[Responsables compétents]** sont chargés, chacun en ce qui le concerne, de l’exécution du présent arrêté.

Fait à **[lieu]**, le **[date]**.  
**[Qualité, nom et signature de l’autorité compétente]**

---

La clause de recours repose sur les extraits du CJA relatifs au [délai de deux mois](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le **1er janvier 2020**, et à la [mention des voies et délais dans la notification](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le **1er janvier 2001** ; consultations archivées du **11 octobre 2026**.

**Avant utilisation :** compléter les pièces, retirer les annotations de travail, vérifier chaque visa et le classement, confirmer les formalités et la juridiction compétente. Limiter les données personnelles aux informations nécessaires.

**Confiance : stable sur les règles couvertes par les extraits archivés ; nomination individuelle et arrêté final à vérifier.** Si la date d’effet relève d’une autre période, les versions applicables devront également être contrôlées.
