# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Vous pouvez conserver une organisation annualisée, sous conditions. En revanche, la conformité de votre cycle actuel est non tranchable sans examiner la délibération et les horaires réellement pratiqués.** Son ancienneté ne suffit ni à l’invalider ni à garantir sa légalité.

Analyse au **11 octobre 2026**, fondée uniquement sur les extraits officiels archivés fournis. Le socle ci-dessous concerne les agents territoriaux relevant du droit commun ; un régime particulier doit être contrôlé séparément.

**Les règles nationales à respecter**

Pour un agent à temps complet, la référence est **35 heures par semaine et 1 607 heures annuelles**, sans préjudice des heures supplémentaires et des réductions régulièrement accordées pour sujétions. L’annualisation permet des semaines de durées différentes : elle doit respecter le décompte annuel et les garanties de repos.

Le décret relatif à la fonction publique de l’État s’applique ici **par le renvoi du décret territorial**, avec les adaptations propres à la fonction publique territoriale. Ce renvoi ne transfère pas aux ministres la décision sur votre cycle local.

Sources : [durée de référence](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142), version depuis le 01/01/2023 ; [renvoi territorial](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version depuis le 14/07/2001 ; consultations archivées du 11/10/2026.

Les garanties suivantes s’appliquent **à chaque période concernée**, même si le total annuel est respecté :

| Point contrôlé | Règle nationale |
|---|---|
| Travail quotidien effectif | Maximum **10 heures** |
| Amplitude de la journée | Maximum **12 heures** |
| Travail hebdomadaire, heures supplémentaires comprises | Maximum **48 heures** sur une semaine |
| Moyenne hebdomadaire | Maximum **44 heures** sur toute période de **12 semaines consécutives** |
| Repos quotidien | Minimum **11 heures** |
| Repos hebdomadaire | Minimum **35 heures**, comprenant en principe le dimanche |
| Pause | Minimum **20 minutes** avant que le travail quotidien atteigne **6 heures** |

Source : [garanties minimales](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150), version depuis le 01/01/2023, consultation archivée du 11/10/2026.

**J’en déduis qu’une période creuse ne régularise pas une semaine dépassant ces plafonds ou un repos insuffisant.** Une délibération locale ne peut pas, à elle seule, autoriser ces dépassements. Le texte prévoit des dérogations encadrées : dispositif réglementaire spécifique pour certaines exigences permanentes du service public, ou circonstances exceptionnelles justifiant une décision limitée dans le temps, avec information immédiate des représentants du personnel. Une organisation récurrente ne peut pas être justifiée comme une exception ponctuelle.

Le décompte doit également correspondre au **travail effectif** : temps pendant lequel l’agent reste à disposition de l’employeur, suit ses directives et ne peut vaquer librement à ses occupations personnelles. Pour les pauses, il faut donc examiner les contraintes réelles, au-delà de leur intitulé dans le planning.

Source : [définition du travail effectif](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version depuis le 29/06/2006, consultation archivée du 11/10/2026.

**Ce qui relève de votre collectivité**

- **Le cycle annualisé** : ses conditions de mise en place sont déterminées par l’organe délibérant, **après avis du comité social territorial (CST)**. Il faut retrouver la délibération, ses annexes et ses éventuelles modifications. [Source](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472), version depuis le 01/01/2023.
- **Une réduction de la durée annuelle** : elle est possible pour des sujétions réelles liées aux missions et aux cycles — notamment nuit, dimanche, horaires décalés, travail en équipes, modulation importante ou travaux pénibles ou dangereux — par décision de l’organe délibérant après avis du CST. Elle n’est pas automatique. [Source](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477), version depuis le 01/01/2023.

Ces deux sources ont fait l’objet de consultations archivées le 11/10/2026. **Réduire la durée annuelle pour sujétions ne dispense pas de respecter les garanties quotidiennes et hebdomadaires.**

Le corpus ne fournit pas la source officielle relative à la suppression de certains anciens régimes dérogatoires. **La possibilité de maintenir un avantage historique reste donc à vérifier spécifiquement** ; elle ne peut pas être déduite de sa seule présence dans une ancienne délibération.

**Pour décider du maintien de votre organisation**

Je recommande ce contrôle, avant de modifier ou de reconduire le dispositif :

1. **DRH** : réunir la délibération, les avis d’instance, les annexes horaires et la justification des éventuelles réductions annuelles.
2. **DRH et responsable du service** : comparer les plannings et heures réellement effectuées aux bornes nationales, notamment sur les semaines hautes et les périodes glissantes de douze semaines.
3. **Collectivité** : conserver le cycle si ces contrôles sont satisfaits ; sinon, préparer les ajustements et, si les conditions de mise en place du cycle changent, les soumettre au CST puis à l’organe délibérant. Les formalités de publicité et de transmission éventuelle restent à vérifier avant mise en œuvre.

Pour trancher votre cas, pouvez-vous préciser en une réponse :

- **Quel employeur, quel effectif et quelles populations** sont concernés : fonctionnaires/contractuels, quotités, éventuel régime particulier ?
- **Que prévoit la délibération actuelle** : date, durée annuelle, réduction pour sujétions et avis de l’instance compétente ?
- **Quels sont les horaires les plus chargés** : travail quotidien, amplitude, maximum hebdomadaire, pauses et repos ?

**Confiance : stable sur le socle national documenté ; à vérifier sur le maintien de votre cycle local.** Le contrôle doit porter sur les règles écrites et sur leur application réelle.
