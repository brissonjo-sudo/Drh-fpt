# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Une exclusion de 5 jours relève du deuxième groupe : le conseil de discipline doit être consulté avant toute sanction.** Vous pouvez envisager d’engager une procédure, mais les seuls soupçons ne permettent pas de recommander dès maintenant cette exclusion.

**État de décision : possible sous conditions pour l’engagement ; non tranchable, à ce stade, pour la sanction.** L’analyse ci-dessous concerne un fonctionnaire titulaire relevant de la fonction publique territoriale. Elle repose exclusivement sur les consultations officielles archivées dans votre corpus, au **11 octobre 2026**.

**Les règles établies**

- **Échelle et consultation préalable.** Une exclusion de **4 à 15 jours** appartient au deuxième groupe. Contrairement à l’exclusion maximale de 3 jours du premier groupe, elle exige une consultation préalable du conseil de discipline. Celui-ci donne un avis ; l’autorité territoriale prend ensuite une décision motivée. Sources : [CGFP, art. L. 533-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), version depuis le 01/03/2022 ; [consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), même date de version ; [décret disciplinaire, avis et décision](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042650806), version depuis le 10/12/2020.
- **Prescription.** La procédure ne peut être engagée au-delà de **3 ans après la connaissance effective de la réalité, de la nature et de l’ampleur des faits par l’administration**. Il faut donc établir cette date, et pas seulement celle des faits. Les poursuites pénales interrompent ce délai selon les conditions du texte ; un simple soupçon pénal ne suffit pas à établir cette interruption. Source : [CGFP, art. L. 532-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430), version depuis le 01/03/2022, applicable à la date d’analyse.
- **Défense.** L’agent doit être informé par écrit de la procédure et des faits reprochés. Il bénéficie de l’accès à l’intégralité de son dossier et des annexes, de l’assistance de défenseurs de son choix et d’un temps suffisant pour préparer sa défense. Les pièces doivent être numérotées. Sources : [CGFP, garanties de défense](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000052323864), version depuis le 01/10/2025 ; [décret disciplinaire, information et dossier](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836), version depuis le 11/12/2025.

**Ma recommandation : préparer le dossier, vérifier que l’engagement est encore possible, puis ouvrir une procédure contradictoire si les éléments recueillis le justifient.** Gardez les 5 jours comme une sanction envisagée, dont le bien-fondé sera réexaminé après la défense et l’avis du conseil. Une sanction moins sévère ou l’abandon de la procédure restent des issues à examiner selon les éléments établis.

Pour appliquer cette recommandation au dossier, il manque trois ensembles d’informations :

1. **Employeur et circuit :** quelle collectivité ou quel établissement, quel effectif, quelle affiliation au centre de gestion, et quel cadre d’emplois ?
2. **Dates :** quand les faits ont-ils eu lieu, quand l’administration en a-t-elle connu précisément la portée, et une procédure est-elle déjà ouverte ?
3. **Éléments disponibles :** quels faits précis, quelles pièces, quelles explications déjà recueillies et quelles éventuelles poursuites pénales ?

Ces éléments conditionnent la prescription, le circuit compétent et la justification d’une sanction.

**Les actions à lancer, dans cet ordre**

| Ordre | Action et responsable | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : constituer une chronologie factuelle.** Rassembler rapports, pièces et témoignages ; distinguer ce qui est constaté de ce qui reste allégué. | Documenter les dates des faits et de connaissance effective. Vérifier la prescription et les éventuelles poursuites pénales. |
| **2** | **DRH et service juridique : confirmer le régime et les compétences.** Identifier l’autorité disciplinaire, le signataire et le secrétariat du conseil compétent. | Vérifier les habilitations ou délégations, l’affiliation et les règles de composition applicables au cadre d’emplois. Ne pas présumer le circuit du centre de gestion. |
| **3** | **Autorité compétente : décider de l’engagement**, après les contrôles précédents. Adresser l’information écrite et organiser l’accès au dossier. | Conserver la preuve de remise, l’inventaire numéroté et les traces d’accès ou de communication. Prévoir un délai de défense réellement suffisant, sans durée arbitraire. |
| **4** | **Avant tout recueil d’observations : sécuriser les garanties de défense.** Permettre l’assistance et recueillir les explications utiles. | **Faire vérifier l’information sur le droit de se taire avant l’audition** : les sources officielles fournies ne permettent pas d’en certifier le régime actuel. Examiner les éléments favorables comme défavorables. |
| **5** | **Si une sanction de 5 jours reste envisagée : préparer la saisine du conseil de discipline.** Le président convoque le conseil et l’agent. | La convocation de l’agent doit intervenir par lettre recommandée avec avis de réception **au moins 15 jours avant la réunion**. L’autorité disciplinaire ne peut siéger. Vérifier composition, convocation et réception. |
| **6** | **Après l’avis : autorité territoriale et DRH, réexaminer puis formaliser la décision.** | Contrôler les faits retenus, leur qualification, la justification de la durée et la proportionnalité. Écrire les motifs de droit et de fait ; conserver l’avis et sa communication. |
| **7** | **DRH : notifier et organiser l’exécution.** Coordonner avec le service et la paie si une exclusion est prononcée. | Vérifier dates exactes, notification traçable, conséquences administratives et financières, voies et délais de recours, ainsi que le régime de transmission applicable. |

Les règles de convocation et de fonctionnement figurent dans les extraits du [décret disciplinaire sur la convocation de l’agent](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372226), version depuis le 19/09/1989, et sur [la présidence et le secrétariat](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222), version depuis le 03/12/1996. La motivation écrite en droit et en fait est confirmée par les [articles relatifs aux sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et à [la teneur de la motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513) du CRPA, versions depuis le 01/01/2016.

**Trois contrôles à conserver avant mise en œuvre**

- **Recours :** le corpus métier signale la suppression de l’ancien conseil de discipline de recours. Les textes de suppression et la structure consolidée correspondante ne sont pas fournis : cette suppression n’est donc pas vérifiable ici. Ne pas confondre cette ancienne instance avec le **conseil préalable**, dont la consultation est confirmée. Faire vérifier les recours administratifs actuels, le tribunal compétent et les délais avant de rédiger la notification ; aucune clause prête à envoyer ne peut être certifiée avec ce dossier.
- **Contrôle de légalité :** **si l’employeur est une commune**, une exclusion disciplinaire de 5 jours n’entre pas, par sa seule nature, dans la liste actuelle de transmission obligatoire de [l’article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), version depuis le 01/07/2022. Distinguer cette liste des anciennes versions, d’une pratique locale et d’une demande du préfet. Celui-ci peut demander communication d’actes hors liste selon [le texte fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), même date de version. Pour un autre employeur territorial, le régime reste à vérifier.
- **Confidentialité :** limiter les pièces et les destinataires aux besoins du dossier ; éviter toute diffusion nominative inutile.

**Confiance : élevée sur le groupe de sanction, la consultation préalable et les garanties expressément documentées. La décision individuelle reste non tranchable tant que les faits, les dates et le circuit compétent ne sont pas établis.**
