# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non. La présomption de démission de 2022 ne s’applique pas à votre agent titulaire.** Elle concerne les salariés de droit privé, y compris ceux employés par une personne publique. Un fonctionnaire territorial relève d’un autre régime : le **licenciement pour abandon de poste, emportant radiation des cadres**.

Cette distinction ressort des extraits officiels fournis : [champ du Code du travail](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006900781), [présomption de démission — article L. 1237-1-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104) et [licenciement du fonctionnaire — article L. 553-1, 1° du Code général de la fonction publique](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184), versions applicables au 11 octobre 2026 selon les traces du dossier.

**Plusieurs semaines d’absence sans justificatif ne suffisent pas, à elles seules, à autoriser la radiation.** Il faut notamment :

- une **mise en demeure écrite et notifiée**, demandant la reprise du service ;
- un **délai approprié**, fixé par l’administration selon la situation ;
- l’avertissement explicite du risque de **radiation des cadres sans procédure disciplinaire préalable** ;
- à l’échéance, le constat de la reprise ou de la non-reprise, puis l’examen des réponses, intentions et éventuels justificatifs médicaux ou matériels.

Sources : [Conseil d’État, Section, 11 décembre 1998, nos 147511 et 147512](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335), pour les garanties de la mise en demeure ; [Conseil d’État, 26 septembre 2014, n° 365918](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000029504219), pour le délai approprié.

Il s’agit d’une **fin de fonctions non disciplinaire** : pas de conseil de discipline ni de communication du dossier au titre des garanties disciplinaires. Cela ne dispense pas de respecter les conditions de l’abandon de poste. Une réponse de l’agent refusant la reprise ne préserve pas automatiquement le lien avec le service ; inversement, la non-reprise ne dispense pas d’examiner ses raisons. L’[arrêt de la CAA de Versailles du 14 avril 2026, n° 24VE00726, points 11 à 13](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000053906348) l’illustre dans une affaire concernant un fonctionnaire de l’État, sans rendre ses circonstances automatiquement transposables.

**Décision : présomption de démission impossible ; radiation non tranchable en l’état.** Faites réunir par les ressources humaines la chronologie, les échanges et les preuves de notification. Avant tout arrêté, restent à vérifier la compétence du signataire, la motivation, la date d’effet, la notification, les voies et délais de recours et le régime de transmission. Le dossier fourni ne permet pas de certifier ces derniers points.

**Avez-vous déjà notifié une mise en demeure : avec quelle échéance, quel avertissement et quelle réponse éventuelle de l’agent ?**

Confiance élevée sur l’exclusion du régime privé ; qualification individuelle encore à établir.
