# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non, selon le droit en vigueur au 11 octobre 2026.** Une exclusion temporaire de fonctions de **5 jours** infligée à un fonctionnaire communal n’est pas obligatoirement transmissible au contrôle de légalité au titre de l’article **L. 2131-2 du CGCT**.

La liste actuelle ne comporte plus de catégorie visant les sanctions disciplinaires. Son **I, 5°** concerne certaines décisions de nomination, de recrutement et de licenciement d’agents non titulaires : il ne couvre pas cette exclusion.  
Source : [L. 2131-2 du CGCT, version applicable depuis le 1er juillet 2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), consultation officielle archivée dans le corpus au 11 octobre 2026.

**Le piège vient de l’ancienne version.** Au 1er janvier 2004, cet article visait expressément les « sanctions soumises à l’avis du conseil de discipline ». Cette rédaction historique ne doit pas être appliquée à une sanction actuelle.  
Source : [version applicable au 1er janvier 2004](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006390079).

En pratique, la DRH peut donc retenir **l’absence de transmission obligatoire sur ce fondement**. Elle doit distinguer cette règle d’une transmission volontaire, d’une pratique locale de télétransmission ou d’une demande du préfet : celui-ci peut demander communication d’un acte hors de la liste, conformément à [L. 2131-3 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556).

**Confiance : stable pour une sanction actuelle**, sur les extraits officiels fournis. Pour une sanction ancienne, la version applicable à sa date doit être retenue.
