# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non. Pour un fonctionnaire territorial relevant du droit commun, une exclusion de 5 jours prononcée en 2026 ne peut pas être contestée devant un conseil de discipline de recours.** Cette voie est supprimée. Il faut indiquer le recours devant le tribunal administratif et la possibilité d’un recours gracieux auprès de l’autorité territoriale.

Analyse au **11 octobre 2026**, fondée exclusivement sur les consultations officielles archivées du corpus.

**Deux instances à distinguer**

- **Le conseil de discipline préalable demeure.** Une exclusion de 5 jours relève du **deuxième groupe** : sa consultation est donc obligatoire avant la sanction. Son avis et la décision doivent être motivés. Sources : [échelle des sanctions du CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) et [consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), versions applicables depuis le 1er mars 2022.
- **Le conseil de discipline de recours est supprimé.** La loi du 6 août 2019, article 32, a supprimé ses fondements ; le décret du 8 décembre 2020 a abrogé les articles 15 et 16 ainsi que le chapitre II du décret de 1989. La [structure consolidée au 11 octobre 2026](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000335719/2026-10-11) confirme cette abrogation, tout en maintenant le chapitre Ier relatif au conseil préalable.

Le régime transitoire concerne les sanctions intervenues **avant le 7 août 2019**, **sous les conditions d’accès et délais du régime transitoire à vérifier** ; il ne concerne donc pas cette sanction de 2026. Source : [loi du 6 août 2019, article 94 XI](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000038889235).

**Mention proposée dans la notification**

> Vous pouvez contester cette décision devant le tribunal administratif de **[tribunal territorialement compétent et coordonnées à compléter]**, dans un délai de **deux mois à compter de sa notification**.
>
> Vous pouvez également, dans ce même délai, former un recours gracieux auprès de **[autorité territoriale ayant pris la décision, adresse]**. Ce recours interrompt le délai de recours contentieux.

Ces mentions reposent sur :

- Le [Code de justice administrative — délai contentieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le 1er janvier 2020 : délai de deux mois.
- Le [Code de justice administrative — opposabilité du délai](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le 1er janvier 2001 : voies **et** délais doivent figurer dans la notification.
- Les [articles L. 410-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367823) et [L. 411-2 du CRPA](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367829), versions depuis le 1er janvier 2016 : définition du recours gracieux et interruption du délai. Le recours gracieux est facultatif.

**Avant envoi**, la DRH doit compléter le tribunal compétent, contrôler la motivation et conserver la preuve de notification. Elle doit aussi contrôler le dossier intégral, l’assistance par un conseil, le temps laissé à la défense et l’information sur le droit de se taire : les extraits officiels fournis ne permettent pas de valider ces garanties dans le dossier individuel. L’éventuelle transmission au contrôle de légalité reste également à vérifier sur la liste légale actuelle et les modalités locales.

**Décision :** recours devant l’ancienne instance impossible ; recours contentieux et gracieux possibles. **Confiance stable sur ces voies de recours**, sans validation de la régularité de la sanction individuelle.
