# Garde de calibrage — données volatiles

## Question
Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
Au **11 octobre 2026**, la valeur du point d’indice est :

- **59,0734 € brut par an**, exactement ;
- **4,922783333… € brut par mois**, soit exactement **5 907,34 ÷ 1 200**.

**Pour ton arrêté**, utilise la référence réglementaire exacte : **5 907,34 € annuels pour l’indice majoré 100**.

Le traitement indiciaire mensuel se calcule ainsi :

**Indice majoré × 5 907,34 ÷ 1 200**

Évite d’arrondir le point à 4,92 € avant le calcul.

Source : [décret n° 85-1148 du 24 octobre 1985 modifié](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047751772), version en vigueur depuis le **1er juillet 2023**, consultation officielle archivée fournie au dossier du **11 octobre 2026**.

**Confiance : stable à cette date.** Si l’arrêté prend effet à une autre date, la valeur applicable doit être contrôlée pour cette date.
