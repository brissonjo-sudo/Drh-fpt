# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**La nomination est possible sous conditions. Pour cet agent, elle reste non tranchable tant que les pièces individuelles et les règles du cadre d’emplois ne sont pas complétées.** Le projet ci-dessous matérialise ces manques ; il ne doit pas être signé en l’état.

L’analyse porte sur le droit au **11 octobre 2026**, à partir des seules consultations officielles archivées dans le corpus. Aucune consultation supplémentaire n’a été réalisée.

**Conditions à réunir**

Le dossier ne précise ni l’employeur, ni le statut de l’agent, ni les grades concernés, ni la date d’effet. Le projet vise donc **un fonctionnaire territorial titulaire bénéficiant d’un avancement dans son cadre d’emplois**, sous réserve de confirmation. Un recrutement contractuel ou un changement de cadre d’emplois nécessiterait un autre examen.

| Contrôle avant nomination | Règle établie par les extraits officiels | Pièce à compléter |
|---|---|---|
| Conditions statutaires | Les extraits ne permettent pas de vérifier l’éligibilité au grade cible ni le classement. | Statut particulier applicable, grade actuel et cible, échelon, ancienneté, services et éventuel examen professionnel. |
| Tableau annuel | L’avancement au choix repose sur l’appréciation de la valeur professionnelle et des acquis de l’expérience, en tenant compte des lignes directrices de gestion (LDG), sans supprimer le pouvoir d’appréciation de l’autorité. | Tableau annuel, évaluations et LDG locales applicables. |
| Rang de nomination | L’autorité territoriale prononce l’avancement parmi les agents inscrits au tableau, **dans l’ordre du tableau**. | Inscription, rang de l’agent et nominations déjà intervenues. |
| Nombre de promotions | Le maximum résulte du nombre de fonctionnaires remplissant les conditions multiplié par le taux fixé par l’assemblée délibérante, après avis du comité social territorial (CST). **L’extrait exclut le cadre d’emplois des agents de police municipale de cette règle générale.** | Délibération, avis du CST, effectif des promouvables, calcul et promotions déjà prononcées ; régime propre à vérifier si l’exception s’applique. |
| Emploi assigné | L’avancement est subordonné à l’acceptation par l’agent de l’emploi assigné dans son nouveau grade. | Emploi concerné, actes locaux permettant son occupation et preuve de l’acceptation. |
| Date d’effet | Une décision individuelle d’avancement peut prévoir une date d’effet antérieure à son caractère exécutoire. | Date souhaitée et vérification de toutes les conditions à cette date. Cette faculté ne régularise pas une condition statutaire manquante. |

**Sources correspondantes :** CGFP, versions en vigueur depuis le **1er mars 2022**, consultations archivées du **11 octobre 2026** : [modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), [taux de promotion et exception](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), [autorité et ordre du tableau](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), [acceptation de l’emploi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496), [date d’effet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425494).

L’extrait relatif au contenu des **LDG** confirme leurs orientations et critères pour l’avancement au choix ; sa version s’applique depuis le **1er août 2026**, conformément à la disposition d’entrée en vigueur reproduite dans le dossier. [Source archivée le 11 octobre 2026](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251). Le dossier ne contient toutefois ni les LDG locales ni les textes complets permettant de vérifier leur procédure d’adoption et le rôle actuel de la commission administrative paritaire (CAP).

**J’en déduis que l’inscription au tableau ne suffit pas, à elle seule, à établir que cette nomination peut être prononcée.** La DRH doit documenter les conditions ci-dessus avant de soumettre l’acte à l’autorité territoriale.

**Formalités à sécuriser**

- **Compétence :** l’autorité territoriale prononce l’avancement. L’identité du signataire et une éventuelle délégation restent à contrôler.
- **Motivation :** le CRPA impose une motivation écrite en droit et en fait pour les décisions individuelles défavorables relevant des catégories qu’il énumère. Le présent projet est favorable ; il ne faut pas transposer automatiquement cette obligation à toute nomination. Un éventuel refus demanderait un examen distinct. Sources : [catégories de décisions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [contenu de la motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le **1er janvier 2016**, consultations archivées du **11 octobre 2026**.
- **Contrôle de légalité, si l’employeur est une commune :** la nomination d’un titulaire par avancement de grade ne relève pas, pour ce seul motif, du recrutement d’un agent non titulaire prévu au 5° de l’article L. 2131-2 du CGCT. Aucune transmission obligatoire ne peut être déduite de cette catégorie. Distinguer une éventuelle transmission volontaire, une pratique locale et une demande préfectorale de communication des actes hors liste. Sources : [liste actuelle](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) et [communication au préfet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), versions depuis le **1er juillet 2022**, consultations archivées du **11 octobre 2026**.
- **Notification et recours :** l’extrait du CJA prévoit, en principe, un recours dans les deux mois suivant notification ou publication. Les délais ne sont opposables au destinataire que si les voies et délais figurent dans la notification. Le tribunal compétent et les formalités de publicité, notamment à l’égard des tiers, restent à déterminer. Sources : [délai de recours](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le **1er janvier 2020**, et [opposabilité du délai](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le **1er janvier 2001**, consultations archivées du **11 octobre 2026**.

**Ordre d’action recommandé :** la DRH complète les pièces statutaires et locales, vérifie l’éligibilité, le contingent, le rang, l’emploi accepté et le classement, puis prépare l’acte pour signature. Après signature, elle assure la notification et les formalités applicables, conserve les preuves et transmet au service paie les seules données validées. Aucun indice ni montant ne peut être fixé avec les sources fournies.

---

**PROJET D’ARRÊTÉ — À COMPLÉTER ET CONTRÔLER AVANT SIGNATURE**

**[Collectivité ou établissement — nature juridique à préciser]**  
**Arrêté n° [numéro] portant nomination de [Prénom NOM] au grade de [grade cible] par avancement de grade**

**[L’autorité territoriale compétente : qualité et identité]**

Vu le code général de la fonction publique, notamment ses dispositions relatives aux modalités d’avancement de grade, à la nomination dans l’ordre du tableau, à l’acceptation de l’emploi assigné et à la date d’effet des décisions individuelles d’avancement ;

Vu [le texte statutaire particulier du cadre d’emplois : intitulé, référence et articles applicables, à vérifier dans leur version à la date d’effet] ;

Vu [les textes de classement dans le grade cible : références et articles à vérifier] ;

Vu les lignes directrices de gestion applicables, arrêtées le [date], pour la période [période] ;

Vu [si le régime général du taux de promotion s’applique] la délibération n° [numéro] du [date] fixant le taux de promotion au grade de [grade], après avis du comité social territorial du [date] ;

Vu le tableau annuel d’avancement au grade de [grade cible], établi pour l’année [année], sur lequel [Prénom NOM] figure au rang [rang] ;

Vu [l’acte local et les pièces établissant l’existence et la situation de l’emploi assigné] ;

Vu l’acceptation de cet emploi par l’intéressé(e), établie le [date] ;

Vu l’arrêté n° [numéro] du [date] fixant la situation administrative actuelle de l’intéressé(e) ;

Considérant que [Prénom NOM], fonctionnaire titulaire du grade de [grade actuel], remplit à la date du [date d’effet] les conditions statutaires de l’avancement envisagé, telles qu’établies par [pièces et éléments précis] ;

Considérant que la nomination respecte l’ordre du tableau annuel et [le contingent applicable, avec référence à la fiche de contrôle / le régime particulier vérifié] ;

**ARRÊTE**

**Article 1 — Nomination**

À compter du [date d’effet contrôlée], [Prénom NOM] est nommé(e), par avancement de grade, au grade de [grade cible], dans le cadre d’emplois de [cadre d’emplois].

**Article 2 — Classement**

À cette date, l’intéressé(e) est classé(e) au [échelon], avec une ancienneté conservée de [durée], conformément à [texte et article de classement vérifiés].

Les indices applicables sont : indice brut [indice vérifié] et indice majoré [indice vérifié].

**Article 3 — Emploi assigné**

L’intéressé(e) occupe l’emploi de [intitulé de l’emploi], au sein de [service], selon [durée de l’emploi et, le cas échéant, autorisation de temps partiel à distinguer], accepté le [date].

**Article 4 — Exécution et formalités**

[Responsable désigné] est chargé(e) de l’exécution du présent arrêté.

L’arrêté est notifié à l’intéressé(e). Une copie est adressée au service chargé de la carrière et de la paie et aux destinataires nécessaires à son exécution.

[Compléter les formalités de publicité et les conditions du caractère exécutoire après vérification du régime de l’employeur.]

[Compléter, seulement après contrôle, la clause de transmission : obligation fondée sur une catégorie applicable / transmission volontaire / communication sur demande préfectorale. Ne pas conserver de mention automatique.]

**Article 5 — Recours**

Le présent arrêté peut faire l’objet d’un recours devant le tribunal administratif de [tribunal territorialement compétent à vérifier], dans un délai de deux mois à compter de sa notification à l’intéressé(e).

[Vérifier et compléter, si nécessaire, toute voie préalable spéciale applicable. Les formalités de publicité et les droits de recours des tiers doivent être contrôlés séparément.]

Fait à [lieu], le [date].

[Qualité du signataire, identité et signature]  
[Référence d’une délégation, uniquement si elle existe et couvre cet acte]

Notification effectuée le : [date]  
Preuve de notification : [référence]

---

**Confiance :** règles générales étayées par les traces officielles fournies ; **nomination individuelle et projet à vérifier**. Les principaux points ouverts sont le statut particulier, les pièces locales, le classement, la date d’effet et les formalités propres à l’employeur. Limiter les données personnelles de l’arrêté et de sa diffusion à celles nécessaires.
