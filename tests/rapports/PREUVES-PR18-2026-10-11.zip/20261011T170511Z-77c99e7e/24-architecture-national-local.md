# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Vous pouvez conserver un cycle annualisé s’il respecte les règles actuelles et repose sur une délibération adaptée. Son ancienneté ne suffit ni à le rendre irrégulier, ni à garantir sa conformité.**

**Décision pour votre organisation actuelle : non tranchable en l’état**, car le dossier ne contient ni votre délibération ni vos horaires. Le cadrage ci-dessous concerne le droit commun de la fonction publique territoriale, à la date du **11 octobre 2026**, d’après les extraits officiels archivés fournis.

**Le socle national à respecter**

La durée de référence est de **35 heures par semaine**, avec un décompte annuel de **1 607 heures de travail effectif** pour un agent à temps complet, hors heures supplémentaires et adaptations légalement fondées. L’annualisation permet de répartir différemment les horaires selon les périodes : elle n’impose donc pas nécessairement 35 heures chaque semaine.

Le décret applicable aux collectivités renvoie aux règles de l’État, sous réserve des adaptations territoriales. Cela ne permet pas de transposer directement aux collectivités les compétences des ministres ou des instances de l’État.  
Sources : [décret territorial du 12 juillet 2001 — renvoi au régime général](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version depuis le 14/07/2001 ; [décret du 25 août 2000 — durée de référence](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142), version depuis le 01/01/2023 ; consultations archivées du 11/10/2026.

Le **travail effectif** correspond au temps pendant lequel l’agent est à la disposition de l’employeur, suit ses directives et ne peut pas vaquer librement à des occupations personnelles. Une pause ne peut donc pas être exclue automatiquement du décompte : il faut examiner ses conditions réelles.  
Source : [définition du travail effectif](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version depuis le 29/06/2006, consultation archivée du 11/10/2026.

Même dans un cycle annualisé, les garanties suivantes s’appliquent :

| Point de contrôle | Règle générale |
|---|---:|
| Travail effectif quotidien | Maximum **10 heures** |
| Amplitude de la journée | Maximum **12 heures** |
| Repos quotidien | Minimum **11 heures** |
| Travail hebdomadaire, heures supplémentaires comprises | Maximum **48 heures** |
| Moyenne sur toute période de 12 semaines consécutives | Maximum **44 heures par semaine** |
| Repos hebdomadaire | Minimum **35 heures**, comprenant en principe le dimanche |
| Pause | Au moins **20 minutes** ; le travail quotidien ne peut atteindre **6 heures** sans cette pause |

**J’en déduis qu’une période creuse ne peut pas compenser le dépassement d’une garantie quotidienne ou hebdomadaire pendant une période chargée.** Les dérogations prévues par le texte répondent à des conditions spécifiques ; une délibération locale ou une simple nécessité habituelle de service ne suffit pas à les créer.  
Source : [garanties minimales et dérogations](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150), version depuis le 01/01/2023, consultation archivée du 11/10/2026.

**Ce qui relève du choix local**

L’**organe délibérant** fixe les conditions de mise en place des cycles, **après avis du comité social territorial (CST)**. Le cycle peut aller de la semaine à l’année. Pour les agents relevant d’un décompte horaire des heures supplémentaires, celles-ci sont identifiées par le dépassement des bornes du cycle : il faut donc contrôler ces bornes, et pas seulement le total annuel. Les modalités territoriales précises de compensation restent à vérifier, leur texte n’étant pas fourni.  
Sources : [règles générales sur les cycles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560147) et [compétence territoriale pour les cycles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472), versions depuis le 01/01/2023, consultations archivées du 11/10/2026.

Une réduction de la durée annuelle est **possible, mais pas automatique**, pour des sujétions liées aux missions et aux cycles : nuit, dimanche, horaires décalés, travail en équipes, travaux pénibles ou dangereux, notamment. Elle relève également de l’organe délibérant après avis du CST. Il faut documenter les sujétions réellement supportées et la réduction retenue.  
Source : [réduction pour sujétions en FPT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477), version depuis le 01/01/2023, consultation archivée du 11/10/2026.

**Pour décider si vous conservez votre organisation**, je recommande ce contrôle conjoint RH–chef de service :

1. **Réunir la délibération et ses modifications**, le règlement du temps de travail et les avis de l’instance compétente.
2. **Comparer les horaires prévus et réellement effectués**, particulièrement pendant les périodes chargées, aux garanties ci-dessus.
3. **Contrôler le décompte annuel**, les pauses, les bornes du cycle et les éventuelles réductions pour sujétions.
4. **Conserver le cycle si ces contrôles sont satisfaits** ; sinon, corriger les horaires ou préparer une modification du cadre local, avec avis du CST puis délibération.

Pour trancher, pouvez-vous préciser **le type et l’effectif de votre employeur, les catégories d’agents et leurs quotités**, puis fournir **le contenu de la délibération actuelle et un exemple de planning en période haute** ? Ces éléments permettront aussi de repérer un éventuel régime particulier.

**Confiance : stable sur le socle reproduit dans les sources fournies ; à vérifier sur votre organisation.** Le dossier ne permet pas de confirmer une dérogation sectorielle, un ancien régime plus favorable, ni toutes les règles de congés nécessaires au calcul individuel annuel.
