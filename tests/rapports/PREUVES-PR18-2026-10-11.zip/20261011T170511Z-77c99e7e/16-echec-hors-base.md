# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**L’indemnité de feu est fixée à 25 % du traitement soumis à retenue pour pension.** Elle correspond donc à un pourcentage, pas à un montant uniforme en euros.

Pour chaque agent :

**Indemnité mensuelle = traitement mensuel soumis à retenue pour pension × 0,25.**

Son fondement est le [décret n° 90-850 du 25 septembre 1990 portant dispositions communes aux sapeurs-pompiers professionnels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025). L’extrait officiel fourni, dans sa version en vigueur depuis le **26 juillet 2020**, consultée le **11 octobre 2026**, indique qu’ils « peuvent percevoir […] une indemnité de feu d’un taux de 25 % du traitement soumis à retenue pour pension ».

**Le montant individuel exact en euros reste non tranchable sans l’assiette de paie de chaque agent.** Pour la contrôler, il faut notamment vérifier l’indice majoré, la valeur du point applicable, la quotité rémunérée et les éléments effectivement compris dans le traitement soumis à retenue pour pension. Le taux ne s’applique pas à l’ensemble de la rémunération brute.

**Limite du dossier :** le décret renvoie aux conditions fixées par l’article 17 de la loi n° 90-1067 du 28 novembre 1990, dont le texte n’est pas fourni. Le taux et l’assiette sont établis par l’extrait ; les conditions d’attribution individuelle restent à vérifier.
