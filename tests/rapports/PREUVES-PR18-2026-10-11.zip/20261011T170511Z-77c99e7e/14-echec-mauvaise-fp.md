# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Votre situation relève de la fonction publique hospitalière, pas territoriale.** Le corpus fourni exclut ce champ : les 900 agents du CHU ne changent pas cette limite.

**Faits connus :** CHU de 900 agents, agent titulaire, arrêt maladie depuis huit mois. La nature du congé actuellement accordé et ses dates exactes ne sont pas précisées.

**Décision : non tranchable avec ce corpus.** Je ne peux pas déterminer son droit au congé de longue maladie, sa durée ou sa rémunération à partir des seules règles territoriales.

Mode dégradé : aucune source officielle n’a été consultée pour cette réponse. La vérification du régime hospitalier reste à faire.

Pour préparer cette vérification, votre service RH doit réunir :

- les décisions de congé déjà prises, les dates des arrêts et les éventuels congés antérieurs ;
- la demande éventuelle de longue maladie et les pièces médicales nécessaires, transmises par le circuit confidentiel adapté ;
- les dispositions du **Code général de la fonction publique** applicables aux fonctionnaires hospitaliers et les textes réglementaires hospitaliers sur les congés de santé et les instances médicales, dans leur version applicable.

Le contrôle devra couvrir l’éligibilité, les droits restant ouverts, la rémunération, l’instance médicale compétente et l’autorité décisionnaire. **Les huit mois d’arrêt ne suffisent pas, dans ce dossier, à établir le régime applicable.**

**Niveau de confiance : abstention sur le régime individuel, faute de sources hospitalières vérifiées.**
