# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non : pour une exclusion de 5 jours prononcée en 2026, un fonctionnaire territorial ne peut pas saisir un conseil de discipline de recours. Cette voie est supprimée.**

Les dispositions de suppression du décret n° 2020-1533 concordent avec la [structure consolidée du décret n° 89-677 au 11 octobre 2026](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000335719/2026-10-11) : le chapitre II consacré aux conseils de discipline de recours est **abrogé**, tandis que le chapitre Ier relatif au conseil de discipline préalable reste en vigueur.

Le [régime transitoire de la loi de 2019, article 94 XI](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000038889235) vise les recours contre des sanctions intervenues **avant le 7 août 2019**. Il ne concerne donc pas une sanction prononcée en 2026.

**Attention à distinguer les deux instances :** l’exclusion de 5 jours appartient au **deuxième groupe**. La consultation préalable du conseil de discipline était donc obligatoire ; sa suppression comme instance de *recours* ne supprime pas cette consultation. La décision doit être motivée. Sources : [échelle des sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) et [consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), versions en vigueur depuis le 1er mars 2022.

Dans la notification, indiquez :

- **Le recours contentieux** devant le tribunal administratif compétent, dans les **deux mois suivant la notification**.
- **La possibilité d’un recours gracieux** auprès de l’autorité territoriale qui a pris la sanction. Présenté dans le délai contentieux, il **interrompt ce délai**. Ce recours est facultatif.

Ces règles sont établies par les extraits fournis du [Code de justice administrative — délai contentieux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005) et du [Code des relations entre le public et l’administration — interruption du délai](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367829). Les voies **et** délais doivent figurer dans la notification pour rendre les délais opposables : [Code de justice administrative](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946).

Formulation proposée, **à compléter avec le tribunal compétent et l’auteur de la décision** :

> La présente décision peut faire l’objet d’un recours contentieux devant le tribunal administratif de **[ville]**, dans un délai de deux mois à compter de sa notification.
>
> Vous pouvez également, dans ce même délai, former un recours gracieux auprès de **[autorité territoriale ayant pris la décision et adresse]**. Ce recours est facultatif. Lorsqu’il est présenté dans le délai de recours contentieux, il interrompt ce délai.

**Action :** retirez toute mention du conseil de discipline de recours ; complétez les destinataires et conservez la preuve de notification. N’ajoutez pas automatiquement un recours hiérarchique auprès du préfet ou du centre de gestion.

**Confiance : stable pour un fonctionnaire territorial de droit commun**, sur la base des consultations officielles archivées fournies, versions applicables au **11 octobre 2026**. Si l’agent est contractuel ou relève d’un statut particulier, le régime propre doit être contrôlé avant d’utiliser cette formulation.
