# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Vous pouvez envisager l’engagement d’une procédure, sous conditions. En revanche, les éléments fournis ne permettent pas de décider d’une exclusion de 5 jours.** Ma recommandation : préparer le dossier et vérifier les conditions d’ouverture, sans arrêter la sanction à l’avance.

L’analyse repose exclusivement sur les extraits officiels archivés fournis, dans leurs versions applicables au **11 octobre 2026**.

**Ce que les textes permettent d’établir**

Pour un **fonctionnaire titulaire**, une exclusion temporaire de **5 jours relève du deuxième groupe** : ce groupe comprend les exclusions de quatre à quinze jours. Elle nécessite donc la **consultation préalable du conseil de discipline**. L’exception dispensant de cette consultation concerne uniquement les sanctions du premier groupe, notamment l’exclusion d’au plus trois jours.

Sources : [CGFP, article L. 533-1 — échelle des sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), version depuis le 01/03/2022 ; [CGFP — consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), version depuis le 01/03/2022. Consultations archivées du 11/10/2026.

L’ouverture doit également respecter la **prescription disciplinaire** : aucune procédure ne peut être engagée au-delà de **trois ans à compter de la connaissance effective, par l’administration, de la réalité, de la nature et de l’ampleur des faits**. Ce point de départ ne se confond donc pas nécessairement avec la date des faits. Des poursuites pénales peuvent interrompre ce délai dans les conditions précisées par le texte.

Source : [CGFP, article L. 532-2 — prescription](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430), version depuis le 01/03/2022, consultation archivée du 11/10/2026.

**J’en déduis que** le soupçon justifie d’abord de documenter les faits. Il ne suffit pas, à lui seul, à justifier une sanction déterminée. La procédure doit permettre à l’agent de répondre aux griefs et à l’autorité de décider sur un dossier complet.

**Les informations nécessaires pour trancher votre dossier**

Merci de préciser, en un seul retour :

- **L’employeur** : type de collectivité, effectif et affiliation au centre de gestion ; cadre d’emplois de l’agent.
- **Les dates** : faits, connaissance effective par l’administration, éventuelle ouverture déjà intervenue et existence de poursuites pénales.
- **Les griefs et preuves disponibles** : faits précisément reprochés, pièces ou témoignages et explications déjà recueillies.

Le statut de titulaire est acquis : il n’est pas nécessaire de le redemander. Ces informations conditionnent la prescription, le circuit compétent et l’appréciation des faits.

**Décision recommandée**

- **Engagement : possible sous conditions**, après vérification du régime de l’employeur, de la compétence et de la prescription.
- **Exclusion de 5 jours : non tranchable en l’état.** Conserver cette durée comme une hypothèse à examiner, sans annoncer une décision acquise.
- **Action immédiate : lancer la préparation du dossier**, puis soumettre à l’autorité territoriale une proposition motivée d’ouverture ou de classement.

**Actions à lancer, dans l’ordre**

| Ordre | Action et responsable | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : établir une chronologie** des faits, de leur découverte et des démarches déjà réalisées. | Identifier la date de connaissance effective et contrôler la prescription ; joindre les pièces datées et, le cas échéant, les documents pénaux utiles. |
| **2** | **DRH et service juridique : vérifier le régime et le circuit compétent.** | Confirmer l’employeur, le cadre d’emplois, l’autorité signataire et ses éventuelles délégations ; identifier le conseil de discipline et son secrétariat selon l’organisation applicable. |
| **3** | **DRH : constituer le dossier factuel**, avec les éléments à charge et ceux susceptibles d’expliquer ou de contredire les griefs. | Distinguer faits établis, témoignages et soupçons ; vérifier la fiabilité des pièces. Numéroter les pièces du dossier et les annexes. Limiter leur circulation aux personnes nécessaires. |
| **4** | **Autorité compétente : décider de l’ouverture**, si les contrôles précédents sont satisfaits, puis informer l’agent par écrit. | Le courrier précise les faits reprochés, le droit au dossier intégral et aux annexes, ainsi que l’assistance de défenseurs de son choix. Conserver la preuve de remise. |
| **5** | **DRH : organiser l’accès au dossier et la préparation de la défense.** | Accès effectif, pièces complètes, délai suffisant et possibilité d’assistance. Avant de recueillir des observations, faire vérifier les exigences relatives au **droit de se taire** : les sources officielles fournies ne permettent pas d’en certifier les modalités. |
| **6** | **Autorité et secrétariat compétents : organiser la saisine du conseil**, si une sanction du deuxième groupe reste envisagée. | Contrôler les règles de saisine et de composition, dont toutes ne figurent pas au dossier. Le président convoque l’agent par lettre recommandée avec avis de réception **au moins quinze jours avant la réunion**. L’autorité investie du pouvoir disciplinaire ne peut siéger. |
| **7** | **Autorité territoriale : réexaminer le dossier après la défense et l’avis.** | L’avis est communiqué sans délai à l’agent et à l’autorité. Examiner la réalité des faits, les explications et l’adéquation de la sanction ; l’exclusion de 5 jours doit rester réexaminable. |
| **8** | **DRH et service juridique : préparer puis notifier la décision retenue.** | Motivation écrite en droit et en fait ; compétence, date d’effet, conséquences administratives et financières, notification traçable, voies et délais de recours contrôlés avant envoi. Conserver les preuves de chaque formalité. |

Les garanties des étapes 3 à 6 sont établies par les extraits suivants du décret du 18 septembre 1989 : [information, dossier et délai suffisant](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836), version depuis le 11/12/2025 ; [convocation et défense devant le conseil](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372226), version depuis le 19/09/1989 ; [convocation du conseil et interdiction de siéger](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222), version depuis le 03/12/1996. Consultations archivées du 11/10/2026.

La décision doit comporter ses **fondements juridiques et les faits précis qui la justifient**, conformément au [CRPA — obligation de motiver une sanction](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et au [CRPA — contenu de la motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le 01/01/2016, consultations archivées du 11/10/2026.

**Deux contrôles à ne pas oublier avant notification**

**Recours.** Vérifier le recours gracieux auprès de l’auteur, le tribunal administratif compétent, les délais et leurs effets. Ne pas proposer l’ancien conseil de discipline de recours comme voie actuelle : les textes officiels de suppression et de transition ne sont pas fournis ici et doivent être contrôlés séparément. Il reste à distinguer cette ancienne instance du **conseil préalable**, dont la consultation est bien établie pour la sanction envisagée.

**Contrôle de légalité.** Si l’employeur est une **commune**, la liste actuelle de [l’article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) ne comporte pas de catégorie générale imposant la transmission d’une sanction disciplinaire de titulaire. Ne pas appliquer automatiquement le délai de quinze jours de transmission. Vérifier séparément la convention locale de télétransmission et une éventuelle demande préfectorale : [l’article L. 2131-3](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556) permet au préfet de demander communication d’actes hors liste. Versions depuis le 01/07/2022, consultations archivées du 11/10/2026. Pour un autre employeur territorial, le régime correspondant reste à vérifier.

**Confiance : stable** sur le classement des 5 jours, le conseil préalable, les droits au dossier et la motivation. **Décision individuelle non tranchable** tant que les dates, les faits, la compétence et les contrôles documentaires manquants ne sont pas établis.
