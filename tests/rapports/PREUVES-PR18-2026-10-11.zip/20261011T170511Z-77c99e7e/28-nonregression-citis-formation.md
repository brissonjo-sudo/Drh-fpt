# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**La formation plénière**, lorsque la saisine est requise pour examiner l’imputabilité au service. **La décision finale appartient à l’autorité territoriale** : le conseil médical rend un avis, il ne décide pas à sa place.

La nuance utile : **une contestation ne rend pas automatiquement la saisine obligatoire**. Pour un accident de service, le texte prévoit la consultation lorsqu’une faute personnelle ou une circonstance particulière est potentiellement de nature à détacher l’accident du service.

- **Formation plénière** : avis sur l’imputabilité dans les cas de saisine prévus ; la formation restreinte n’est pas la formation compétente pour cet objet. [Décret du 30 juillet 1987 — compétence](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783).
- **Déclencheur de la saisine** : faute personnelle ou circonstance susceptible de détacher l’accident du service. [Même décret — consultation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859).
- **Décision finale** : au terme de l’instruction, l’autorité territoriale se prononce sur l’imputabilité et, le cas échéant, accorde le **congé pour invalidité temporaire imputable au service (CITIS)**. [Même décret — décision](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843).

**À faire dans votre dossier :** documenter les circonstances de l’accident et les motifs précis de la contestation pour déterminer si ce déclencheur est présent. Ce circuit concerne le fonctionnaire territorial ; le régime du contractuel doit être examiné séparément.

**Confiance élevée sur la répartition des compétences**, d’après les extraits officiels fournis, consultés le 11 octobre 2026, versions en vigueur depuis le 18 avril 2024. La nécessité de saisir dans ce dossier dépend des faits contestés.
