# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non. Pour un fonctionnaire titulaire, la présomption de démission de 2022 ne s’applique pas.** Elle concerne les salariés de droit privé, y compris ceux employés par une personne publique sous ce régime. Votre agent relève d’une autre voie : **le licenciement pour abandon de poste, emportant radiation des cadres**.

Cette distinction ressort des extraits officiels fournis : [champ du Code du travail](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006900781), [présomption de démission](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104) et [article L. 553-1, 1° du Code général de la fonction publique](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184), dans leurs versions applicables au **11 octobre 2026**.

**Plusieurs semaines d’absence injustifiée ne suffisent pas, à elles seules, à permettre la radiation.** Il faut préalablement une mise en demeure :

- **écrite et notifiée** à l’agent ;
- lui demandant de reprendre son service dans un **délai approprié**, fixé par l’administration ;
- l’avertissant explicitement du risque de **radiation des cadres sans procédure disciplinaire préalable**.

Ces exigences sont établies par [CE, Section, 11 décembre 1998, nos 147511 et 147512, publié au Recueil Lebon](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335). Le caractère approprié du délai constitue une condition nécessaire à la caractérisation de l’abandon : [CE, 26 septembre 2014, n° 365918](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000029504219).

La direction des ressources humaines doit ensuite examiner les réponses, l’intention de reprendre et les éventuels empêchements médicaux ou matériels. **Une réponse refusant la reprise ne préserve pas automatiquement le lien avec le service** : [CAA Versailles, 14 avril 2026, n° 24VE00726, points 11 à 13](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000053906348). Cette décision concerne une fonctionnaire de l’État ; elle corrobore le principe, sans permettre de transposer automatiquement ses circonstances à votre agent territorial.

Il s’agit d’une voie **non disciplinaire** : pas de conseil de discipline ni de communication du dossier **au titre des garanties disciplinaires**. Cela ne dispense pas des conditions de mise en demeure et de caractérisation de l’abandon.

**Décision : présomption de démission inapplicable ; radiation non tranchable en l’état.** Faites réunir par les RH le relevé des absences, les échanges et les éventuels justificatifs. Avant tout arrêté, restent à contrôler la compétence du signataire, la motivation, la date d’effet, la notification, les recours et les formalités applicables ; les extraits officiels fournis ne permettent pas de sécuriser tous ces points. Ne fixez pas automatiquement l’effet au premier jour d’absence.

**Une mise en demeure a-t-elle déjà été notifiée ? Si oui, à quelle date, avec quel délai de reprise et quel avertissement exact ?**

*Confiance élevée sur l’exclusion du régime privé ; situation individuelle à instruire. Analyse fondée uniquement sur les consultations officielles archivées fournies.*
