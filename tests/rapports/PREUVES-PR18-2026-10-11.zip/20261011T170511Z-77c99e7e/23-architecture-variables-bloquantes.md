# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable à ce stade : son nom et son cadre d’emplois ne suffisent pas pour savoir s’il peut être nommé en 2026.** Il faut distinguer les conditions permettant d’être promouvable, l’inscription au tableau et la décision de nomination.

**Pouvez-vous réunir ces informations, sans transmettre son nom ?**

- **Situation statutaire** : cadre d’emplois exact, statut de titulaire/stagiaire/contractuel, grade actuel et grade visé.
- **Carrière** : échelon, date d’accès à cet échelon, ancienneté et services accomplis ; éventuel examen professionnel obtenu ; temps complet, non complet ou temps partiel.
- **Calendrier** : date de nomination envisagée en 2026.

Ces éléments permettront de rechercher les conditions du statut particulier applicable. **Ce statut n’est pas fourni dans les extraits officiels : je ne peux donc pas confirmer son éligibilité.**

Les sources archivées permettent néanmoins de fixer le cadre général au **11 octobre 2026** :

| Contrôle | Règle établie par les extraits officiels |
|---|---|
| **Modalité d’avancement** | Selon le régime applicable : choix, examen professionnel ou concours professionnel. Au choix, le tableau repose sur la valeur professionnelle et les acquis de l’expérience ; l’autorité tient compte des lignes directrices de gestion (LDG). [Source — version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506) |
| **Ratio promus-promouvables** | Le nombre maximal de promotions dépend des effectifs remplissant les conditions et du taux fixé par l’assemblée délibérante après avis du comité social territorial (CST). **Le cadre d’emplois des agents de police municipale est exclu de cette règle générale** : son régime propre doit être vérifié. [Source — version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500) |
| **LDG locales** | Elles fixent les orientations et critères généraux de l’avancement au choix. Il faut disposer des LDG applicables dans votre collectivité. [Source — version depuis le 01/08/2026](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054076251) |
| **Nomination** | L’autorité territoriale nomme parmi les fonctionnaires inscrits au tableau, en respectant son ordre. **J’en déduis que remplir les conditions statutaires ne suffit pas à garantir une nomination.** [Source — version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498) |

**Votre prochaine action :** faire compléter par la gestion carrière une fiche individuelle avec les données ci-dessus, puis rapprocher cette fiche du statut particulier, des LDG, de la délibération fixant le ratio applicable et du tableau envisagé.

Le rôle actuel de la **commission administrative paritaire (CAP)** doit aussi être contrôlé : le corpus métier indique l’absence de consultation préalable sur l’avancement, mais aucun extrait officiel fourni ne permet ici de certifier ce point.

**Confiance :** cadre général étayé par les consultations archivées ; nomination individuelle **non tranchable** jusqu’à vérification des conditions statutaires et des pièces locales.
