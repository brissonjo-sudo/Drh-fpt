# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non. Au 11 octobre 2026, cette exclusion de 5 jours n’est pas soumise à transmission obligatoire au titre de l’article L. 2131-2 du CGCT.**

La liste actuelle ne comporte plus de catégorie visant les sanctions disciplinaires. Le classement de cette exclusion dans le **deuxième groupe** ne crée donc pas d’obligation de transmission.

Source : [article L. 2131-2 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), version en vigueur depuis le 1er juillet 2022, consultation officielle archivée fournie du 11 octobre 2026 — fonction : déterminer les actes obligatoirement transmissibles.

La confusion vient de **l’ancienne version**, applicable notamment au 1er janvier 2004 : elle visait expressément les « sanctions soumises à l’avis du conseil de discipline ». Cette ancienne liste ne s’applique pas à une sanction actuelle. ([Version historique fournie](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006390079).)

En pratique, distinguez :

- **Transmission obligatoire légale : non**, pour cette sanction.
- **Transmission volontaire ou pratique locale :** à examiner séparément selon le circuit communal.
- **Demande du préfet :** il peut demander communication d’un acte hors liste, conformément à [l’article L. 2131-3 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), version applicable et consultation archivées fournies.

**Confiance : stable sur l’absence d’obligation au titre de L. 2131-2 pour un acte actuel.**
