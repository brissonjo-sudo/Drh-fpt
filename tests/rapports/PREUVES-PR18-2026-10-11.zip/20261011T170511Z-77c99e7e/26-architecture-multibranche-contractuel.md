# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne donne pas, à elle seule, les droits de carrière d’un fonctionnaire titulaire.** Pour cet agent en contrat à durée indéterminée (CDI), la voie à instruire est une **réévaluation de sa rémunération**, en examinant son expérience, ses fonctions et les clauses de son contrat.

Analyse au **11 octobre 2026**, fondée uniquement sur les extraits officiels et leurs traces de consultation fournis dans le corpus.

**Ancienneté et grade : deux demandes à distinguer**

- **Reprise de toute l’ancienneté : aucun droit automatique établi.** Le texte impose de prendre en compte l’expérience pour fixer la rémunération ; il ne prévoit pas une conversion de toutes les années travaillées en échelons, comme lors d’un classement statutaire. L’expérience antérieure peut donc justifier un meilleur positionnement salarial, à apprécier selon les fonctions, les qualifications et les pièces produites.
- **Avancement de grade : le régime du titulaire ne s’applique pas au seul motif que la rémunération est indiciaire.** L’indice constitue ici une référence de rémunération ; il ne confère pas un grade. Une évolution des responsabilités peut conduire à revoir la rémunération, mais elle ne constitue pas un avancement statutaire de grade.

Le Code général de la fonction publique prévoit que la rémunération contractuelle est fixée par l’autorité compétente en tenant compte des fonctions, de la qualification requise et de l’expérience ; elle peut aussi tenir compte des résultats professionnels. **J’en déduis que l’ancienneté doit être examinée comme expérience pertinente, sans lui appliquer mécaniquement les règles de classement d’un fonctionnaire.**  
Source : [disposition du CGFP relative à la rémunération des contractuels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), version depuis le 01/03/2022, consultation archivée le 11/10/2026.

**En revanche, le réexamen de la rémunération est obligatoire au moins tous les trois ans pour les CDI**, notamment au vu des entretiens professionnels ou de l’évolution des fonctions. Il faut distinguer **l’obligation de réévaluer** et **une augmentation automatique** : le texte ne fixe ni hausse minimale ni progression d’échelon.  
Source : [décret du 15 février 1988, disposition relative à la rémunération](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), version depuis le 01/07/2026, consultation archivée le 11/10/2026.

Attention : cet extrait prévoit un **régime dérogatoire pour certains emplois fonctionnels de direction**, avec classement selon l’expérience. Si l’agent occupe un tel emploi, les textes auxquels il renvoie doivent être examinés avant de conclure sur son classement.

**État de décision : possible sous conditions pour une réévaluation ; non tranchable pour son montant.** Le dossier fourni n’établit aucun droit à la reprise intégrale demandée ni à un avancement de grade.

La marche à suivre :

1. **La DRH rassemble les pièces déterminantes** : contrat et avenants, fondement du recrutement, clauses de rémunération ou de progression, fiche de poste, justificatifs d’expérience, historique salarial et date du dernier réexamen. Elle vérifie également le cadre local de rémunération et l’éventuel emploi fonctionnel.
2. **Le supérieur hiérarchique documente la situation actuelle** : fonctions réellement exercées, qualifications, responsabilités, résultats et évolutions du poste. Pour un agent en CDI recruté sur un emploi permanent, l’entretien professionnel annuel est obligatoire et donne lieu à un compte rendu.  
   Source : [décret du 15 février 1988, disposition relative à l’entretien professionnel](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), version depuis le 01/01/2023, consultation archivée le 11/10/2026.
3. **La DRH propose un positionnement salarial motivé**, en expliquant quelles expériences sont pertinentes et comment elles sont prises en compte. Si la dernière réévaluation remonte à trois ans ou davantage, elle organise le réexamen requis.
4. **L’autorité territoriale arrête sa décision.** Avant mise en paie, la DRH contrôle la formalisation nécessaire, les clauses contractuelles et le cadre local. Toute conversion en euros exige l’indice majoré retenu, la quotité de travail et la valeur du point à la date d’effet, qui n’est pas fournie ici.

La réponse à l’agent doit expliquer ces distinctions et présenter le résultat concret du réexamen. **Un refus ne doit pas reposer uniquement sur son statut contractuel en ignorant son expérience ou une éventuelle clause de progression.**

**Confiance : socle confirmé par les extraits officiels fournis ; décision individuelle à vérifier sur les pièces contractuelles et locales.**
