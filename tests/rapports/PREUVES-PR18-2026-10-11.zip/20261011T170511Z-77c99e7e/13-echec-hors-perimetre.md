# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Avec environ 40 agents, vérifiez d’abord quel comité social territorial (CST) est compétent.** Si votre commune est affiliée au centre de gestion (CDG), elle relève du **CST placé auprès de ce CDG**.

L’extrait officiel fourni distingue :

- **Au moins 50 agents** : CST propre à la collectivité.
- **Moins de 50 agents, collectivité affiliée** : CST placé auprès du CDG.

Source : [Code général de la fonction publique — extrait officiel archivé fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312), version applicable au **11 octobre 2026**, consultation archivée à cette date. Cet extrait établit le rattachement de l’instance ; il ne décrit pas sa procédure de consultation.

**Pour la procédure détaillée : non tranchable avec ce dossier.** Le corpus DRH fourni couvre les collectivités de plus de 350 agents et ne contient pas les règles permettant de dérouler une procédure pour votre commune.

Votre prochaine démarche est de **contacter le secrétariat du CST de votre CDG**, en lui indiquant :

- l’effectif de la commune et son affiliation ;
- le projet sur lequel vous souhaitez consulter ;
- la date de mise en œuvre envisagée.

Demandez-lui de confirmer **l’instance compétente, les pièces du dossier, le calendrier de saisine et l’articulation entre l’avis et votre décision**. Les règles de convocation, de quorum et de traitement de l’avis restent à vérifier : elles ne figurent pas dans l’extrait fourni.

**Confiance : stable sur le rattachement décrit par l’extrait ; abstention sur la procédure détaillée.**
