# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé :** le compagnon `recherche-juridique` est indisponible. Je m’appuie uniquement sur le corpus fourni, sans vérification officielle. Je peux expliquer la distinction des régimes et préparer l’examen du dossier, mais pas confirmer un droit individuel, calculer une reprise d’ancienneté ou rédiger un acte engageant.

**La référence à un indice ne donne pas au contractuel en CDI la carrière d’un fonctionnaire titulaire.** Selon le corpus, la CDIsation ne vaut pas titularisation : le contractuel ne bénéficie pas d’un avancement automatique d’échelon ou de grade. L’indice sert à déterminer sa rémunération ; il ne lui attribue pas un grade statutaire.

Sa demande comporte donc deux sujets distincts :

- **Reprise de toute l’ancienneté :** distinguer l’ancienneté retenue pour des droits propres aux contractuels et la prise en compte de l’expérience pour fixer ou réexaminer la rémunération. Le corpus ne permet pas de reconnaître une reprise intégrale automatique transformant les services passés en carrière indiciaire.
- **Avancement de grade :** ce mécanisme appartient à la carrière du fonctionnaire. Pour le contractuel, une évolution peut être recherchée par un réexamen de la rémunération ou des fonctions, selon les bases contractuelles et les règles applicables à vérifier. Le corpus distingue une obligation de réévaluation, dans son champ applicable, d’une augmentation automatique.

**État de décision : non tranchable pour la demande individuelle.** Le CDI et la rémunération par référence à un indice sont connus. En revanche, l’employeur territorial et son effectif, la nature publique du contrat, ses clauses, l’historique des services et les règles locales restent à établir. Le cadre d’emplois de référence et les fonctions réellement exercées sont nécessaires pour examiner une évolution salariale.

La marche à suivre consiste à préparer l’examen, sans engager immédiatement une modification de paie :

1. **La DRH rassemble** le CDI, les avenants, la fiche de poste, l’historique des contrats et services, ainsi que les décisions de rémunération et les derniers réexamens.
2. **Elle distingue dans la demande** les droits liés à l’ancienneté, la reconnaissance de l’expérience dans la rémunération et le souhait d’accéder à une carrière de fonctionnaire.
3. **Elle fait vérifier les sources applicables** à la date envisagée : régime contractuel, champ de la réévaluation, clauses du contrat et cadre local. Cette vérification permettra de déterminer les droits et les marges de décision.
4. **Elle soumet ensuite à l’autorité territoriale une réponse motivée**, examinant une éventuelle évolution de rémunération ou de fonctions. Si l’objectif est une carrière statutaire, les voies d’accès à la qualité de fonctionnaire doivent être étudiées séparément.

**Avant toute décision :** contrôler la base juridique, les clauses contractuelles, la cohérence du traitement des situations comparables et l’impact budgétaire. Ne pas appliquer une reconstitution de carrière de titulaire au seul motif que la rémunération utilise un indice.

**Niveau de confiance : abstention sur les droits individuels et leurs modalités ; cadrage fondé uniquement sur le corpus.**
