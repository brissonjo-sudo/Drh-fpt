# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Ne considérez pas votre agent comme démissionnaire sur cette seule base.** Avec le corpus fourni, l’applicabilité de la « présomption de démission de la loi de 2022 » à un **fonctionnaire territorial titulaire** n’est pas établie.

**Mode dégradé :** le compagnon *recherche-juridique* est indisponible. Le corpus ne contient ni le texte invoqué ni le module consacré à l’abandon de poste. Je m’abstiens donc de confirmer le dispositif applicable ou de fournir une procédure de radiation.

**État de décision : non tranchable.** L’absence sans justificatif est un fait à documenter ; elle ne permet pas, dans cette analyse, de conclure à une démission.

Pour avancer :

- **Gestionnaire RH :** réunir les dates d’absence, les justificatifs éventuellement reçus, les tentatives de contact et les courriers déjà adressés, avec leurs preuves de réception.
- **Service juridique ou CDG compétent :** vérifier, à la date des faits, le champ d’application du texte invoqué et examiner la piste de **l’abandon de poste**, identifiée dans le corpus, ainsi que les autres suites adaptées.
- **Avant toute décision :** faire confirmer les conditions, les garanties procédurales et la compétence de l’autorité signataire.

Le point décisif à préciser : **avez-vous déjà adressé un courrier à l’agent, avec quel contenu et quelle preuve de réception ?**

**Niveau de confiance : abstention sur le régime juridique applicable.**
