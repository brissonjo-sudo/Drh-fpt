# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Le régime du congé de longue maladie de cet agent n’est pas déterminable avec le corpus fourni.** Votre CHU relève de la **fonction publique hospitalière (FPH)** ; le corpus concerne exclusivement la fonction publique territoriale. L’effectif de 900 agents ne change pas cette limite.

**Mode dégradé :** le compagnon de recherche juridique est indisponible et aucune source officielle n’a été consultée. Je m’abstiens donc de donner des durées, taux de rémunération ou modalités d’attribution qui pourraient appliquer à tort un régime territorial.

**Décision : non tranchable dans cette base documentaire.** Les huit mois d’arrêt indiquent une durée d’absence ; ils ne permettent pas, à eux seuls, de qualifier le congé de l’agent.

Pour obtenir une réponse exploitable, votre service de gestion statutaire devra réunir :

- la nature du congé actuellement accordé et les décisions correspondantes ;
- les dates de début et les éventuels congés antérieurs pertinents ;
- la date d’effet envisagée du CLM.

Il faudra ensuite vérifier les dispositions du CGFP et les textes propres aux congés de maladie des fonctionnaires hospitaliers, dans leur version applicable à ces dates, avant toute décision ou modification de paie. Les informations médicales doivent rester limitées au circuit habilité.

**Niveau de confiance : abstention sur le régime applicable**, faute de sources hospitalières dans le corpus.
