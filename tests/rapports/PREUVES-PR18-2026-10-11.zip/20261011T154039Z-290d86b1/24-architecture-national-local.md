# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Votre cycle annualisé ancien ne suffit pas, à lui seul, à établir les règles applicables aujourd’hui. Sa conservation est à examiner au regard des textes actuels et de votre délibération locale.**

**Mode dégradé :** le compagnon `recherche-juridique` est indisponible. Je m’appuie uniquement sur le corpus fourni, sans vérification officielle. Je ne confirme donc aucune durée chiffrée ni la conformité juridique de votre cycle.

**Décision : non tranchable en l’état.** Il manque surtout la délibération applicable et la description de votre organisation.

Le corpus distingue deux niveaux :

- **Le socle national à vérifier aujourd’hui** : durée annuelle de référence, garanties de durée maximale de travail et de repos, éventuelles dérogations et conditions permettant une réduction pour sujétions particulières.
- **Les choix locaux à contrôler** : cycle annualisé, répartition des heures, périodes hautes et basses, modalités de décompte et éventuelle réduction liée aux contraintes du service. Le corpus rattache cette organisation à une délibération et à une consultation de l’instance compétente, dont les exigences actuelles restent à vérifier.

Il signale également la suppression d’anciens régimes plus favorables et la nécessité de leur mise en conformité. **L’ancienneté de votre organisation ne permet donc pas de présumer qu’elle peut être maintenue.** À l’inverse, elle ne démontre pas qu’il faut abandonner l’annualisation.

Pour avancer, la DRH et le responsable du service peuvent préparer ce contrôle :

| Action | Pièces utiles | Résultat attendu |
|---|---|---|
| Retrouver le cadre local | Délibération initiale, modifications, règlement et avis de l’instance consultée | Identifier la décision actuellement appliquée |
| Décrire le cycle réel | Plannings, décompte annuel, pauses, repos et traitement des absences | Comparer l’organisation prévue et celle pratiquée |
| Documenter les contraintes | Travail de nuit, dimanche, horaires décalés, pénibilité ou danger éventuels | Étayer toute réduction invoquée |
| Faire vérifier le droit applicable | Textes officiels actuels et pièces locales | Décider du maintien ou des adaptations nécessaires |

**Recommandation : examiner d’abord la possibilité de conserver la structure du cycle**, en corrigeant les paramètres qui seraient incompatibles avec les règles vérifiées. Si une durée réduite repose seulement sur un avantage historique, son maintien devra faire l’objet d’un contrôle particulier ; une sujétion réelle doit être documentée, pas supposée.

Pour trancher, pouvez-vous préciser **le type d’employeur, son effectif, les statuts des agents concernés**, et fournir le contenu de **la délibération ainsi que le cycle actuel** — volume annuel, horaires, repos et éventuelles réductions ?

Le risque principal serait de reconduire un régime devenu incompatible avec les textes, ou de modifier inutilement une organisation encore adaptée. **Avant toute modification ou validation du cycle, contrôler les textes, la délibération et les consultations applicables. Niveau de confiance : abstention sur la conformité de votre organisation.**
