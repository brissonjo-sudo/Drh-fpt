# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable avec ces seules informations.** Le nom et le cadre d’emplois ne permettent pas de déterminer si l’agent peut être nommé au grade supérieur cette année.

**Mode dégradé :** le skill de recherche juridique est indisponible. Le corpus permet de cadrer le dossier, mais pas de confirmer l’éligibilité sans vérifier les textes applicables.

Pour avancer, réunissez les éléments suivants — inutile de communiquer son nom :

- **Situation de l’agent :** titulaire ou stagiaire, grade actuel, grade visé, échelon et ancienneté, dates des services retenus, éventuel examen professionnel obtenu.
- **Date envisagée de nomination :** elle permettra de contrôler les conditions statutaires à la date utile.
- **Cadre local :** type de collectivité, effectif, LDG applicables, délibération fixant le ratio promus-promouvables, situation du tableau annuel et emploi permettant la nomination.

Il faut distinguer deux contrôles :

- **Conditions nationales :** le décret statutaire du cadre d’emplois détermine les conditions d’accès au grade visé. Elles restent à vérifier dans sa version applicable.
- **Décision locale :** remplir ces conditions ne suffit pas à établir qu’une nomination aura lieu ; il faut également examiner le tableau, les règles locales et les possibilités de nomination.

**Prochaine action :** faites établir par le gestionnaire carrière une fiche anonymisée réunissant ces données, puis faites contrôler les conditions statutaires et les pièces locales. Cette vérification permettra de distinguer l’agent potentiellement promouvable de celui effectivement proposé à la nomination.

**À ce stade, ne validez pas sa nomination sur la seule identification du cadre d’emplois. Niveau de confiance : abstention sur l’éligibilité et la nomination**, faute de données déterminantes et de vérification officielle.
