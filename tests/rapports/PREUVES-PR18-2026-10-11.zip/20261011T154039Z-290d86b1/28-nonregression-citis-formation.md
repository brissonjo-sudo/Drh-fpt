# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé** : le skill `recherche-juridique` est indisponible ; aucune source officielle n’a été vérifiée pour cette réponse.

D’après le corpus fourni :

- **Formation plénière** : lorsqu’un avis du conseil médical est requis pour apprécier l’imputabilité au service, c’est cette formation qui intervient, **pas la formation restreinte**.
- **Décision finale** : elle appartient à **l’autorité territoriale** ; le conseil médical rend un avis.

**Point à vérifier :** la saisine n’est pas systématique. Le seul fait que l’accident soit « contesté » ne permet pas, avec les éléments fournis, de déterminer si elle est obligatoire dans votre dossier.

**État de décision : non tranchable sur l’obligation de saisine.** Avant de poursuivre, le service RH doit préciser les motifs de contestation et vérifier les cas de saisine dans les textes FPT applicables à la date des faits.

**Niveau de confiance : abstention sur la validation juridique ; orientation issue du corpus uniquement.**
