# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé :** le compagnon `recherche-juridique` est indisponible et aucune source officielle n’est consultée. Le cadrage ci-dessous repose uniquement sur le corpus ; la notification ne peut pas être juridiquement finalisée.

**Selon le corpus, non :** le conseil de discipline de recours a été supprimé, hors procédures transitoires anciennes. Il n’est donc pas présenté comme une voie de recours pour une sanction nouvelle prononcée en 2026. Le **conseil de discipline préalable** et le **conseil de discipline de recours** sont deux instances distinctes.

Pour la notification, le corpus oriente vers :

- les **recours administratifs utiles**, notamment le recours gracieux auprès de l’autorité ayant prononcé la sanction, sous réserve de vérification ;
- le **recours contentieux devant le tribunal administratif compétent**.

**État de décision : non tranchable pour la rédaction définitive des voies et délais.** Il manque la vérification des textes applicables à la date de notification, du statut de l’agent et du tribunal compétent. Je ne donne donc aucun délai exact.

Voici une **trame de travail à compléter avant notification** :

> La présente décision peut faire l’objet d’un recours gracieux auprès de [autorité compétente], selon [délai et modalités vérifiés], ainsi que d’un recours contentieux devant le tribunal administratif de [tribunal compétent], selon [délai, point de départ et modalités vérifiés].  
> [Préciser, après vérification, l’effet du recours gracieux sur le délai du recours contentieux.]

Le service RH ou juridique doit vérifier ces mentions et leur articulation **avant l’envoi**. Une indication erronée ou incomplète peut compromettre la sécurité de la notification, notamment concernant l’opposabilité des délais.

**Niveau de confiance : abstention sur les mentions définitives ; orientation documentaire explicite dans le corpus contre le recours à l’ancienne instance.**
