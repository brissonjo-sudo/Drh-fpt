# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé — décision non tranchable sans vérification du texte applicable.**

D’après le corpus, l’article **L. 2131-2 du CGCT ne comporte plus de catégorie générale visant les « sanctions disciplinaires de toute nature »**. Cette indication reste **à confirmer en version consolidée** : aucune source officielle n’a été consultée pour cette réponse.

On ne peut donc **déduire une transmission obligatoire du seul fait qu’il s’agit d’une exclusion de 5 jours**. Je ne peux toutefois certifier l’absence d’obligation pour cet acte précis.

Avant de décider, le service juridique doit vérifier :

- la version de l’article applicable à la date de l’arrêté et les catégories d’actes qu’elle vise ;
- séparément, la convention locale de télétransmission et une éventuelle demande du préfet.

**Niveau de confiance : abstention sur l’obligation exacte de transmission.** Le corpus écarte l’automatisme « sanction = transmission obligatoire », mais ne remplace pas la vérification officielle.
