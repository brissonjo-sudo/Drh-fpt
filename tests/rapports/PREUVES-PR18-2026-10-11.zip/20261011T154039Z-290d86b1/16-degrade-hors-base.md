# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé — décision non tranchable.** Le skill `recherche-juridique` est indisponible : je ne peux fournir ni un montant exact utilisable en paie ni une référence juridique présentée comme confirmée.

Le corpus précise que les **sapeurs-pompiers professionnels relèvent d’un régime spécifique**, mais il ne contient ni le texte instituant l’indemnité de feu ni sa règle de calcul. Lui appliquer le régime indemnitaire territorial général serait donc inapproprié.

Pour obtenir le montant et son fondement :
- **Le gestionnaire RH** réunit la date de paie concernée, la situation statutaire et les éléments de rémunération de chaque agent.
- **Le service paie ou juridique** vérifie sur Légifrance le texte propre aux SPP, sa version applicable, les bénéficiaires, l’assiette et les modalités de calcul, puis contrôle les paramètres de paie.

**Niveau de confiance : abstention sur le montant et le texte exact**, faute de source dédiée et de vérification officielle possible.
