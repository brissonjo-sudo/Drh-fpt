# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : le skill recherche-juridique est indisponible. Je ne peux pas fournir la valeur exacte du point d’indice pour votre arrêté.** Le corpus impose de vérifier cette valeur volatile sur une source officielle à la date utile, avant tout chiffre destiné à un acte.

**Décision : non tranchable en l’état.** Le corpus ne contient aucune valeur actuelle vérifiée.

Pour finaliser l’arrêté, faites confirmer par le service paie ou juridique la valeur applicable à sa **date d’effet**, à partir du texte officiel en vigueur sur Légifrance. Conservez la référence, la version applicable et la preuve de consultation avant signature.

**Niveau de confiance : abstention sur le chiffre.** Une valeur non vérifiée pourrait fausser le montant inscrit dans l’arrêté.
