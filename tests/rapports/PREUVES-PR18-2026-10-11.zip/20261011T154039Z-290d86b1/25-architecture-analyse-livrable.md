# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Les informations fournies ne permettent pas de déterminer si l’agent peut être nommé au grade supérieur.

**Mode dégradé :** le compagnon `recherche-juridique` est indisponible et aucune source officielle n’a été consultée. Conformément au corpus, je peux fournir une analyse bornée et une **trame préparatoire**, mais pas un arrêté juridiquement engageant prêt à signer.

### Ce qui doit permettre de trancher

Le corpus distingue l’avancement de grade, dans le même cadre d’emplois, de la promotion interne, qui change de cadre d’emplois. Il distingue également **l’inscription au tableau d’avancement** de la nomination : la première ne suffit pas, à elle seule, à établir la possibilité de la seconde.

| Informations | État du dossier |
|---|---|
| **Connues** | Demande d’analyse et de projet d’arrêté concernant une nomination après avancement de grade. |
| **Bloquantes** | Employeur et effectif ; statut de l’agent ; cadre d’emplois ; grades actuel et visé ; situation de carrière ; dates de référence et d’effet ; conditions statutaires ; tableau annuel d’avancement ; ratio local et LDG applicables ; situation de l’emploi permettant la nomination. |
| **Non bloquantes pour le cadrage** | Référence interne de l’arrêté et présentation administrative : elles peuvent rester en champs à compléter. |

Les données bloquantes peuvent aussi apparaître comme champs dans la trame, mais **elles devront être renseignées et contrôlées avant toute décision**.

Le contrôle doit séparer :

- **Le socle national :** statut particulier applicable, conditions d’avancement et règles de nomination et de classement, à vérifier à la date envisagée.
- **Les paramètres locaux :** tableau annuel, ratio, LDG et pièces relatives à l’emploi, sans présumer leur contenu.

### Actions à mener

1. **Gestionnaire carrière :** réunir le dernier arrêté de situation, les informations statutaires et les pièces locales ; constituer une fiche de contrôle.
2. **DRH avec appui juridique :** vérifier les sources officielles applicables et confronter chaque condition aux pièces du dossier.
3. **Autorité territoriale :** décider après validation ; faire compléter le projet et contrôler les formalités avant signature et mise en paie.

### Trame préparatoire d’arrêté

**Document incomplet — non validé juridiquement — ne pas signer en l’état**

**[Collectivité / établissement]**  
**Arrêté n° [référence]**  
**Objet : nomination de [identité de l’agent] au grade de [grade visé] par avancement de grade**

**L’autorité territoriale [qualité],**

**Visas à compléter après vérification :**

- [Dispositions statutaires applicables et version pertinente]
- [Statut particulier du cadre d’emplois]
- [Délibération locale relative au ratio applicable]
- [Lignes directrices de gestion pertinentes]
- [Tableau annuel d’avancement : année, référence et inscription de l’agent]
- [Pièces relatives à l’emploi permettant la nomination]
- [Dernier arrêté établissant la situation de carrière de l’agent]

**Éléments justifiant la décision :**  
[Conditions statutaires établies, situation de l’agent et éléments locaux retenus ; ne compléter qu’après contrôle.]

**Dispositif à finaliser après validation :**

**Article 1 — Nomination**  
[Disposition de nomination précisant l’agent, le cadre d’emplois, le grade et la date d’effet validée.]

**Article 2 — Classement**  
[Échelon, ancienneté conservée et éléments de classement établis selon les règles vérifiées ; aucune valeur présumée.]

**Article 3 — Exécution**  
[Services responsables et modalités d’exécution applicables.]

**Article 4 — Formalités et recours**  
[Notification ; publicité et transmission si applicables ; voies et délais de recours vérifiés.]

Fait à [lieu], le [date].  
[Qualité, identité et signature de l’autorité compétente]

**Avant signature :** contrôler compétence, visas, justification, classement, date d’effet, formalités et recours. Les risques principaux sont une nomination sans conditions établies, un classement erroné ou une date d’effet irrégulière. Limiter les données personnelles aux informations nécessaires.

**Niveau de confiance : abstention sur la possibilité juridique de nomination et sur la validité de l’acte.**
