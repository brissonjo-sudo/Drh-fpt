# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Je recommande de préparer le dossier et de faire vérifier le cadre juridique avant de décider d’engager formellement la procédure. Une exclusion de cinq jours ne doit pas être arrêtée à ce stade.

**Mode dégradé :** le compagnon `recherche-juridique` est indisponible et aucune source officielle n’a été consultée. Je m’appuie exclusivement sur le corpus fourni : je peux donner un cadrage et des actions préparatoires, mais pas certifier une procédure disciplinaire applicable.

**Ce que le corpus permet de comprendre**

Le corpus classe une exclusion temporaire de cinq jours dans le **deuxième groupe**, avec intervention du **conseil de discipline**. Il distingue cette sanction de la suspension conservatoire. Ces indications doivent être confirmées dans les textes applicables avant leur utilisation.

La sanction envisagée ne suffit pas à justifier la procédure : il faut établir les faits, leur imputabilité à l’agent et leur qualification disciplinaire. La décision finale devra aussi apprécier leur gravité et la proportion de la sanction.

Les informations sont les suivantes :

- **Connues :** agent titulaire, faits soupçonnés, exclusion de cinq jours envisagée.
- **Bloquantes :** employeur territorial et effectif relevant du corpus, éventuel statut particulier, cadre d’emplois, faits précis et pièces disponibles, dates des faits et de leur connaissance effective, éventuelles poursuites pénales, date envisagée de décision.
- **À préciser pour le circuit :** affiliation au centre de gestion et organisation du secrétariat de l’instance. Elles ne doivent pas être présumées.

**Actions à lancer, dans l’ordre**

Les étapes ci-dessous constituent un **plan de préparation et de contrôle**, pas une procédure disciplinaire juridiquement validée.

| Ordre | Action et responsable | Contrôle / preuve attendue |
|---|---|---|
| 1 | **DRH : qualifier le dossier** avec les informations manquantes ci-dessus. | Fiche de situation ; confirmation du régime territorial applicable. Si le dossier est hors périmètre, orientation vers la source compétente. |
| 2 | **DRH et encadrement : réunir les pièces existantes**, y compris celles favorables à l’agent. Distinguer faits établis, témoignages et soupçons. | Chronologie datée, inventaire des pièces, origine et fiabilité des éléments ; accès limité aux personnes utiles. |
| 3 | **DRH / service juridique : faire vérifier les sources officielles** à la date pertinente. | Note traçable couvrant qualification des faits, prescription, compétence, droits de la défense, droit de se taire et circuit du conseil de discipline. **Avant tout recueil d’observations à visée disciplinaire**, contrôler les garanties applicables. |
| 4 | **Autorité territoriale, sur analyse DRH/juridique : arbitrer l’engagement.** | Si les éléments et vérifications le permettent, décision d’engager ; sinon, compléter le dossier ou ne pas poursuivre. Garder la sanction finale ouverte. |
| 5 | **Si l’engagement est validé : DRH et secrétariat compétent organisent la procédure vérifiée.** | Contrôler information de l’agent, accès au dossier, assistance, temps de préparation et saisine de l’instance selon les règles confirmées. |
| 6 | **Après instruction : autorité compétente statue.** | Avant signature : faits retenus, proportionnalité, motivation, compétence, date d’effet, notification, recours et obligation éventuelle de transmission, vérifiés séparément. |

**Risques principaux :** sanction fondée sur des soupçons insuffisamment étayés, décision prédéterminée, prescription ou droits de la défense méconnus.

**Niveau de confiance : abstention sur la possibilité juridique d’engager immédiatement et sur la procédure exacte.** La prochaine décision utile est de mandater la DRH pour constituer le dossier et obtenir les vérifications nécessaires.
