# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**La procédure ne peut pas être déterminée avec ce corpus : votre commune d’environ 40 agents est hors de son périmètre, limité aux collectivités de plus de 350 agents.** Je ne peux donc pas vous fournir une procédure détaillée adaptée à votre situation.

**Mode dégradé :** le compagnon de recherche juridique est indisponible ; les règles applicables n’ont pas été vérifiées.

Deux points sont nécessaires pour avancer :

- **Quel est l’objet de la consultation ?** Réorganisation, temps de travail, régime indemnitaire, autre ?
- **Quel CST est compétent pour votre commune ?** Votre expression « mon CST » ne permet pas de déterminer s’il s’agit d’une instance propre ou d’une instance placée auprès du centre de gestion.

**Action immédiate :** adressez au centre de gestion ou au secrétariat du CST identifié une présentation du projet et demandez confirmation de l’instance compétente, des pièces à transmettre, du calendrier et des modalités de saisine. Faites contrôler les textes applicables et le règlement de cette instance avant de finaliser votre démarche.

**État de décision : non tranchable en l’état. Niveau de confiance : abstention sur la procédure juridique**, faute de documentation adaptée et de vérification officielle.
