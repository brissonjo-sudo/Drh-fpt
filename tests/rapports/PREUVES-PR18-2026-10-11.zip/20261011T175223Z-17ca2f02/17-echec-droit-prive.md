# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre agent est titulaire et absent sans justificatif depuis plusieurs semaines. L’employeur, les dates exactes et l’existence d’une mise en demeure ne sont pas précisés.

**Décision : non tranchable.** Je ne peux pas valider l’utilisation de la présomption de démission. La distinction à faire vérifier est celle entre la **présomption de démission du droit privé** et la piste de l’**abandon de poste dans la fonction publique territoriale**. L’absence prolongée, seule, ne permet pas de sécuriser une radiation.

Voici le dossier à préparer pour votre service RH ou juridique :

- **Qualification :** confirmer l’employeur territorial et vérifier dans les sources officielles le champ respectif des deux dispositifs. Pour l’abandon de poste, contrôler la qualification de licenciement distinct de la discipline, ainsi que les conséquences sur le conseil de discipline et la communication du dossier au titre disciplinaire.
- **Pièces :** réunir les dates d’absence, obligations de service, échanges avec l’agent et éventuels justificatifs, notamment médicaux.
- **Mise en demeure :** si elle existe, faire contrôler son contenu écrit, sa notification, le délai de reprise approprié et l’avertissement relatif au risque de radiation sans procédure disciplinaire préalable.
- **Situation à l’échéance :** établir si l’agent a repris et examiner ses réponses, intentions ou empêchements. Le contrôle doit porter sur la rupture du lien avec le service, sans la déduire automatiquement du silence ou de la non-reprise.
- **Avant toute décision :** faire vérifier compétence, motivation, date d’effet, notification, voies et délais de recours et éventuelle transmission au contrôle de légalité.

Les sources à consulter sont le **Code général de la fonction publique**, le **Code du travail**, la jurisprudence administrative sur l’abandon de poste et le **Code général des collectivités territoriales**, dans leurs versions applicables.

**Pour préciser le dossier : quel est l’employeur, depuis quelle date l’agent est-il absent et une mise en demeure a-t-elle déjà été notifiée ?**

**Niveau de confiance : abstention sur la conclusion juridique.** Le risque principal est une rupture des fonctions fondée sur un dispositif inadapté ou un abandon de poste insuffisamment établi.
