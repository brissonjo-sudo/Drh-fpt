# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes DRH d’un CHU de 900 agents ; l’agent est titulaire et en arrêt maladie depuis huit mois.

Votre question concerne la **fonction publique hospitalière**, alors que le corpus fourni couvre uniquement la **fonction publique territoriale**. L’effectif de 900 agents ne lève pas cette exclusion. Je ne peux donc pas transposer ce corpus pour déterminer le régime de congé de longue maladie, sa durée ou sa rémunération.

**Décision : non tranchable avec ce corpus.** Les huit mois d’arrêt ne permettent pas, à eux seuls, de qualifier le congé dans cette analyse.

Pour préparer la vérification par votre service juridique ou un référent RH hospitalier, réunissez :

- les décisions précisant la nature actuelle du congé et les dates exactes des périodes accordées ;
- le corps et le statut particulier de l’agent ;
- l’existence d’une demande de congé de longue maladie, les avis médicaux administratifs disponibles et la date d’effet envisagée.

Le contrôle devra porter sur le **Code général de la fonction publique et les textes propres aux congés des fonctionnaires hospitaliers**, dans leur version applicable aux dates concernées : conditions d’accès, articulation avec le congé actuel, droits à rémunération, autorité décisionnaire et instance médicale compétente.

Avant toute décision individuelle, faites également vérifier les exigences de motivation, de notification et de recours, notamment en cas de refus. Limitez la circulation des informations médicales aux éléments nécessaires.

**Niveau de confiance : abstention sur le régime juridique demandé**, faute de sources hospitalières vérifiées.
