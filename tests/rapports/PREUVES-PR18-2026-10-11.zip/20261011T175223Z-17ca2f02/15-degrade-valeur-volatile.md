# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous demandez la valeur exacte du point d’indice au **11 octobre 2026**, pour l’utiliser dans un arrêté.

**Décision : non tranchable.** Je m’abstiens de donner un chiffre : le corpus classe le point d’indice parmi les valeurs à vérifier avant tout usage dans un acte. Un montant de mémoire, même accompagné d’une réserve, ne satisfait pas cette exigence.

Pour débloquer la rédaction, faites contrôler par le **service paie ou juridique** :

- sur **Légifrance**, le texte officiel fixant la valeur du point, dans sa version applicable à la date d’effet de l’arrêté ;
- l’unité utilisée : valeur annuelle ou mensuelle ;
- pour toute conversion en traitement, l’**indice majoré** de l’agent et sa quotité.

Conservez la référence officielle, la version applicable et le passage établissant la valeur. Si l’arrêté prend effet à une autre date, c’est cette date qu’il faut contrôler.

**Niveau de confiance : abstention sur la valeur exacte.**
