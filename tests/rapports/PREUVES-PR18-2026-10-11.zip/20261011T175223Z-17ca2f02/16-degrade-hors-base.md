# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** votre demande concerne l’indemnité de feu de sapeurs-pompiers professionnels. L’employeur, les grades et la date de rémunération concernée ne sont pas précisés.

**Décision : non tranchable.** Le corpus signale un régime indemnitaire spécifique aux sapeurs-pompiers professionnels, mais ne fournit ni le barème de l’indemnité de feu ni son texte fondateur. Je ne peux donc donner **aucun montant exact, taux ou numéro de décret** sans la vérification requise.

Pour obtenir une réponse utilisable en paie, le service RH/paie devra :

- **Identifier la source :** consulter sur Légifrance le texte indemnitaire propre aux sapeurs-pompiers professionnels, dans sa version applicable à la période concernée.
- **Contrôler la règle :** vérifier les bénéficiaires, le taux, l’assiette et les éventuelles conditions de versement ; examiner les actes locaux pertinents.
- **Réunir les données individuelles :** cadre d’emplois, grade, quotité et éléments de traitement nécessaires. Si l’assiette est indiciaire, vérifier l’indice majoré et la valeur du point à la date utile avant toute conversion en euros.

**Niveau de confiance : abstention sur le montant et le fondement juridique exact**, faute de source officielle vérifiée.
