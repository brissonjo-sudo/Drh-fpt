# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Faits connus :** vous êtes maire d’une commune d’environ 40 agents et souhaitez consulter un **comité social territorial (CST)**. Votre commune est hors du périmètre du corpus DRH fourni, réservé aux collectivités de plus de 350 agents. Je ne peux donc pas vous donner une procédure détaillée et juridiquement validée.

**État de décision : non tranchable en l’état.** Le premier contrôle concerne le rattachement : il faut vérifier si la consultation relève du CST placé auprès du **centre de gestion (CDG)** ou d’une autre organisation applicable à votre commune. Je ne certifie ici ni le seuil d’un CST propre ni l’instance compétente.

Pour préparer votre consultation, voici le dossier à constituer :

| À préparer | Acteur à solliciter | Contrôle attendu |
|---|---|---|
| Objet précis du projet et date envisagée de décision | Secrétariat de mairie / gestionnaire RH | Vérifier si une consultation est requise et à quel moment |
| Effectif retenu pour les instances, affiliation au CDG et rattachement actuel | CDG / gestionnaire RH | Confirmer le CST compétent et son secrétariat |
| Projet de document, note explicative et conséquences pour les agents | Service porteur du projet | Obtenir la liste des pièces nécessaires |
| Calendrier et modalités de saisine | Secrétariat du CST compétent | Faire confirmer les formalités, délais, inscription à l’ordre du jour et éventuelle nouvelle consultation |
| Préparation de la décision après consultation | Gestionnaire RH / conseil juridique | Vérifier l’autorité compétente, la portée de l’avis, les formalités de publicité ou notification et, selon l’acte, les recours et la transmission |

Les sources à contrôler sont le **Code général de la fonction publique**, ses dispositions réglementaires applicables aux CST, le **Code général des collectivités territoriales** pour l’acte envisagé, ainsi que le règlement et les consignes du CST compétent. Une pratique locale doit être rapprochée des règles nationales.

**Pour avancer, trois informations suffisent :**

- Sur quel projet souhaitez-vous consulter le CST ?
- Votre commune est-elle affiliée au CDG, et quel CST consultez-vous habituellement ?
- À quelle date souhaitez-vous prendre la décision ?

**Niveau de confiance : abstention sur la procédure juridique.** Le risque principal est de saisir une instance incompétente ou d’adopter le projet sans avoir confirmé les conditions de consultation. Ce dossier sert à préparer ces vérifications.
