# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Mode dégradé : le compagnon de recherche juridique est indisponible et aucune source officielle n’a été consultée.** Je peux préparer l’arbitrage, mais pas certifier la possibilité d’engager la procédure ni fournir une procédure disciplinaire directement exécutable.

**État de décision : non tranchable en l’état.** Cela ne signifie pas que la procédure est interdite : les faits et les vérifications nécessaires manquent pour répondre juridiquement.

Les données connues sont : un agent titulaire, des faits soupçonnés et une exclusion temporaire de **5 jours envisagée**. Cette durée est votre hypothèse de sanction ; sa qualification réglementaire reste à vérifier.

À réunir en une fois :

- **Employeur et circuit** : type de collectivité, confirmation du périmètre de plus de 350 agents, affiliation au centre de gestion pour déterminer le circuit d’instance.
- **Faits** : nature précise, dates, pièces disponibles, témoignages et circonstances pouvant expliquer ou contredire les accusations.
- **Chronologie** : date de connaissance effective des faits par l’administration, éventuelles poursuites pénales et démarches déjà réalisées auprès de l’agent.
- **Calendrier** : date envisagée pour l’engagement formel et pour une éventuelle décision.

Le contrôle juridique devra notamment déterminer si les faits peuvent constituer une faute, si l’action reste possible au regard de la prescription, quelle instance doit être consultée pour la sanction envisagée et quelles garanties doivent précéder les observations de l’agent. **Le corpus interne ne suffit pas à certifier ces points.**

**Ma recommandation : préparer le dossier maintenant, sans arrêter la sanction.** L’exclusion envisagée doit rester une option à apprécier après établissement des faits, prise en compte de la défense et validation juridique. La décision immédiate recommandée porte donc sur la préparation de l’instruction, pas sur l’exclusion.

Voici les actions concrètes, dans l’ordre. Ce tableau organise la préparation ; il ne remplace pas la procédure réglementaire à vérifier.

| Ordre | Action à lancer | Responsable proposé | Contrôle et preuve attendue |
|---|---|---|---|
| **1** | Réunir les informations ci-dessus et établir une chronologie factuelle. | DRH avec le responsable du service | Distinguer faits constatés, témoignages, soupçons et inconnues. Conserver les pièces originales et leur provenance. |
| **2** | Faire vérifier le cadre juridique avant l’engagement formel et avant tout recueil d’observations à portée disciplinaire. | Service juridique ou conseil compétent ; CDG selon le circuit applicable | Note datée fondée sur les sources officielles applicables : régime du titulaire, prescription, classement de la sanction envisagée, instance préalable, compétence du signataire et droit de se taire. |
| **3** | Préparer un dossier complet et l’organisation de la défense, puis les faire valider avant utilisation. | DRH et service juridique | Contrôler l’information de l’agent, l’accès à l’intégralité du dossier, l’assistance, le temps de préparation et l’information sur le droit de se taire. Prévoir une preuve de chaque formalité, sans inventer de délai. |
| **4** | Après validation du cadre, conduire l’instruction selon le circuit confirmé, recueillir la défense et solliciter l’instance si elle est requise. | Acteurs désignés par la validation juridique | Traçabilité des échanges, examen des éléments à charge et à décharge, contrôle de la consultation préalable applicable et conservation de l’avis éventuel. |
| **5** | Soumettre un arbitrage motivé à l’autorité compétente. | DRH et service juridique | Comparer les suites possibles selon les faits établis : absence de sanction, sanction différente ou exclusion envisagée. Examiner la proportionnalité sans traiter les 5 jours comme un résultat acquis. |
| **6** | Si une sanction est retenue, préparer l’acte et organiser sa mise en œuvre après contrôle final. | DRH, service juridique, signataire compétent et paie | Vérifier compétence, motivation en fait et en droit, date d’effet, notification, recours, publicité éventuelle, transmission au contrôle de légalité et conséquences financières. |

Pour la vérification, les sources à consulter sont le **CGFP**, les dispositions réglementaires applicables à la discipline territoriale, le **CGCT**, les règles de motivation et les textes ou décisions actuels relatifs aux garanties de défense.

**Points de vigilance avant toute décision :** faits insuffisamment établis, sanction prédéterminée, garantie de défense omise, instance mal identifiée ou formalité de notification incorrecte. Ne présumez pas une transmission obligatoire au préfet : son fondement et les modalités locales doivent être contrôlés séparément. Limitez aussi la circulation des données de l’agent aux personnes nécessaires au traitement du dossier.

**Niveau de confiance : abstention sur la conclusion juridique.** Le dossier de préparation est utilisable ; l’engagement formel et la sanction restent à valider sur les sources officielles.
