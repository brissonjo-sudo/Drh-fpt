# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Le compagnon de recherche juridique est indisponible : je réponds en **mode dégradé**, sans consultation de sources officielles. Le corpus permet de préparer le dossier, mais pas de confirmer la possibilité de nomination ni de produire un arrêté juridiquement sécurisé.

Les champs à compléter permettent d’avancer la rédaction. Ils ne remplacent pas la vérification des conditions de nomination.

**Informations nécessaires pour trancher**

La seule donnée connue est votre demande d’une nomination après avancement de grade. Les éléments suivants sont bloquants et doivent être réunis ensemble :

| Élément à compléter | Contrôle à effectuer |
|---|---|
| Employeur, type de collectivité, effectif et éventuel statut particulier | Confirmer le périmètre territorial et le régime applicable |
| Statut de l’agent, cadre d’emplois, grade actuel et grade cible | Vérifier que l’opération relève bien de l’avancement de grade envisagé |
| Échelon, ancienneté, services et éventuel examen professionnel | Contrôler les conditions prévues par le statut particulier |
| Année et inscription au tableau d’avancement | Vérifier le tableau applicable et la situation de l’agent |
| Délibération sur les ratios et LDG applicables | Contrôler les règles locales et leur articulation avec les textes nationaux |
| Emploi concerné, situation budgétaire et quotité | Vérifier le support de la nomination |
| Date d’effet souhaitée | Déterminer la version des textes et les règles de classement applicables |

L’affiliation au centre de gestion est à préciser si elle modifie le circuit concerné. Les mentions matérielles — numéro de l’arrêté, lieu, coordonnées — peuvent rester en attente sans modifier l’analyse.

**Analyse à conduire**

La piste documentaire est celle d’un avancement au sein du même cadre d’emplois, suivie d’une nomination dans le grade cible. Cette qualification doit être contrôlée : un changement de cadre d’emplois, un statut de stagiaire ou de contractuel peuvent nécessiter une autre analyse.

Il faut distinguer :

- **Le socle national à vérifier** : conditions statutaires, modalités de nomination et de classement, compétence du signataire et formalités de l’acte.
- **Les éléments locaux à contrôler** : ratios, LDG, tableau d’avancement et emploi concerné. Leur existence et leur contenu ne sont pas présumés.

Aucune de ces pièces, prise isolément, ne permet ici de confirmer la nomination.

**Recommandation et ordre de travail**

1. **Gestionnaire carrière** : réunir les pièces ci-dessus et établir une fiche de situation, avec les justificatifs associés.
2. **DRH ou juriste compétent** : consulter les sources officielles applicables à la date d’effet, notamment le statut particulier, puis consigner la règle, sa version et le résultat de chaque contrôle.
3. **Service carrière et paie** : préparer le classement et les conséquences financières uniquement après validation juridique et vérification des données de paie.
4. **Autorité compétente** : examiner le projet final après contrôle du signataire, de la date d’effet et des formalités.

Si la voie de l’avancement de grade ne correspond pas au dossier, faire qualifier la voie appropriée avant de rédiger l’acte.

**Trame préparatoire de l’arrêté**

*Document de travail — rédaction finale suspendue aux contrôles ci-dessus. Cette trame ne vaut ni décision de nomination ni document prêt à signer.*

> **[COLLECTIVITÉ / ÉTABLISSEMENT]**  
> **Projet d’arrêté n° [référence]**  
> **Objet : nomination envisagée de [identité] au grade de [grade cible], par avancement de grade**
>
> **Autorité envisagée pour signer :** [qualité — compétence et éventuelle délégation à vérifier].
>
> **Visas à renseigner après vérification**
>
> - [Dispositions nationales applicables, références et version confirmées].
> - [Statut particulier du cadre d’emplois concerné].
> - [Délibération locale relative aux ratios : référence et date].
> - [LDG applicables : référence et date].
> - [Tableau d’avancement : année, référence et inscription de l’agent].
> - [Actes relatifs à l’emploi et à la situation actuelle de l’agent, selon leur pertinence].
>
> **Éléments justificatifs à établir**
>
> [Situation actuelle de l’agent].  
> [Conditions statutaires effectivement remplies et pièces justificatives].  
> [Contrôles du tableau, des paramètres locaux et de l’emploi].  
> [Éléments fondant la décision envisagée].
>
> **Article 1 — Nomination envisagée**  
> Agent : [identité].  
> Grade actuel : [grade].  
> Grade cible : [grade].  
> Cadre d’emplois : [cadre d’emplois].  
> Date d’effet proposée : [date].  
> **Rédaction de la décision à insérer après validation de sa possibilité.**
>
> **Article 2 — Classement envisagé**  
> [Échelon, ancienneté conservée et références de classement à compléter après contrôle].  
> **Aucun indice ni montant arrêté à ce stade.**
>
> **Article 3 — Mise en œuvre**  
> [Services chargés de l’exécution et instructions de gestion à préciser après validation].
>
> **Article 4 — Formalités**  
> [Notification, publicité et éventuelle transmission : modalités à déterminer selon les textes applicables].  
> [Voies et délais de recours : rédaction à vérifier avant insertion].
>
> Fait à [lieu], le [date].  
> [Identité et qualité du signataire — signature après validation finale].

Avant signature, les risques principaux à contrôler sont une mauvaise qualification de l’opération, des conditions d’accès non remplies, un classement erroné ou des formalités inadéquates. Limiter les données personnelles aux informations nécessaires au dossier.

**Niveau de confiance : abstention sur la possibilité juridique de nomination et sur le contenu définitif de l’arrêté.** Le livrable ci-dessus constitue un dossier de préparation à compléter et à vérifier.
