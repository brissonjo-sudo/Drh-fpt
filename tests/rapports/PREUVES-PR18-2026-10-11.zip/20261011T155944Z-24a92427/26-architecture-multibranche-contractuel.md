# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé :** le compagnon de recherche juridique est indisponible et aucune source officielle n’a été consultée. Les règles ci-dessous sont donc des **pistes à vérifier avant décision**.

**État de décision : non tranchable en l’état.** Il faut examiner séparément la demande de reprise d’ancienneté, l’évolution de rémunération et la demande d’avancement de grade.

Le corpus invite à distinguer **la rémunération par référence à un indice** et **la carrière d’un fonctionnaire titulaire**. Cette référence, à elle seule, ne démontre ni une nomination dans un grade ni l’application des règles de classement et d’avancement des titulaires.

Les points juridiques à confirmer sont les suivants :

- **Ancienneté :** déterminer quels services peuvent être pris en compte, pour quel objet et sur quel fondement. La prise en compte pour une réévaluation de rémunération ne se confond pas avec une reprise d’ancienneté lors d’un classement statutaire. Le caractère automatique d’une reprise de *toute* l’ancienneté n’est pas établi.
- **Avancement de grade :** le corpus oriente vers une distinction entre carrière statutaire et évolution contractuelle. Il faut confirmer l’absence de mécanisme d’avancement de grade applicable à ce CDI, sans assimiler l’indice de référence à un grade détenu.
- **Réévaluation de rémunération :** vérifier l’obligation applicable au CDI, sa périodicité et les critères à examiner. Une obligation de réexaminer la rémunération doit être distinguée d’un droit à une augmentation ou à une progression automatique d’échelon.

**Informations à réunir**

- **Connues :** CDI, rémunération référencée à un indice, demande de reprise intégrale d’ancienneté et d’avancement de grade.
- **Bloquantes :** employeur et régime de droit public territorial ; contrat et avenants, fondement du recrutement, clauses de rémunération et d’évolution ; historique précis des services ; dernière réévaluation ; cadre local de rémunération ; date d’effet demandée et éventuelle demande rétroactive.
- **Non bloquantes à ce stade :** logiciel de paie et circuit interne de traitement. Ils pourront être précisés lors de la mise en œuvre.

Le cadre national applicable aux contractuels et les engagements locaux ou contractuels doivent être contrôlés séparément : aucun choix local ne doit être supposé.

**Marche à suivre recommandée**

| Étape | Responsable | Contrôle et preuve attendue |
|---|---|---|
| Constituer le dossier | Gestionnaire RH avec l’agent | Contrat, avenants, justificatifs des services, fonctions exercées et décisions antérieures de rémunération. |
| Vérifier les règles à la date utile | DRH / service juridique | Sources officielles applicables aux contractuels territoriaux, éventuelle recodification, clauses contractuelles et cadre local ; conserver les passages utiles. |
| Examiner les trois demandes séparément | DRH | Note distinguant droits éventuellement établis, réévaluation de rémunération et demande de carrière statutaire. Aucun montant avant contrôle des paramètres de paie. |
| Soumettre une réponse motivée | Autorité compétente, à confirmer | Décision fondée sur les vérifications, puis formalités et mise en paie si une évolution est retenue. |

**Orientation pratique :** instruire prioritairement la possibilité de valoriser l’expérience, les fonctions et les responsabilités dans la rémunération contractuelle. Si l’agent recherche une carrière de titulaire, examiner séparément les voies d’accès au statut correspondant et ses conditions de classement, sans promettre une titularisation ni une reprise intégrale.

**Formulation utilisable pour l’instruction interne :**

> La demande doit être examinée au regard du contrat, des services justifiés et du cadre de rémunération applicable. La référence indiciaire ne suffit pas à établir l’application des mécanismes de carrière des titulaires. La DRH vérifiera séparément la prise en compte de l’expérience, les obligations de réévaluation et les possibilités d’évolution de rémunération avant de proposer une réponse.

Les risques à contrôler sont une transposition injustifiée du régime des titulaires, l’omission d’un engagement contractuel ou d’une réévaluation requise, et une régularisation rétroactive sans fondement établi. Avant toute réponse défavorable formelle, faire vérifier sa motivation et les recours applicables. Limiter la circulation du dossier aux personnes chargées de son traitement.

**Niveau de confiance : abstention sur les droits exacts et la décision finale, faute de vérification officielle.**
