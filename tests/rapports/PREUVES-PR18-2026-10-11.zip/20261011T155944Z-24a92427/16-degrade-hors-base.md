# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : aucune source officielle n’a été consultée. Je ne peux donc fournir ni montant exact ni référence juridique confirmée.**

Le corpus indique que les **sapeurs-pompiers professionnels relèvent d’un régime indemnitaire spécifique**, mais il ne contient pas le texte régissant l’indemnité de feu. Son montant et son fondement sont donc **hors de la base documentaire fournie**.

**Décision : non tranchable avec les éléments disponibles.**

Pour obtenir une réponse exploitable, la DRH ou le service paie doit :

- rechercher sur **Légifrance le texte indemnitaire propre aux sapeurs-pompiers professionnels**, dans sa version applicable à la date de rémunération concernée ;
- contrôler les bénéficiaires, l’assiette, le taux et les éventuelles règles de proratisation ;
- réunir les données individuelles nécessaires : grade, échelon, quotité de travail et éléments de rémunération.

La date de rémunération souhaitée reste à préciser. **Aucun montant ne doit être utilisé en paie sur la seule base de ce corpus.**

**Niveau de confiance : abstention sur le montant et le fondement juridique précis.**
