# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : aucune source officielle n’a été consultée ; le compagnon de recherche juridique est indisponible. Je ne peux pas valider juridiquement cette voie.**

Le corpus rattache la **présomption de démission de 2022 au droit du travail privé**. Pour votre agent titulaire territorial, il oriente plutôt la recherche vers le **licenciement pour abandon de poste, emportant radiation des cadres**. Cette distinction reste à confirmer sur les sources officielles applicables.

**Décision : non tranchable sans cette vérification.** Dans l’intervalle, ne fondez pas une sortie des effectifs sur la présomption de démission. Les semaines d’absence constituent un fait à documenter, pas une qualification juridique déjà établie.

Pour préparer le dossier, faites réunir par la DRH :

- les dates d’absence, obligations de service et tentatives de contact ;
- tout justificatif ou élément médical reçu, même tardivement ;
- l’éventuelle mise en demeure déjà adressée, son contenu, sa preuve de notification et la réponse de l’agent.

La DRH ou le service juridique devra ensuite contrôler sur les sources officielles **la caractérisation de l’abandon de poste et les exigences de mise en demeure préalable**, puis, si cette voie est confirmée, la motivation, la date d’effet, la notification et les recours.

Le risque principal est une radiation prématurée ou fondée sur une procédure inadaptée. **Niveau de confiance : abstention sur la conclusion juridique ; piste documentaire identifiée.**
