# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : aucune source officielle consultée, et le compagnon juridique est indisponible.** Le corpus fourni couvre les collectivités de plus de 350 agents : votre commune d’environ 40 agents est **hors de ce périmètre**. Je ne peux donc pas vous donner une procédure juridique prête à appliquer.

**Décision : non tranchable en l’état.** Il faut d’abord identifier le CST compétent et l’objet précis de la consultation. L’expression « mon CST » ne permet pas de présumer qu’il s’agit d’une instance propre à votre commune.

Voici le **dossier de préparation** que votre secrétariat de mairie ou votre gestionnaire RH peut constituer :

| Action préparatoire | Pièce ou contrôle attendu |
|---|---|
| Préciser le projet soumis à consultation et sa date envisagée | Projet de délibération, d’organisation ou autre document concerné |
| Établir les données de la commune | Effectif détaillé par statut et affiliation au centre de gestion |
| Faire identifier l’instance compétente, notamment auprès du CDG | Confirmation du circuit applicable et coordonnées du secrétariat concerné |
| Demander les modalités de saisine | Règlement intérieur, dossier requis, calendrier et modalités d’inscription |
| Faire contrôler les exigences juridiques avant toute décision | Caractère obligatoire et préalable de l’avis, règles de réunion et suites à donner, sur les textes officiels applicables |

Le principal risque serait de saisir la mauvaise instance ou d’adopter le projet avant une consultation requise. **Le corpus ne permet pas de confirmer ces règles pour votre commune.**

**Quel projet souhaitez-vous soumettre au CST, et votre commune est-elle affiliée au centre de gestion ?**

**Niveau de confiance : abstention sur la procédure juridique ; préparation du dossier uniquement.**
