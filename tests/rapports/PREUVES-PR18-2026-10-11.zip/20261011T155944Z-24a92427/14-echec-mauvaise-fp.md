# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Votre demande relève de la fonction publique hospitalière, hors du périmètre du corpus fourni**, qui traite uniquement de la fonction publique territoriale. L’effectif de 900 agents ne change pas cette limite.

**Mode dégradé :** le compagnon de recherche juridique est indisponible et aucune source officielle n’a été consultée. **Décision : non tranchable avec ce corpus.** Je ne peux donc pas vous donner les conditions, la durée, la rémunération ou la procédure du congé de longue maladie applicable à cet agent.

Les **8 mois d’arrêt** ne permettent pas, à eux seuls, de qualifier le congé. Pour préparer une réponse fiable, votre service chargé de la carrière doit réunir :

- les décisions de congé déjà prises, leur qualification et les périodes couvertes ;
- la date de début de l’arrêt et la date d’effet envisagée pour un éventuel CLM ;
- l’historique des congés et les éléments médicaux nécessaires, transmis dans le circuit confidentiel approprié.

Il devra ensuite consulter les **dispositions du CGFP et les textes propres à la fonction publique hospitalière**, dans leur version applicable, pour contrôler l’éligibilité au CLM, les droits restants, la rémunération et le circuit médical et décisionnel.

La recommandation est de **constituer ce dossier avant toute décision ou modification de paie**, sans transposer les règles territoriales au CHU.

**Niveau de confiance : abstention sur le régime juridique du CLM hospitalier.**
