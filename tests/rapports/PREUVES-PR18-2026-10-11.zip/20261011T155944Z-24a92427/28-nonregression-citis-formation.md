# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé : aucune source officielle n’a été consultée ; je ne peux donc pas confirmer juridiquement le circuit applicable.**

Le corpus donne la **piste documentaire suivante, à vérifier** :

- **Formation plénière** pour l’avis sur l’imputabilité au service, lorsqu’une saisine du conseil médical est requise.
- **Autorité territoriale** pour la décision finale d’imputabilité : distinguer son pouvoir de décision de l’avis médical.

La formation restreinte n’est donc pas la piste indiquée par le corpus pour cette question. Toutefois, la seule mention d’un accident « contesté » ne permet pas de confirmer que la saisine est nécessaire.

**État de décision : non tranchable en l’état.** Avant toute saisine, le service RH/juridique doit contrôler les motifs de contestation et les textes officiels applicables aux dates pertinentes, puis confirmer la formation compétente et l’autorité décisionnaire.

**Niveau de confiance : abstention sur la conclusion juridique ; orientation documentaire issue du corpus.**
