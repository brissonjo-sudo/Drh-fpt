# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable avec les informations actuelles.** Le nom et le cadre d’emplois ne permettent pas de déterminer si l’agent pourrait être nommé au grade supérieur cette année.

**Mode dégradé :** le compagnon de recherche juridique est indisponible et aucune source officielle n’a été consultée. Je peux préparer les contrôles, mais pas confirmer l’éligibilité ni une nomination.

Pour avancer, réunissez en une fois, **sans transmettre le nom de l’agent** :

- **Situation statutaire :** titulaire, stagiaire ou contractuel ; intitulé précis du cadre d’emplois, grade actuel et grade visé.
- **Carrière :** échelon, dates d’accès au grade et à l’échelon, ancienneté et état des services ; éventuel examen professionnel obtenu et sa date.
- **Contexte :** type de collectivité, effectif et date de nomination envisagée.
- **Documents locaux :** lignes directrices de gestion (LDG), délibération sur les ratios promus-promouvables et tableau d’avancement de l’année, s’il est déjà établi.

La DRH pourra ensuite préparer cette fiche de contrôle :

| Point à examiner | Pièce ou source à contrôler |
|---|---|
| Conditions statutaires d’accès au grade visé | Décret du cadre d’emplois, version applicable à la date envisagée |
| Situation individuelle au regard de ces conditions | Arrêtés de carrière, état des services, justificatif d’examen |
| Conditions locales de sélection et de nomination | LDG, ratios et tableau annuel |
| Compétence et formalités applicables | Sources officielles correspondant à l’employeur et à l’acte envisagé |

**Recommandation :** constituez ce dossier avant de proposer la nomination. Le contrôle devra distinguer l’éligibilité statutaire, l’inscription au tableau et la possibilité effective de nomination, sans déduire l’une de l’autre.

**Niveau de confiance : abstention sur l’éligibilité et la nomination.** Une vérification officielle et les pièces de carrière permettront de trancher.
