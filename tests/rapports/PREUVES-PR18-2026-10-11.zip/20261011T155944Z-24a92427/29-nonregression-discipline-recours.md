# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé : aucune source officielle n’a été consultée ; le compagnon juridique est indisponible. La réponse définitive est donc « non tranchable » sans vérification.**

Le corpus indique comme **piste à confirmer** la suppression du conseil de discipline de recours pour les sanctions nouvelles. Votre dossier concerne une exclusion de **5 jours prononcée en 2026** : la vérification doit porter sur les voies actuelles, avec une vigilance sur les anciens modèles de notification.

Pour préparer la rubrique « voies et délais de recours » :

| Voie à examiner | Contrôle avant notification |
|---|---|
| **Recours contentieux devant le tribunal administratif** | Confirmer le tribunal compétent, le délai applicable, son point de départ et les modalités de saisine. |
| **Recours administratif éventuellement ouvert** | Confirmer son destinataire, ses modalités et son effet éventuel sur le délai contentieux. |
| **Conseil de discipline de recours** | Confirmer officiellement sa suppression et l’absence de disposition transitoire applicable avant toute mention. |

**Action recommandée :** faites valider cette rubrique par le service juridique avant l’envoi. Transmettez-lui le **statut exact de l’agent** — titulaire, stagiaire ou contractuel —, la décision et les dates de prononcé et de notification envisagée. Le corpus présente une échelle disciplinaire de fonctionnaires : elle ne permet pas de présumer le régime de tout agent territorial.

Le contrôle doit aussi couvrir la motivation, les garanties de défense et l’éventuelle transmission au contrôle de légalité, sans présumer que toute sanction est obligatoirement transmissible.

Je ne fournis pas de clause prête à notifier ni de délai chiffré : ils nécessitent la vérification officielle demandée par le corpus. **Risque résiduel : une notification utilisant une voie obsolète ou des modalités erronées. Niveau de confiance : abstention sur les voies et délais juridiquement applicables.**
