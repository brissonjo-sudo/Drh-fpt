# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Mode dégradé :** le compagnon de recherche juridique est indisponible et aucune source officielle n’a été consultée. Je peux préparer les contrôles nécessaires, mais pas certifier les règles applicables aujourd’hui ni valider votre cycle.

**Décision : non tranchable en l’état.** L’ancienneté de votre organisation ne permet, à elle seule, ni de confirmer son maintien ni de conclure qu’il faut l’abandonner.

Pour une analyse au **11 octobre 2026**, voici les points à vérifier :

| Socle national à vérifier | Organisation locale à examiner |
|---|---|
| Durée annuelle de référence et éventuelles règles propres aux agents concernés | Délibération instituant l’annualisation, modifications ultérieures et règlement du temps de travail |
| Limites quotidiennes et hebdomadaires, repos et pauses | Plannings réels, périodes hautes et basses, amplitudes et récupération |
| Conditions d’une éventuelle réduction pour sujétions particulières | Travail de nuit, dominical, pénible ou dangereux effectivement réalisé et justification documentée |
| Règles de décompte des congés, absences et journée de solidarité | Méthode de calcul annuelle et paramétrage du logiciel de gestion des temps |
| Exigences de consultation et d’adoption du dispositif | Avis du CST, ou de l’instance compétente à l’époque, et actes adoptés |

Ces éléments sont des **pistes de contrôle**, pas une procédure juridiquement validée. Aucun volume horaire réglementaire n’est donné sans vérification.

**Pour avancer, réunissez en une fois :**

- Le type de collectivité, son effectif, le service concerné et les statuts des agents, notamment leurs quotités de travail.
- La délibération initiale et ses modifications, le règlement et les avis d’instance disponibles.
- Un planning représentatif et le calcul détaillé du volume annuel réellement demandé.

La date exacte de création du cycle n’est pas, seule, bloquante si les actes applicables sont disponibles. En revanche, **leur contenu, le régime des agents et le fonctionnement réel** conditionnent la réponse.

**Recommandation :** confier à la DRH, avec le responsable du service, une comparaison entre ces documents, les pratiques et les textes officiels dans leur version actuelle. Le résultat attendu est une fiche identifiant chaque écart, sa preuve et la correction envisagée.

Deux scénarios restent ouverts :

- **Compatibilité confirmée :** le maintien de l’organisation pourrait être envisagé.
- **Écarts constatés :** une adaptation du cycle ou de son cadre local serait à étudier, avec les formalités à vérifier.

Les risques à examiner sont les dépassements horaires, les repos insuffisants, les erreurs de décompte et une réduction annuelle insuffisamment justifiée.

**Niveau de confiance : abstention sur la conformité et le maintien du cycle**, jusqu’à réception des pièces et vérification officielle.
