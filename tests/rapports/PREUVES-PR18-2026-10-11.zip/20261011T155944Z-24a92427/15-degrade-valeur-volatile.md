# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé :** le skill recherche-juridique est indisponible ; aucune source officielle n’a été consultée.

**Décision : non tranchable.** Je ne peux pas fournir la valeur exacte du point d’indice au **11 octobre 2026** pour un arrêté. Le corpus impose de vérifier cette valeur avant tout chiffrage : un montant non vérifié, même accompagné d’une réserve, ne convient pas.

Avant de finaliser l’arrêté, la DRH doit contrôler sur **Légifrance** le texte de rémunération applicable à sa date d’effet, distinguer la valeur annuelle de la valeur mensuelle et conserver la source ainsi que sa version.

**Niveau de confiance : abstention sur le chiffre.**
