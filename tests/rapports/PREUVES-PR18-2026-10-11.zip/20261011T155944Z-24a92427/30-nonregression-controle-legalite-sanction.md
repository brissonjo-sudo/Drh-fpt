# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé : aucune source officielle n’a été consultée ; le compagnon juridique est indisponible.**

**Décision : non tranchable en l’état.** Je ne peux donc pas certifier une obligation de transmission pour cette exclusion de cinq jours.

Le corpus signale que l’article **L. 2131-2 du CGCT — à confirmer dans sa version applicable à la date de l’acte —** ne comporte plus de catégorie générale couvrant les « sanctions disciplinaires de toute nature ». Cette indication constitue une **piste de vérification**, pas une confirmation juridique. Le seul caractère disciplinaire de l’acte ne suffit donc pas, dans ce dossier documentaire, à établir une transmission obligatoire.

Pour trancher, le service juridique doit :

- consulter la version officielle applicable à la **date de la sanction** ;
- rechercher si une autre catégorie de l’article couvre précisément cet acte ;
- distinguer l’obligation légale d’une éventuelle demande du préfet ou des modalités locales de télétransmission.

**Ne présentez pas la transmission comme obligatoire sur la seule base de l’ancienne catégorie générale. Niveau de confiance : abstention sur l’obligation légale, dans l’attente de cette vérification.**
