# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Le corpus donne deux **pistes à vérifier avant d’agir** :

- **Formation plénière** : c’est la formation indiquée pour l’avis sur l’imputabilité au service lorsqu’une saisine du conseil médical est requise, plutôt que la formation restreinte.
- **Autorité territoriale** : c’est l’acteur indiqué pour prendre la décision finale d’imputabilité. L’avis médical et la décision administrative sont distincts.

**Décision : non tranchable en l’état.** Ces indications ne sont pas juridiquement confirmées pour votre dossier ; la contestation ne suffit pas, à elle seule, à établir que la saisine est obligatoire.

Pour trancher, la **DRH** doit réunir la déclaration d’accident, le certificat médical, les circonstances, les dates utiles et les motifs de contestation, puis contrôler le CGFP et les textes territoriaux applicables au CITIS : nécessité de saisine, formation compétente et pouvoir de décision. Le régime des contractuels ne doit pas être transposé à ce fonctionnaire.

**Niveau de confiance : abstention sur la conclusion juridique définitive.**
