# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable.** Avec seulement le nom et le cadre d’emplois, je ne peux pas confirmer une nomination au grade supérieur cette année. Cela ne signifie pas que l’avancement est exclu : il manque les données permettant d’examiner la situation.

Le nom n’est pas nécessaire pour cette analyse : vous pouvez anonymiser le dossier.

Pour avancer, réunissez en une fois :

- **L’employeur** : type de collectivité et effectif, pour confirmer le périmètre du corpus.
- **La situation de l’agent** : titulaire, stagiaire ou contractuel ; grade exact actuel, échelon et date d’accès à cet échelon.
- **Le parcours** : ancienneté dans le grade, état des services et éventuel examen professionnel obtenu.
- **L’objectif** : grade exact visé et date de nomination envisagée en 2026.
- **Les pièces locales** : LDG applicables, délibération fixant les ratios promus-promouvables, éléments de préparation du tableau annuel et situation de l’emploi destiné à accueillir la nomination.

Ces informations sont **bloquantes** pour conclure. Le nom, lui, sert seulement à identifier le dossier en interne.

La DRH pourra ensuite préparer cette fiche de contrôle, sans arrêter encore de décision :

| Point à examiner | Pièce ou contrôle attendu |
|---|---|
| Nature de l’évolution | Vérifier qu’il s’agit d’un avancement de grade dans le même cadre d’emplois, et non d’une promotion interne |
| Conditions individuelles | Confronter grade, échelon, services et examen éventuel au statut particulier applicable à la date envisagée |
| Cadre local | Examiner les LDG et le ratio applicable ; faire vérifier la compétence de l’assemblée pour sa fixation |
| Tableau et nomination | Distinguer conditions statutaires remplies, inscription au tableau et décision de nomination ; contrôler l’emploi disponible et la compétence de l’autorité territoriale |
| Rôle des instances | Vérifier le rôle actuel de la CAP, notamment l’absence de consultation préalable sur l’avancement indiquée par le corpus, sans le confondre avec ses autres compétences |

**Recommandation :** constituer maintenant le dossier avec le gestionnaire carrière, puis faire contrôler les textes officiels et les pièces locales par le service juridique ou l’interlocuteur compétent du CDG, selon votre organisation. Conserver les sources applicables et le résultat de chaque contrôle avant de finaliser le tableau ou une nomination.

Le risque principal serait de confondre une possibilité statutaire avec une nomination acquise. **Niveau de confiance : abstention sur l’éligibilité et la nomination individuelles**, faute de données et de vérification officielle.
