# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je m’appuie uniquement sur le corpus fourni. Les règles ci-dessous constituent des **contrôles à faire vérifier**, pas une procédure juridiquement validée.

**Décision juridique : non tranchable en l’état.** Le statut de titulaire et la sanction envisagée sont connus, mais ils ne suffisent pas à confirmer que vous pouvez engager la procédure. Il manque notamment la qualification de l’employeur, les faits documentés, les dates déterminantes et la vérification des textes applicables.

**Ma recommandation : lancer la préparation du dossier et son contrôle juridique, sans décider maintenant d’une exclusion de 5 jours.** La durée envisagée doit rester une hypothèse : les faits sont encore soupçonnés, et leur matérialité, leur caractère fautif et la proportionnalité d’une éventuelle sanction restent à examiner.

Les points juridiques décisifs à vérifier sont les suivants :

- **Régime applicable et instance préalable.** Le corpus oriente une exclusion de cette durée vers le deuxième groupe et vers un avis préalable du conseil de discipline, formation de la CAP. Cette qualification et cette exigence doivent être confirmées dans les textes applicables au titulaire concerné.
- **Autorité compétente.** Faire confirmer le pouvoir de l’autorité territoriale et les éventuelles délégations. Distinguer l’autorité qui décide de l’instance qui rend un avis.
- **Possibilité de poursuivre.** Contrôler la prescription à partir de la date de connaissance effective des faits par l’administration, ainsi que l’incidence d’éventuelles poursuites pénales. Aucune durée de prescription n’est certifiée ici.
- **Garanties de défense.** Vérifier l’information de l’agent, l’accès au dossier intégral, l’assistance d’un conseil de son choix, un temps suffisant pour préparer sa défense et l’information sur le droit de se taire avant le recueil d’observations.
- **Décision proportionnée.** Examiner les preuves, les explications de l’agent, les circonstances et les éléments à décharge avant de retenir une sanction.

Pour avancer concrètement, voici **l’ordre de préparation recommandé**. Les étapes formelles restent subordonnées à la validation juridique.

| Ordre | Action à lancer | Responsable proposé | Contrôle et preuve attendue |
|---|---|---|---|
| **1** | Compléter une fiche de cadrage : employeur, effectif, statut particulier éventuel, cadre d’emplois et grade, affiliation au CDG, dates envisagées d’ouverture et de décision. | DRH | Situation statutaire documentée ; circuit d’instance identifié sans présumer l’affiliation. |
| **2** | Établir une chronologie des faits et réunir les pièces existantes : rapports, documents, témoignages, éléments favorables et défavorables à l’agent. Relever séparément la date de connaissance effective et l’existence d’une procédure pénale. | DRH et encadrement | Chaque fait relié à une pièce ; distinction entre constat, témoignage et soupçon ; accès limité au dossier. |
| **3** | Faire vérifier les textes officiels aux dates utiles : champ d’application, prescription, échelle des sanctions, compétence, conseil de discipline, garanties et éventuelles dispositions transitoires. | Juriste RH ; appui du CDG selon le circuit confirmé | Note de validation avec sources officielles, versions applicables et conclusion explicite sur la possibilité d’ouvrir la procédure. |
| **4** | Préparer les documents d’ouverture et les modalités de défense, puis les faire valider avant tout envoi ou audition disciplinaire. | DRH et juriste | Dossier complet et inventorié ; information sur les droits ; modalités d’accès et d’assistance ; calendrier permettant la défense. |
| **5** | Après validation et mise en œuvre des garanties, organiser le contradictoire et préparer la saisine de l’instance si son avis préalable est confirmé comme requis. | DRH, autorité compétente et secrétariat identifié | Observations de l’agent intégrées ; convocations et composition contrôlées ; preuve de l’avis recueilli avant décision. |
| **6** | Réexaminer l’opportunité de sanctionner et sa proportionnalité, puis préparer la décision et sa mise en œuvre. | Autorité compétente, avec DRH et juriste | Motivation en fait et en droit, date d’effet, notification, recours, transmission éventuelle et conséquences de paie validés avant signature. |

À l’issue de l’instruction, les options à examiner sont **l’absence de sanction si les faits ne sont pas suffisamment établis**, ou une sanction adaptée aux faits établis et aux garanties respectées. L’exclusion de 5 jours ne doit pas devenir le résultat fixé d’avance.

Avant signature, faire contrôler spécialement :

- les **recours actuels**, en distinguant le conseil de discipline préalable de l’ancienne instance de recours que le corpus indique supprimée, point à confirmer ;
- la **transmission au contrôle de légalité**, à partir de la liste légale applicable, puis séparément de la convention locale et des éventuelles demandes préfectorales ;
- la notification traçable, la date d’effet et le paramétrage de paie.

Les risques principaux sont une sanction fondée sur des faits insuffisamment établis, une prescription mal appréciée, une garantie de défense omise ou une sanction disproportionnée. **Niveau de confiance : abstention sur la possibilité juridique d’engager la procédure ; dossier de préparation exploitable pour obtenir la validation nécessaire.**
