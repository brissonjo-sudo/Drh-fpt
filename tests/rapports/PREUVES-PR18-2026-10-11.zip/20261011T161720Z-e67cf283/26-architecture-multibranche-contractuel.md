# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Les éléments ci-dessous constituent un dossier de préparation, sans validation juridique définitive.

**Décision : non tranchable en l’état.** Il faut distinguer deux demandes : la prise en compte de l’ancienneté dans la rémunération et l’accès à une carrière statutaire.

La piste donnée par le corpus est la suivante, **à confirmer sur les textes applicables** : un CDI et une rémunération par référence à un indice ne confèrent pas un grade de fonctionnaire. Le régime contractuel décrit repose sur des décisions de rémunération et de réévaluation, sans avancement automatique comparable à celui d’un titulaire. La demande ne peut donc pas être traitée d’emblée comme un avancement de grade.

Cela ne signifie pas que l’ancienneté doit être ignorée. Il faut examiner si les services antérieurs, l’expérience, les fonctions exercées et les clauses du contrat peuvent justifier un réexamen de la rémunération. **Une reprise intégrale d’ancienneté, une réévaluation et une augmentation sont trois questions différentes**, à contrôler séparément.

Les données connues sont le CDI et la référence indiciaire. Pour poursuivre, la DRH doit réunir :

- la confirmation d’un contrat de droit public territorial, le type d’employeur et son effectif ;
- le contrat, ses avenants, son fondement de recrutement et ses clauses sur la rémunération ou l’ancienneté ;
- l’historique des services, les fonctions et catégories correspondantes, ainsi que les dernières réévaluations ;
- le cadre local de rémunération et la date d’effet souhaitée.

La marche à suivre est de **préparer un réexamen individualisé de la rémunération**, selon cet ordre :

1. **Gestionnaire RH — qualifier la demande.** Préciser avec l’agent s’il demande une augmentation, l’application d’une clause contractuelle ou l’accès au statut de fonctionnaire. Constituer une chronologie documentée des services et rémunérations.
2. **DRH ou service juridique — vérifier le régime applicable.** Consulter le CGFP et les dispositions encore applicables du décret relatif aux contractuels territoriaux, en tenant compte des recodifications. Contrôler les règles de fixation et de réévaluation de la rémunération, leur périodicité, le rôle de l’ancienneté et la portée des clauses contractuelles.
3. **DRH — préparer l’arbitrage.** Séparer ce qui relève du socle national, du contrat et du choix local. Examiner une éventuelle revalorisation, sans importer automatiquement les règles de classement et d’avancement des titulaires. Si l’objectif est une carrière de fonctionnaire, étudier séparément les voies de recrutement statutaire et leurs conditions.
4. **Autorité compétente, à confirmer — formaliser la réponse.** Après vérification, déterminer l’acte ou l’avenant nécessaire et contrôler sa motivation, sa date d’effet, sa notification et les recours éventuellement applicables.

Avant toute modification de paie, vérifier les paramètres indiciaires et budgétaires. Les risques principaux sont de promettre une reprise intégrale sans fondement, d’assimiler l’indice à un grade ou d’omettre un réexamen de rémunération éventuellement dû.

**Niveau de confiance : abstention sur les droits individuels ; pistes documentaires à vérifier.**
