# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Non tranchable avec ce corpus.** Votre CHU relève de la **fonction publique hospitalière**, alors que le corpus fourni couvre uniquement la fonction publique territoriale. L’effectif de 900 agents ne change pas cette limite : appliquer ses règles à votre agent serait inadapté.

**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je ne peux donc pas préciser les conditions, la durée ou la rémunération du congé de longue maladie hospitalier.

Les informations fournies — titulaire, arrêt depuis huit mois — ne permettent pas de déterminer le congé applicable. Pour préparer l’examen du dossier, réunissez :

- la décision précisant le **congé actuellement accordé**, ses dates et les congés antérieurs utiles ;
- l’existence éventuelle d’une demande de congé de longue maladie et des avis médicaux déjà rendus, sans communiquer ici de diagnostic ;
- la date d’effet envisagée.

La prochaine action est de faire contrôler, par votre service statutaire ou juridique hospitalier, les dispositions du **CGFP et les textes propres à la fonction publique hospitalière**, dans leur version applicable : éligibilité, durée, rémunération, autorité décisionnaire et circuit médical.

**Point de vigilance :** aucune modification du congé ou de la paie ne peut être sécurisée sur ce seul corpus.

**Niveau de confiance : abstention sur le régime demandé, faute de base hospitalière et de vérification officielle.**
