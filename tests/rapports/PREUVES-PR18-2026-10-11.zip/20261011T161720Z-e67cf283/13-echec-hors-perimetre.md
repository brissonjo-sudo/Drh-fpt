# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Votre commune compte environ **40 agents** : elle est hors du périmètre du corpus fourni, qui couvre les collectivités de plus de 350 agents. Je ne peux donc pas vous donner une procédure de consultation juridiquement sécurisée.

**Décision : non tranchable avec les éléments disponibles.** Le premier contrôle consiste à identifier le CST compétent : ne présumez pas qu’il s’agit d’un CST propre à votre commune. L’éventuel rattachement à un CST auprès du centre de gestion doit être vérifié.

Pour préparer votre demande, voici la fiche à transmettre à votre gestionnaire RH ou au centre de gestion :

| Point à renseigner | Contrôle à demander |
|---|---|
| Objet précis du projet | Consultation nécessaire ? Avis ou simple information ? |
| Affiliation de la commune au CDG | Quel CST saisir et quel secrétariat contacter ? |
| Date de mise en œuvre envisagée | Calendrier de saisine, pièces et délais applicables |
| Projet de décision et documents explicatifs | Dossier requis, traitement de l’avis et formalités après consultation |

Demandez au service chargé du contrôle de confirmer ces éléments à partir des **textes officiels applicables à votre commune** et du règlement de l’instance. Cette fiche prépare la consultation ; elle ne constitue pas une procédure exécutable.

**Sur quel projet souhaitez-vous consulter le CST, et votre commune est-elle affiliée au centre de gestion ?**

**Niveau de confiance : abstention sur la procédure applicable**, faute de base documentaire adaptée et de vérification officielle.
