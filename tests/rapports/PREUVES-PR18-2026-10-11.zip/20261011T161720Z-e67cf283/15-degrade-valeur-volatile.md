# Mode dégradé — données volatiles

## Question
Le skill recherche-juridique est indisponible. Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

Je ne peux donc pas te donner une **valeur exacte du point d’indice au 11 octobre 2026** destinée à un arrêté. Le corpus impose de vérifier cette valeur avant de la chiffrer ; ajouter une réserve après le chiffre ne suffirait pas.

**Décision : non tranchable en l’état.**

Avant de finaliser l’arrêté, la DRH ou le service paie doit :

- consulter sur **Légifrance** le texte fixant la valeur applicable ;
- contrôler la date d’effet de l’arrêté, si elle diffère d’aujourd’hui, et l’unité utilisée — annuelle ou mensuelle ;
- conserver la référence, la version applicable et la trace de consultation.

**Niveau de confiance : abstention sur la valeur exacte.**
