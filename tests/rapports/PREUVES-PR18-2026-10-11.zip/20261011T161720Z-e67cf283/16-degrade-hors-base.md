# Mode dégradé — sujet spécialisé

## Question
Le skill recherche-juridique est indisponible. Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** Je ne peux fournir ni montant exact, ni taux, ni référence réglementaire certaine de l’indemnité de feu. Le corpus signale le régime spécifique des sapeurs-pompiers professionnels, mais ne contient pas le texte qui fixe cette indemnité. Lui appliquer le régime indemnitaire territorial général serait donc insuffisamment sécurisé.

Pour préparer la vérification, il faut réunir :

- **La date de référence** : montant actuel ou date d’effet différente.
- **Les données de chaque agent** : grade exact, situation indiciaire, quotité et éléments de rémunération.
- **Les pièces locales** : délibération indemnitaire applicable et paramétrage de paie.

**Contrôle à confier à la DRH ou au service paie :** rechercher sur Légifrance le texte propre au régime indemnitaire des sapeurs-pompiers professionnels, dans sa version applicable, puis relever l’article relatif à l’indemnité de feu, ses bénéficiaires, son taux, son assiette et ses modalités de versement. Confronter ensuite ces règles aux pièces locales et aux données individuelles.

Le résultat attendu est une **référence officielle traçable et un montant individuel contrôlé avant utilisation en paie**.

**Niveau de confiance : abstention sur le montant et le fondement juridique exact.**
