# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** Je ne peux donc pas certifier une obligation de transmission.

Le corpus indique que **la catégorie des sanctions disciplinaires soumises à l’avis du conseil de discipline figurait dans une ancienne version**, mais ne figure plus dans la version actuelle qu’il décrit. Cette indication reste une **piste à vérifier**, pas une conclusion juridique validée. La consultation du conseil de discipline et la transmission au contrôle de légalité sont deux contrôles distincts.

Pour trancher, le service juridique doit vérifier :

- l’**article L. 2131-2 du CGCT dans sa version applicable à la date de la sanction** — référence à confirmer en version consolidée ;
- séparément, la convention locale de télétransmission et une éventuelle demande du préfet, sans les confondre avec une obligation légale fondée sur cet article.

**Niveau de confiance : abstention sur l’obligation de transmission.**
