# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable sans cette vérification.** Le corpus indique que le **conseil de discipline de recours a été supprimé** et ne doit plus être présenté comme une voie de recours pour une sanction nouvelle. Cette indication reste **à confirmer sur les sources officielles**, notamment pour écarter un éventuel régime transitoire. La seule date de sanction, en 2026, ne renseigne pas la date d’ouverture de la procédure.

Il faut distinguer le **conseil de discipline consulté avant certaines sanctions** du **conseil de discipline de recours** : leur rôle est différent.

Pour préparer la notification, faites contrôler par le service juridique :

- **Le recours administratif ouvert**, notamment la possibilité d’un recours gracieux auprès de l’autorité ayant prononcé la sanction, ainsi que son délai et ses effets sur le délai contentieux.
- **Le recours contentieux devant le tribunal administratif compétent** : juridiction, modalités de saisine et délai applicable.
- **L’absence de recours devant l’ancien conseil de discipline de recours**, après vérification de sa suppression et des dispositions transitoires.

Les éléments à réunir sont le **statut de l’agent** — titulaire, stagiaire ou contractuel —, la date d’ouverture de la procédure, la décision de sanction et la date prévue de notification. L’échelle et le circuit disciplinaires doivent être contrôlés dans le régime propre à cet agent.

**Recommandation :** faire valider ces mentions avant l’envoi. Je ne fournis pas de clause de recours prête à notifier ni de délai chiffré sans vérification.

**Niveau de confiance : abstention sur les voies et délais applicables ; pistes documentaires issues du corpus.**
