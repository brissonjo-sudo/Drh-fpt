# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Décision : non tranchable en l’état.** Le corpus permet de préparer le dossier, mais pas de confirmer la possibilité de nomination ni de rédiger un arrêté juridiquement engageant. Les champs à compléter permettent d’avancer ; ils ne remplacent pas la vérification des textes.

**Les éléments nécessaires pour trancher**

La demande de nomination par avancement de grade est connue. En revanche, aucun élément individuel ou local n’est fourni.

À réunir par la DRH :

- **Employeur et agent** : collectivité, effectif, éventuel statut particulier ; statut de l’agent, cadre d’emplois, grades actuel et visé, échelon, ancienneté et services. Vérifier que l’opération relève bien de l’avancement de grade, et non d’un changement de cadre d’emplois.
- **Conditions statutaires** : texte propre au cadre d’emplois, conditions d’accès au grade visé et éventuel examen professionnel, à contrôler à la date d’effet souhaitée.
- **Cadre local** : tableau annuel d’avancement applicable, délibération relative au ratio promus-promouvables, LDG et éléments d’appréciation de la valeur professionnelle. Contrôler séparément l’éligibilité et la possibilité effective de nomination.
- **Emploi et décision** : emploi correspondant au grade visé, situation de cet emploi, crédits, autorité compétente et éventuelle délégation de signature. Vérifier le rôle actuel des instances, notamment celui de la CAP, sans présumer une consultation préalable.
- **Dates** : année du tableau, date envisagée de signature et date d’effet. Leur cohérence reste à contrôler.

Le **socle national** doit être recherché dans le CGFP et le statut particulier applicable. Les **choix locaux** doivent être établis à partir des actes de la collectivité : aucune délibération, aucun ratio ni aucune LDG ne peuvent être supposés.

**Projet correspondant — trame préparatoire non signable**

Les mentions ci-dessous constituent le dossier de rédaction de l’arrêté. Le dispositif définitif reste suspendu aux contrôles précédents.

---

**[COLLECTIVITÉ / ÉTABLISSEMENT]**  
**Projet d’arrêté n° [à compléter]**  
**Objet : nomination envisagée de [identité de l’agent] au grade de [grade visé], par avancement de grade**

**Autorité et signature envisagées**  
[Qualité de l’autorité] — [identité du signataire]  
[Délégation éventuelle : référence et portée à contrôler]

**Visas à renseigner après vérification**

- [Dispositions du CGFP applicables à l’opération, dans leur version pertinente]
- [Statut particulier du cadre d’emplois et dispositions relatives au grade visé]
- [Délibération relative au ratio applicable]
- [LDG pertinentes]
- [Tableau annuel d’avancement : année, date, référence et inscription de l’agent]
- [Acte relatif à l’emploi, si pertinent]
- [Dernier arrêté établissant la situation statutaire de l’agent]

**Éléments justifiant la nomination envisagée**

Agent : [identité strictement nécessaire]  
Situation actuelle : [statut, cadre d’emplois, grade, échelon, ancienneté]  
Conditions d’accès : [pièces établissant leur satisfaction, à valider]  
Situation au tableau : [inscription et référence à contrôler]  
Possibilité locale de nomination : [contrôle du ratio, de l’emploi et des crédits]  
Éléments d’appréciation : [éléments objectifs pertinents]

**Contenu du dispositif à arrêter après validation**

| Rubrique | Données à intégrer au texte définitif |
|---|---|
| Nomination | [Agent], [grade visé], [cadre d’emplois], [emploi concerné] |
| Date d’effet | [Date juridiquement contrôlée] |
| Classement | [Échelon et ancienneté conservée, établis selon les règles vérifiées] |
| Rémunération | [Données validées par la paie et actes locaux pertinents, sans montant présumé] |
| Exécution | [Services chargés de l’application, à identifier] |
| Formalités | [Notification, publicité et éventuelle transmission, selon le régime vérifié] |
| Recours | [Mention adaptée après contrôle des voies et délais applicables] |

Fait à [lieu], le [date]  
[Signature à apposer uniquement après validation]

---

**Suite recommandée**

1. **DRH** : réunir les pièces individuelles et locales ; produire une fiche de contrôle des conditions de nomination.
2. **Service juridique ou interlocuteur compétent** : vérifier les sources officielles à la date d’effet, les compétences et les formalités ; conserver la trace des vérifications.
3. **Carrière et paie** : établir le classement et ses conséquences financières, puis compléter le dispositif avant présentation à la signature.

Les risques à lever sont une qualification erronée de l’opération, une condition statutaire non remplie, un cadre local insuffisant, une date d’effet irrégulière ou un classement incorrect. Limiter les données personnelles aux informations nécessaires.

**Niveau de confiance : abstention sur la possibilité juridique de nomination et sur l’arrêté définitif.** La trame permet de préparer le dossier ; elle ne permet pas encore la signature ni la mise en paie.
