# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.** Je peux préparer le contrôle de votre organisation, mais pas certifier les règles applicables aujourd’hui ni autoriser son maintien.

**Décision : non tranchable en l’état.** L’ancienneté du cycle annualisé ne permet, à elle seule, ni de conclure qu’il faut le supprimer, ni de garantir que vous pouvez le conserver.

Pour trancher, il faut distinguer deux niveaux :

| Socle national à vérifier | Organisation locale à examiner |
|---|---|
| Durée annuelle de référence et adaptations autorisées selon les agents et les sujétions | Volume annuel effectivement prévu et justification des éventuelles réductions |
| Durées maximales de travail, moyenne hebdomadaire, pauses et repos | Enchaînement réel des journées, semaines hautes et périodes basses |
| Réforme des anciens régimes dérogatoires et dispositions actuellement applicables | Délibération fondatrice, modifications et éventuelle mise en conformité |
| Règles de congés et traitement des différentes absences | Méthode de décompte dans les plannings et le logiciel de gestion des temps |

Les textes nationaux et le choix local doivent être contrôlés séparément : **l’existence d’une ancienne délibération ne suffit pas à établir la conformité actuelle du cycle.**

**Les pièces déterminantes à réunir en une fois :**

- Type d’employeur, effectif et populations concernées : titulaires, contractuels, emplois à temps non complet, agents à temps partiel, éventuel régime particulier.
- Délibération sur le temps de travail, annexes, modifications et avis de l’instance consultée lors de leur adoption.
- Plannings représentatifs d’une année, volume annuel attendu, règles de congés, RTT et journée de solidarité, modalités de décompte des absences.
- Justification des éventuelles sujétions : nuits, dimanches, horaires décalés, pénibilité ou danger.
- Date envisagée pour maintenir ou modifier l’organisation.

**Deux pistes de décision, sous réserve de vérification :**

- **Conserver le cycle** : à examiner si son fondement local, son volume annuel et les plannings réels respectent les règles nationales applicables.
- **Adapter le cycle** : à examiner si le dossier révèle un ancien avantage dérogatoire sans fondement actuel, des garanties de repos insuffisantes ou une annualisation mal décomptée. Il faudra alors déterminer si une correction ciblée suffit ou si une nouvelle organisation est nécessaire.

**Premières actions utiles :**

1. **RH et responsable du service** : constituer le dossier ci-dessus et comparer le cycle prévu aux horaires réellement effectués.
2. **Service juridique/RH** : consulter les sources officielles dans leur version applicable au **11 octobre 2026**, puis à la date d’effet retenue : textes territoriaux sur le temps de travail, garanties minimales auxquelles ils renvoient et réforme des anciens régimes dérogatoires.
3. **Avant tout arbitrage** : faire vérifier les rôles respectifs du CST, de l’assemblée délibérante et de l’autorité territoriale, ainsi que les consultations et formalités nécessaires au maintien ou à la modification.

Les principaux risques à examiner sont un décompte annuel erroné, des repos insuffisants et un fondement local devenu inadapté. **Niveau de confiance : abstention sur la conformité de votre cycle ; dossier de contrôle exploitable pour préparer la décision.**
