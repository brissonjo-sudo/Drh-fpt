# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Mode dégradé : la vérification officielle est indisponible pour cette réponse ; aucune source officielle n’a été consultée.**

**Ne considérez pas la présomption de démission de 2022 comme une base validée pour votre agent.** Le corpus oriente vers une autre piste : **l’abandon de poste en FPT**, à distinguer de la présomption de démission du secteur privé. Cette distinction reste à confirmer sur les textes officiels avant toute décision.

**État de décision : non tranchable en l’état.** Plusieurs semaines d’absence ne permettent pas, à elles seules, de tenir la qualification d’abandon de poste pour acquise.

Pour préparer le contrôle par la **DRH ou le service juridique**, réunissez :

- le type d’employeur, les dates exactes d’absence et les obligations de service ;
- les démarches de contact, les réponses éventuelles et tout élément pouvant justifier l’absence ;
- l’éventuelle mise en demeure, son contenu et la preuve de sa notification.

Le contrôle devra porter sur la justification de l’absence et, selon la piste du corpus, sur les garanties de la mise en demeure : reprise demandée dans un délai approprié et avertissement explicite sur le risque de radiation sans procédure disciplinaire préalable. Il faudra également vérifier la **distinction entre licenciement pour abandon de poste et sanction disciplinaire**, puis la motivation, la date d’effet, la notification, les recours et la transmission éventuelle de la décision.

**Recommandation : faites contrôler cette piste avant de rédiger une décision de sortie.** Le risque principal est une qualification ou une mise en demeure irrégulière.

**Niveau de confiance : abstention sur la conclusion juridique ; dossier de préparation uniquement.**
