# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non, pour un fonctionnaire titulaire territorial.** La présomption de démission concerne les salariés de droit privé, y compris ceux employés par une personne publique. Elle ne s’applique pas à votre agent titulaire.

**Décision : impossible en l’état par cette voie.** La voie à examiner est le **licenciement pour abandon de poste, emportant radiation des cadres**, prévu par l’article L. 553-1 du CGFP. Ce n’est pas une sanction disciplinaire.

**Plusieurs semaines d’absence ne suffisent pas, à elles seules, à sécuriser une radiation.** Le Conseil d’État exige préalablement une mise en demeure :

- **écrite et notifiée** à l’agent ;
- fixant un délai pour rejoindre son poste ou reprendre son service ;
- l’avertissant explicitement du **risque de radiation des cadres sans procédure disciplinaire préalable**.

L’arrêt fourni annule précisément une radiation parce que cet avertissement manquait.

Pour avancer :

1. **RH : réunir les pièces** — dates d’absence, planning, justificatifs éventuellement reçus, échanges et démarches de contact.
2. **Autorité territoriale avec RH : préparer la mise en demeure**, avec une échéance adaptée et une preuve de notification.
3. **À l’échéance : examiner la reprise, la réponse et les éventuels justificatifs**, avant d’envisager une décision.

La radiation individuelle reste **non tranchable** sans ces pièces et contrôles. Avant signature, faire vérifier notamment la compétence du signataire, la motivation, la date d’effet, la notification et les recours.

Sources : [champ du Code du travail](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006900781), [présomption de démission](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104), [CGFP, art. L. 553-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184), versions applicables au 11 octobre 2026 ; [CE, Section, 11 décembre 1998, nos 147511 et 147512, Recueil Lebon](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335).

**Confiance : étayée par les extraits officiels et les consultations archivées fournis ; aucune consultation supplémentaire effectuée.**
