# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Le taux prévu est de 25 % du traitement soumis à retenue pour pension. Le montant exact en euros est non tranchable sans connaître cette assiette pour chaque agent.**

Le fondement spécifique est le **décret n° 90-850 du 25 septembre 1990**, portant dispositions communes aux sapeurs-pompiers professionnels : [disposition relative à l’indemnité de feu](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025), version applicable depuis le 26 juillet 2020, selon la consultation officielle archivée fournie du 11 octobre 2026.

Le calcul correspondant est :

**Indemnité de feu = traitement soumis à retenue pour pension × 25 %.**

L’assiette indiquée par le texte est donc ce traitement, et non la rémunération totale comprenant toutes les primes.

**Quelle est l’assiette mensuelle brute soumise à retenue pour pension de chaque agent, et pour quel mois souhaitez-vous le calcul ?** Une donnée anonymisée suffit.

Avant mise en paie, le service paie devra confirmer l’assiette et les conditions d’attribution : l’extrait renvoie à un texte dont le contenu n’est pas fourni, ainsi qu’aux pièces locales applicables. Le dossier établit le taux, mais ne permet pas de certifier chaque droit individuel.

**Confiance : taux étayé par la source officielle fournie ; abstention sur le montant individuel en l’état.**
