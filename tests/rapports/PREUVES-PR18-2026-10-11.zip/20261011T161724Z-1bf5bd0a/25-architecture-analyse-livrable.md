# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Le corpus permet de préciser le cadre général de l’avancement de grade, mais pas de confirmer l’éligibilité de l’agent ni de préparer un arrêté signable. Je fournis donc une **trame d’arrêté à compléter**, réservée au scénario où l’agent est confirmé comme fonctionnaire territorial titulaire.

L’analyse repose uniquement sur les **extraits officiels et les traces de consultation fournis**, applicables au **11 octobre 2026**. Aucune consultation nouvelle n’a été effectuée.

**Ce qui permettrait la nomination**

Les dispositions officielles fournies établissent les points suivants :

| Point | Règle établie par le corpus |
|---|---|
| Modalité d’avancement | L’avancement peut notamment intervenir au choix ou après examen professionnel, par inscription à un tableau annuel. Au choix, l’autorité tient compte des LDG et conserve son pouvoir d’appréciation. |
| Décision individuelle | L’autorité territoriale prononce l’avancement parmi les agents inscrits au tableau, en respectant son ordre. |
| Nombre de promotions | Le taux de promotion est fixé par l’assemblée délibérante après avis du CST. Le texte fourni exclut expressément le cadre d’emplois des agents de police municipale de cette règle générale. |
| Emploi assigné | L’avancement est subordonné à l’acceptation par l’agent de l’emploi assigné dans son nouveau grade. |

**Sources — fonction juridique : conditions et compétence en matière d’avancement.** CGFP, versions en vigueur depuis le 01/03/2022, consultations archivées du 11/10/2026 : [modalités d’avancement — LEGIARTI000044425506](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), [taux de promotion — LEGIARTI000044425500](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), [autorité et ordre du tableau — LEGIARTI000044425498](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), [acceptation de l’emploi — LEGIARTI000044425496](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496).

**J’en déduis que l’inscription au tableau ne suffit pas, à elle seule, à établir que la nomination envisagée est possible.** Il faut encore contrôler les conditions propres au grade, les pièces locales et la situation individuelle.

**Informations à compléter avant de trancher**

- **Employeur et agent :** type de collectivité, effectif, statut de l’agent, cadre d’emplois, grades actuel et cible, échelon, ancienneté et services retenus. Un statut particulier ou un autre régime impose de revoir la trame.
- **Conditions et pièces locales :** décret statutaire applicable, éventuel examen professionnel, tableau annuel et rang de l’agent, LDG, taux de promotion et avis du CST lorsqu’ils sont applicables, situation de l’emploi d’accueil et acceptation de cet emploi.
- **Calendrier et signature :** date d’effet souhaitée, date de signature, compétence du signataire et éventuelle délégation.

Ces éléments sont **bloquants pour la décision définitive**. Le nom de l’agent et les références administratives peuvent rester en champs sans empêcher cette préparation.

La **DRH** doit réunir ces pièces, puis faire contrôler le texte statutaire et ses éventuels renvois dans leur version applicable à la date d’effet. Elle doit aussi vérifier le rôle actuel de la CAP : le module interne indique que sa consultation préalable sur l’avancement a été retirée, mais aucune trace officielle fournie ne permet ici de certifier ce point.

Le **service carrière-paie** doit ensuite établir le classement et ses conséquences financières à partir des textes vérifiés. Aucun échelon, indice ou montant ne peut être déduit des seules données présentes.

---

**Projet préparatoire d’arrêté — à compléter et à valider avant signature**

**[Collectivité / établissement]**  
**Arrêté n° [référence]**  
**Portant avancement au grade de [grade cible] de [prénom NOM]**

*Cette trame concerne uniquement le scénario d’un fonctionnaire territorial titulaire. Les mentions entre crochets sont des champs ou des contrôles à résoudre.*

**[L’autorité territoriale compétente],**

Vu le Code général de la fonction publique, notamment les dispositions relatives à l’avancement de grade des fonctionnaires territoriaux **[articles à identifier et version applicable à confirmer pour l’acte]** ;

Vu **[le décret statutaire du cadre d’emplois : référence, articles et version applicable à vérifier]** ;

Vu **[les textes de classement et de rémunération applicables : références à vérifier]** ;

Vu **[les lignes directrices de gestion applicables : auteur, date et référence]** ;

Vu **[si applicable, la délibération fixant le taux de promotion, sa date et sa référence, ainsi que l’avis préalable du CST]** ;

Vu le tableau annuel d’avancement au grade de **[grade cible]** pour l’année **[année]**, établi le **[date]**, sur lequel **[prénom NOM]** figure au rang **[rang]** ;

Vu **[les pièces relatives à l’emploi d’accueil et les actes locaux nécessaires, après contrôle]** ;

Vu **[l’acte fixant la situation administrative actuelle de l’agent]** ;

Vu **[le cas échéant, la délégation permettant au signataire de prendre le présent arrêté]** ;

Considérant **[les éléments précis établissant que l’agent remplit les conditions statutaires, après vérification]** ;

Considérant **[les éléments établissant le respect du tableau, des LDG et, lorsqu’il s’applique, du nombre maximal de promotions]** ;

Considérant l’acceptation par l’agent de l’emploi de **[emploi assigné]**, constatée par **[pièce et date]** ;

**ARRÊTE**

**Article 1 — Avancement de grade**

À compter du **[date d’effet juridiquement contrôlée]**, **[prénom NOM]**, fonctionnaire territorial titulaire du grade de **[grade actuel]**, bénéficie d’un avancement au grade de **[grade cible]**, au sein du cadre d’emplois de **[cadre d’emplois]**.

**Article 2 — Classement**

L’agent est classé au **[échelon]**, avec **[ancienneté conservée]**, conformément à **[dispositions de classement vérifiées]**.

Les indices applicables sont : **[indice brut]** et **[indice majoré]**.

**Article 3 — Emploi assigné**

L’agent exerce les fonctions de **[intitulé]** sur l’emploi de **[désignation et référence]**, selon **[durée de l’emploi et quotité applicables]**.

**Article 4 — Notification et formalités**

Le présent arrêté est notifié à l’agent.

**[Compléter, après vérification selon l’employeur et la nature de l’acte, les formalités de publicité, de communication et, si elle est requise, de transmission au contrôle de légalité.]**

**Article 5 — Voies et délais de recours**

**[Insérer la mention définitive après identification du tribunal administratif compétent et contrôle des voies applicables.]**

Le cadre général documenté prévoit un recours dans les deux mois suivant la notification ou la publication ; l’opposabilité du délai suppose la mention des voies et délais de recours dans la notification.

Fait à **[lieu]**, le **[date]**.  
**[Qualité, nom et signature de l’autorité compétente]**

---

**Contrôles avant signature et mise en paie**

La DRH doit valider l’éligibilité, le tableau et son ordre, le régime du taux de promotion, l’emploi accepté, le classement, la date d’effet et la signature. Elle doit également compléter les formalités et la mention des recours.

Pour une **commune**, la liste de transmission obligatoire fournie ne comporte pas de catégorie consacrée à l’avancement de grade. Cela ne permet pas de certifier les formalités de cet employeur encore inconnu ; le préfet peut par ailleurs demander communication d’actes hors de cette liste. Sources : CGCT, versions depuis le 01/07/2022, consultations archivées du 11/10/2026, [liste de transmission — LEGIARTI000044190560](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) et [communication sur demande — LEGIARTI000044190556](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556).

Le cadre des recours ci-dessus provient du CJA : [délai général — LEGIARTI000039807005](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le 01/01/2020, et [opposabilité — LEGIARTI000006449946](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le 01/01/2001 ; consultations archivées du 11/10/2026.

**Risques résiduels :** nomination sans éligibilité établie, méconnaissance du tableau ou du taux applicable, classement erroné et formalités inadaptées. Limiter les données personnelles aux informations nécessaires à l’acte.

**Confiance : stable sur les règles générales documentées ; abstention sur la possibilité individuelle de nommer. Le projet reste non signable tant que les contrôles signalés ne sont pas achevés.**
