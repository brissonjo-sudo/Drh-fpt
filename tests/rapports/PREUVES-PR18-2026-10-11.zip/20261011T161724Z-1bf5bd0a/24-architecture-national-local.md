# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**L’annualisation reste possible. Vous pouvez conserver votre cycle s’il respecte les règles actuelles et repose sur une délibération applicable. Sa conformité est toutefois non tranchable sans examiner cette délibération et les horaires réels.**

Analyse au **11 octobre 2026**, fondée sur les extraits officiels archivés fournis pour cette date, sans consultation supplémentaire. Le cadrage ci-dessous vise la FPT de droit commun ; un statut particulier peut nécessiter des contrôles supplémentaires.

**Les règles nationales à respecter**

Le décret territorial renvoie aux règles du décret relatif au temps de travail de l’État, avec des adaptations propres aux collectivités : [décret du 12 juillet 2001, règle de renvoi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version applicable fournie depuis le 14 juillet 2001.

| Point | Règle issue des extraits officiels fournis |
|---|---|
| Durée de référence | **35 heures par semaine et 1 607 heures annuelles**, sans préjudice des heures supplémentaires. L’annualisation permet une variation des horaires selon les périodes du cycle. |
| Travail quotidien | **10 heures maximum** ; amplitude de la journée limitée à **12 heures**. |
| Travail hebdomadaire | **48 heures maximum**, heures supplémentaires comprises ; **44 heures maximum en moyenne sur toute période de 12 semaines consécutives**. |
| Repos | Au moins **11 heures quotidiennes** et **35 heures hebdomadaires**, comprenant en principe le dimanche. |
| Pause | Au moins **20 minutes** : aucun temps de travail quotidien ne peut atteindre **6 heures** sans cette pause. |

Sources : décret du 25 août 2000, [durée de référence](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142), [cycles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560147) et [garanties minimales](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150), versions applicables fournies depuis le 1er janvier 2023.

**Une semaine moins chargée ne permet donc pas de compenser le dépassement d’une garantie quotidienne ou hebdomadaire.** Le texte prévoit des dérogations encadrées, notamment pour certaines exigences permanentes du service ou des circonstances exceptionnelles limitées dans le temps. Leur application au service doit être vérifiée séparément ; la seule annualisation ne les autorise pas.

Le décompte doit aussi porter sur le **travail effectif** : temps pendant lequel l’agent reste à disposition de l’employeur, suit ses directives et ne peut vaquer librement à ses occupations personnelles. C’est notamment le critère à examiner pour les pauses : [définition officielle](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version applicable fournie depuis le 29 juin 2006.

**Ce qui dépend de votre collectivité**

L’assemblée délibérante fixe les conditions des cycles **après avis du CST compétent** : [décret territorial, organisation des cycles](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472), version applicable fournie depuis le 1er janvier 2023.

Une durée annuelle inférieure à la référence peut être décidée, après avis du CST, pour des **sujétions documentées** : nuit, dimanche, horaires décalés, équipes, modulation importante du cycle, travaux pénibles ou dangereux. Cette réduction concerne le décompte annuel ; elle ne dispense pas, par elle-même, du respect des garanties minimales : [décret territorial, sujétions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477), même date de version.

**Pour contrôler votre organisation actuelle**

Les faits connus sont l’existence d’un cycle annualisé ancien. Les pièces bloquantes sont sa délibération, ses annexes, les éléments de consultation de l’époque et les plannings effectivement appliqués.

| Ordre | Action recommandée | Responsable et preuve attendue |
|---|---|---|
| 1 | Réunir les documents du cycle, ses modifications et les éventuelles réductions pour sujétions. | DRH : dossier des actes et consultations. |
| 2 | Comparer le planning annuel et les heures réalisées aux bornes nationales et au décompte local. | Encadrement et gestion du temps : tableau des écarts, incluant pauses et heures supplémentaires. |
| 3 | Vérifier la validité actuelle du régime ancien, puis déterminer les corrections nécessaires. | DRH/juridique : contrôle écrit ; si modification, préparation du dossier pour avis du CST puis délibération. |

**Point documentaire restant ouvert :** le corpus métier signale une réforme des anciens régimes dérogatoires, mais les extraits officiels fournis ne permettent pas d’en vérifier ici la portée pour votre délibération. Je ne peux donc pas confirmer le maintien d’une durée annuelle réduite au seul motif qu’elle existe depuis plusieurs années.

Pour trancher, précisez en une fois :

- **Quel employeur, quel effectif et quels agents sont concernés**, avec leur éventuel statut particulier et leur quotité ?
- **Que prévoient la délibération et ses annexes** : durée annuelle, périodes hautes/basses, horaires, pauses et réductions pour sujétions ?

**Recommandation :** contrôler le cycle existant avant de décider son maintien ou sa modification. Le risque principal est un écart entre le planning, le décompte réel et les garanties nationales.

**Confiance : stable pour les règles couvertes par les extraits officiels fournis ; abstention sur la conformité de votre cycle, faute de pièces locales.**
