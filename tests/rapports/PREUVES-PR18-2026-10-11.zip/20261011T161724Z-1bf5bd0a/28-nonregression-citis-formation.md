# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**La formation plénière, si la saisine est requise. La décision finale appartient à l’autorité territoriale**, et non au conseil médical.

- **Quand saisir ?** Pour un accident de service, le texte prévoit la consultation lorsqu’une faute personnelle ou une circonstance particulière est potentiellement de nature à détacher l’accident du service. Une simple mention « accident contesté » ne permet donc pas, à elle seule, de déterminer si la consultation est nécessaire. [Source officielle archivée](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859).
- **Quelle formation ?** Si cette consultation est nécessaire, le conseil médical siège en **formation plénière**, et non restreinte, pour examiner l’imputabilité. [Source officielle archivée](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783).
- **Qui décide ?** À l’issue de l’instruction, **l’autorité territoriale — maire ou président selon l’employeur — se prononce sur l’imputabilité** et, le cas échéant, place le fonctionnaire en CITIS. Le conseil médical rend un avis. [Source officielle archivée](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843).

Pour votre dossier, identifiez donc précisément **le motif de contestation** avant de déterminer si la saisine est requise.

**Confiance : stable sur la formation compétente et l’autorité décisionnaire**, d’après les consultations officielles fournies, datées du 11 octobre 2026, pour des versions applicables à cette date. La nécessité de saisir dans le cas individuel reste à apprécier selon les faits.
