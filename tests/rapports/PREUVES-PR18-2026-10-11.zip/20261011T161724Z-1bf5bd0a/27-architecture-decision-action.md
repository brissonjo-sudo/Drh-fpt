# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Une exclusion de 5 jours relève du deuxième groupe : elle exige un avis préalable du conseil de discipline.** Cela ne permet pas, à lui seul, de conclure que cette sanction est justifiée dans votre dossier. [CGFP, échelle des sanctions, version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) ; [consultation préalable et motivation, même version](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422).

**Décision sur le dossier : non tranchable en l’état.** Je recommande de préparer l’instruction, sans arrêter dès maintenant la sanction à 5 jours. L’ouverture de la procédure devra être décidée après contrôle des faits, de la prescription et de l’autorité compétente.

L’analyse repose sur les **consultations officielles archivées fournies**, applicables au 11 octobre 2026. Je n’ai effectué aucune consultation supplémentaire ; les points non documentés ci-dessous restent à vérifier.

Pour trancher, trois ensembles d’informations sont nécessaires :

- Quel est l’employeur territorial, son effectif, son affiliation au CDG et le cadre d’emplois de l’agent ?
- Quels faits précis sont reprochés, à quelles dates, avec quelles pièces ? Quand l’administration a-t-elle connu leur réalité, leur nature et leur ampleur ? Existe-t-il des poursuites pénales ?
- La procédure est-elle déjà ouverte ? À quelle date envisagez-vous son ouverture et la décision finale ?

Voici les actions à lancer, dans l’ordre. Les premières préparent le dossier ; les étapes suivantes supposent les contrôles préalables satisfaits.

| Ordre | Action et responsable | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : qualifier la situation.** Réunir l’arrêté de titularisation, le cadre d’emplois, la situation administrative et les éléments concernant l’employeur. | Confirmer le régime applicable et identifier l’autorité compétente ainsi que le circuit du conseil de discipline. Contrôler les éventuelles délégations. |
| **2** | **DRH et service concerné : documenter les faits.** Établir une chronologie et réunir rapports, pièces et éléments favorables comme défavorables à l’agent. | Séparer ce qui est établi, contesté ou seulement soupçonné. Identifier les obligations professionnelles susceptibles d’avoir été méconnues, sans transformer les soupçons en faits acquis. |
| **3** | **DRH/juriste : contrôler la prescription et les dates de droit.** | Le délai vérifié est de **3 ans à compter de la connaissance effective de la réalité, de la nature et de l’ampleur des faits**, avec interruption en cas de poursuites pénales selon les conditions du texte. Conserver les pièces établissant cette connaissance et vérifier l’incidence exacte du dossier pénal. [CGFP, art. L.532-2, version depuis le 01/03/2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430). |
| **4** | **Autorité compétente, avec la DRH : décider éventuellement l’ouverture et informer l’agent par écrit.** | Préciser les faits reprochés, le droit d’accès au dossier intégral et l’assistance par un ou plusieurs conseils de son choix. **Avant tout recueil d’observations, faire vérifier l’information sur le droit de se taire et ses modalités** : les extraits officiels fournis ne documentent pas ce point. |
| **5** | **DRH : organiser effectivement les droits de la défense.** | Dossier individuel intégral, documents annexes, pièces numérotées, accès traçable et temps suffisant pour préparer la défense. Aucun délai standard ne remplace l’appréciation du temps nécessaire. Le renvoi concernant les modalités de copie reste à vérifier. [CGFP, droits au dossier et à l’assistance, version depuis le 01/10/2025](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000052323864) ; [décret disciplinaire, information et dossier, version depuis le 11/12/2025](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836). |
| **6** | **Autorité/DRH : si une sanction du deuxième groupe reste envisagée, préparer la saisine du conseil de discipline.** | Faire vérifier le rapport de saisine, les pièces requises, la composition et le circuit selon l’affiliation au CDG. Le président convoque le conseil ; l’autorité investie du pouvoir disciplinaire ne peut y siéger. [Décret disciplinaire, disposition sur le conseil, version depuis le 03/12/1996](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222). |
| **7** | **Président et secrétariat du conseil : organiser la séance.** | L’agent doit être convoqué par lettre recommandée avec avis de réception **au moins 15 jours avant la réunion**. Contrôler la convocation et les possibilités d’observations, de témoins et d’assistance. Ce délai concerne la séance, pas automatiquement toute la préparation de la défense. [Décret disciplinaire, convocation, version depuis le 19/09/1989](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372226). |
| **8** | **Autorité compétente : réexaminer le dossier après l’avis et décider.** | Vérifier les faits retenus, les explications de l’agent et la proportionnalité de la sanction. L’avis doit être motivé et communiqué sans délai à l’agent et à l’autorité. La décision doit exposer par écrit ses fondements de droit et de fait. [Décret disciplinaire, avis et décision, version depuis le 10/12/2020](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042650806) ; [CRPA, obligation de motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et [contenu de la motivation, versions depuis le 01/01/2016](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513). |
| **9** | **DRH/juriste : sécuriser la notification et l’exécution.** | Contrôler la compétence du signataire, la date d’effet, les voies et délais de recours, la notification traçable et les conséquences administratives et de paie. Les textes de recours et les règles financières nécessaires ne sont pas fournis : les vérifier avant finalisation. |

**Contrôle de légalité : ne prévoyez pas une transmission obligatoire du seul fait de la sanction.** Pour une commune, la liste actuelle fournie ne comporte pas de catégorie relative aux sanctions disciplinaires des titulaires. Il faut distinguer cette liste, les modalités locales de télétransmission et une éventuelle demande du préfet. Celui-ci peut demander communication d’un acte hors liste. Pour un autre employeur territorial, contrôler les dispositions propres. [CGCT, art. L.2131-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) ; [demande de communication des actes hors liste](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), versions depuis le 01/07/2022.

Avant signature, faites aussi vérifier les **recours actuels**, notamment la suppression de l’ancien conseil de discipline de recours et tout régime transitoire pertinent. Le corpus métier signale ce point, mais les extraits officiels fournis ne permettent pas de le certifier.

Les risques principaux sont une prescription mal calculée, des faits insuffisamment établis, une défense entravée ou une sanction disproportionnée. Limitez la circulation du dossier aux personnes nécessaires.

**Confiance : stable sur les règles étayées par les extraits officiels ; abstention sur la possibilité d’engager ce dossier précis et sur le choix définitif des 5 jours, tant que les informations et vérifications manquantes ne sont pas réunies.**
