# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Pour votre commune d’environ 40 agents, il faut d’abord identifier le CST compétent.** L’extrait officiel fourni prévoit un **CST auprès du centre de gestion pour les collectivités affiliées employant moins de 50 agents**.

Source : [CGFP — disposition relative à la création des CST](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312), version applicable au 11 octobre 2026, consultation archivée fournie dans le corpus.

**Votre commune est-elle affiliée au centre de gestion, et quel projet souhaitez-vous soumettre au CST ?** Ces deux informations déterminent l’instance à contacter et les règles de consultation à rechercher.

La procédure détaillée est **non tranchable en l’état** : le corpus métier vise les collectivités de plus de 350 agents et l’extrait officiel fourni ne décrit ni la saisine, ni les délais, ni les pièces nécessaires. Cette limite documentaire ne signifie pas que votre commune serait dispensée de consultation.

Pour préparer votre démarche :

- **Vous ou votre gestionnaire RH** : réunir le projet, son objet, ses effets sur les agents et la date envisagée de mise en œuvre.
- **Auprès du CDG, si votre affiliation est confirmée** : demander au secrétariat du CST la fiche de saisine, les pièces attendues et le calendrier des séances.
- **Faire confirmer avant toute décision** : le caractère obligatoire de la consultation, son articulation avec l’adoption du projet, l’autorité compétente et les formalités finales.

**Niveau de confiance :** le critère d’identification du CST est documenté par l’extrait fourni ; **abstention sur la procédure exacte**, faute de sources adaptées dans ce dossier.
