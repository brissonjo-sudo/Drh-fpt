# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non, pour une sanction nouvelle prononcée en 2026 : l’agent ne peut plus saisir un conseil de discipline de recours.** Cette voie a été supprimée. Le maintien transitoire concerne uniquement d’anciens recours déjà engagés lors de la réforme, pas cette exclusion.

Cette conclusion repose sur les extraits officiels archivés du décret du 8 décembre 2020 : [abrogation du chapitre consacré au recours](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000042625346) et [dispositions transitoires](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000042625452).

Pour un **fonctionnaire territorial relevant de l’échelle fournie**, une exclusion de cinq jours appartient au **deuxième groupe** : le conseil de discipline devait être consulté **avant** la sanction. Ce conseil préalable se distingue de l’ancien conseil de recours ([échelle des sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388), [consultation et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422)).

Dans la notification, indiquez le **recours devant le tribunal administratif compétent**, avec son délai. Formulation exploitable après identification du tribunal :

> « Vous pouvez contester cette décision devant le tribunal administratif de **[tribunal territorialement compétent]**, dans un délai de **deux mois à compter de sa notification**. »

Les extraits du Code de justice administrative établissent le [délai de deux mois](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005) et précisent que ce délai n’est opposable que si les **voies et délais de recours figurent dans la notification** ([source](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946)).

**À contrôler avant envoi :**

- Le statut exact de l’agent : ne pas transposer automatiquement l’échelle du titulaire à un stagiaire ou à un contractuel.
- Le tribunal compétent, la motivation de la sanction et la preuve de notification.
- Si vous ajoutez un **recours gracieux auprès de l’autorité territoriale**, ses modalités et ses effets sur le délai contentieux : les extraits officiels fournis ne permettent pas de les confirmer.

**État de décision : possible sous conditions** pour finaliser la notification. **Confiance : stable** sur la suppression du conseil de recours et les règles contentieuses citées, d’après les consultations archivées fournies au 11 octobre 2026.
