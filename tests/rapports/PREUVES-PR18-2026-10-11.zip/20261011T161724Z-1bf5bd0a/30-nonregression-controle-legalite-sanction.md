# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non, au 11 octobre 2026.** Une exclusion temporaire de fonctions de cinq jours prononcée contre un fonctionnaire communal **n’est pas soumise à transmission obligatoire au titre de l’article L. 2131-2 du CGCT**.

La version applicable de cet article ne comporte plus de catégorie visant les sanctions disciplinaires. Son 5° concerne certaines décisions de nomination, de recrutement et de licenciement d’agents non titulaires.

La confusion peut venir de **l’ancienne version**, applicable au 1er janvier 2004 : elle mentionnait expressément les « sanctions soumises à l’avis du conseil de discipline ». Cette liste historique ne doit pas être appliquée à une sanction actuelle.

Il reste à distinguer cette absence de transmission obligatoire d’une **demande de communication du préfet**, que le texte fourni autorise pour les actes hors liste. Vérifiez donc séparément une éventuelle demande préfectorale et les modalités locales de télétransmission.

Sources : [L. 2131-2, version depuis le 1er juillet 2022](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), [version historique](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006390079), [communication à la demande du préfet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556).

**Niveau de confiance : stable**, sur la base des consultations officielles archivées fournies dans le corpus, datées du 11 octobre 2026.
