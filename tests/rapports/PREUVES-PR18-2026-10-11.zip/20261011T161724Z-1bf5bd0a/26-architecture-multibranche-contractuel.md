# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne suffit pas à donner au contractuel les droits de carrière d’un fonctionnaire titulaire.** Il faut distinguer sa demande d’avancement de grade de sa demande de revalorisation salariale.

L’analyse porte sur un **contractuel de droit public territorial**, au **11 octobre 2026**, à partir des consultations officielles archivées fournies dans le corpus. Aucune nouvelle consultation n’a été effectuée.

**Ce que les sources permettent d’établir**

La rémunération d’un contractuel est fixée en tenant compte des fonctions, des qualifications et de l’expérience. L’indice peut servir de référence pour déterminer cette rémunération ; il ne constitue pas, à lui seul, une nomination dans un grade.

Source : [CGFP — fixation de la rémunération des contractuels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), version en vigueur depuis le 1er mars 2022, consultation archivée du 11 octobre 2026 — fonction juridique : rémunération.

**J’en déduis que :**

- **Avancement de grade :** le CDI et l’indice de référence ne fondent pas un droit à l’avancement statutaire demandé. Une évolution des fonctions ou de la rémunération doit être examinée séparément.
- **Reprise de toute l’ancienneté :** l’expérience est un élément à prendre en compte, mais cette prise en compte ne signifie pas une conversion automatique de chaque année de service en échelon ou en indice supérieur. Il faut examiner le contrat, ses avenants et le cadre local de rémunération avant de répondre définitivement.

Pour un agent en **CDI**, la rémunération doit faire l’objet d’une **réévaluation au moins tous les trois ans**, notamment au regard des entretiens professionnels ou de l’évolution des fonctions. Le texte impose un réexamen ; il ne garantit ni une augmentation ni un rattrapage intégral d’ancienneté.

Source : [décret relatif aux contractuels territoriaux — rémunération et réévaluation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), version en vigueur depuis le 1er juillet 2026, consultation archivée du 11 octobre 2026 — fonctions juridiques : fixation de la rémunération et réévaluation périodique.

**État de décision**

- **Impossible en l’état :** accorder un avancement de grade de fonctionnaire sur le seul fondement du CDI et de l’indice.
- **Non tranchable :** reconnaître une reprise intégrale d’ancienneté ou déterminer un nouvel indice sans les pièces contractuelles et locales.
- **Possible sous conditions :** examiner une revalorisation motivée par l’expérience, les fonctions, les qualifications ou les résultats professionnels.

**La marche à suivre**

| Ordre | Action et responsable | Pièces et contrôle attendus |
|---|---|---|
| 1 | **DRH : qualifier le dossier** | Confirmer l’employeur, le régime de droit public, le fondement du recrutement et la nature du poste ; relever la date d’effet souhaitée. |
| 2 | **DRH : examiner les engagements existants** | Contrat, avenants, clause de rémunération, délibération ou cadre local applicable. Vérifier si une clause prévoit une évolution ou une prise en compte particulière des services antérieurs. |
| 3 | **DRH et supérieur hiérarchique : documenter le réexamen** | Historique des services et rémunérations, date de la dernière réévaluation, fiche de poste, qualifications, expérience pertinente et comptes rendus d’entretien. |
| 4 | **Autorité territoriale : arbitrer la rémunération** | Comparer les fonctions et responsabilités actuelles avec celles ayant fondé la rémunération initiale ; tracer les raisons d’une revalorisation ou d’un maintien. |
| 5 | **DRH et paie : formaliser après contrôle** | Vérifier le support nécessaire, notamment l’éventuel avenant, la date d’effet et les paramètres de paie avant toute modification. Répondre distinctement aux deux demandes. |

Pour un CDI sur emploi permanent, l’entretien professionnel annuel constitue une pièce utile à cette appréciation ; il est conduit par le supérieur hiérarchique direct.

Source : [décret relatif aux contractuels territoriaux — entretien professionnel](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), version en vigueur depuis le 1er janvier 2023, consultation archivée du 11 octobre 2026 — fonction juridique : évaluation professionnelle.

Si l’objectif de l’agent est d’accéder à une carrière de fonctionnaire, **la piste à vérifier est une voie de recrutement statutaire distincte**, puis les règles de classement et de reprise des services propres au cadre d’emplois visé.

**Avant toute décision individuelle**, contrôler les clauses contractuelles, les règles locales, les formalités applicables et, si une décision faisant grief est préparée, sa motivation et ses recours. Les principaux risques sont de promettre une progression automatique, d’ignorer un engagement contractuel ou d’omettre une réévaluation arrivée à échéance.

**Confiance : stable sur les règles de rémunération et de réévaluation documentées ; abstention sur le droit individuel à une reprise intégrale et sur son chiffrage, faute de pièces.**
