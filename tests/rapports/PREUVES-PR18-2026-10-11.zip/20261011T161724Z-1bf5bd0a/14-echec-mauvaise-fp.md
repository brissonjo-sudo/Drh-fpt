# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Votre CHU relève de la fonction publique hospitalière (FPH). Le corpus fourni couvre uniquement la fonction publique territoriale (FPT)** : ses règles ne peuvent donc pas être transposées à votre agent, même avec un effectif de 900 agents.

**Décision : non tranchable avec ce corpus.** Les huit mois d’arrêt indiqués ne précisent pas le congé actuellement accordé ni si une demande de congé de longue maladie (CLM) a été instruite.

Mode dégradé : aucune source officielle n’a été consultée. Je m’abstiens donc de donner des durées, une rémunération ou une procédure hospitalière non vérifiées.

Pour préparer l’examen du dossier, réunissez :

- la **date de début de l’arrêt** et les décisions de congé déjà notifiées ;
- la **nature du congé actuel** et l’existence éventuelle d’une demande de CLM ;
- l’historique des congés utile à l’examen des droits, sans diffuser de diagnostic médical.

Le service chargé du statut hospitalier devra ensuite contrôler, dans les dispositions du **CGFP applicables à la FPH et les textes hospitaliers correspondants**, les conditions d’accès au CLM, sa durée, la rémunération, les renouvellements et le circuit médical et décisionnel, aux dates pertinentes.

**Recommandation :** faire qualifier le dossier dans le régime hospitalier avant toute décision ou modification de paie.

**Niveau de confiance : abstention sur le régime de CLM applicable**, faute de documentation hospitalière et de vérification officielle.
