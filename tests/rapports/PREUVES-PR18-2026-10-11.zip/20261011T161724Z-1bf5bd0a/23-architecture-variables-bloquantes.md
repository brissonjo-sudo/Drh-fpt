# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Le nom et le cadre d’emplois ne suffisent pas pour déterminer si l’agent peut être nommé au grade supérieur en **2026**. Son nom n’est pas nécessaire pour cette analyse.

Pour avancer, pouvez-vous réunir ces trois blocs ?

- **Situation de l’agent** : titulaire, stagiaire ou contractuel ; cadre d’emplois exact, grade actuel, grade visé, échelon et ancienneté.
- **Parcours** : état des services et, le cas échéant, réussite à un examen professionnel.
- **Cadre de la campagne** : date de nomination envisagée, LDG applicables, délibération fixant le taux de promotion et éléments d’appréciation de la valeur professionnelle.

Les extraits officiels fournis permettent déjà de distinguer **l’éligibilité**, **l’inscription au tableau** et **la nomination** :

| Point établi par les sources fournies | Conséquence pour votre dossier |
|---|---|
| L’avancement peut notamment intervenir au choix ou après examen professionnel ; au choix, la valeur professionnelle, l’expérience et les LDG sont prises en compte. | Il faut identifier la voie applicable au grade visé. [Source CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506) |
| Le taux de promotion est fixé par l’assemblée délibérante après avis du CST, avec une exception expressément prévue pour le cadre d’emplois des agents de police municipale. | Il faut retrouver le taux local ou contrôler le régime particulier applicable. [Source CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500) |
| L’autorité territoriale prononce l’avancement parmi les agents inscrits au tableau, en respectant son ordre. | **Remplir les conditions ne garantit pas une nomination.** [Source CGFP](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498) |

*Ces trois extraits sont accompagnés d’une trace de consultation du 11 octobre 2026 et d’une version applicable à cette date.*

**Prochaine action :** la DRH peut constituer une fiche de contrôle avec les pièces ci-dessus, puis vérifier le statut particulier du cadre d’emplois : conditions d’accès au grade cible, ancienneté retenue, examen éventuel et règles applicables à la date prévue. Elle devra aussi contrôler les possibilités de nomination sur un emploi correspondant et le rôle actuel des instances ; ces points ne sont pas vérifiés par les extraits fournis.

**Confiance : abstention sur l’éligibilité individuelle.** Les principes du tableau sont documentés, mais les données de carrière et le texte statutaire déterminant manquent. Ne validez pas encore cette nomination.
