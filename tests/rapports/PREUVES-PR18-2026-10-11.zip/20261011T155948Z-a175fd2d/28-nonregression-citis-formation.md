# QVT & santé

## Question
Pour instruire un accident de service contesté d'un fonctionnaire territorial, dois-je saisir le conseil médical en formation restreinte ou en formation plénière, et qui prend la décision finale d'imputabilité ?

## Réponse (contexte vierge)
**La formation plénière, lorsque la saisine est requise. La décision finale d’imputabilité appartient à l’autorité territoriale ; le conseil médical rend un avis.**

Une contestation ne rend pas, à elle seule, la saisine automatique. Pour un accident de service, le texte prévoit la consultation lorsqu’une **faute personnelle ou une circonstance particulière pourrait détacher l’accident du service**. Il faut donc identifier le motif de contestation.

Les extraits officiels archivés fournis établissent :

- **Le déclencheur de consultation** : [disposition sur la saisine du conseil médical](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428859).
- **La formation compétente : plénière** : [disposition sur les compétences de cette formation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428783).
- **La décision de l’autorité territoriale**, au terme de l’instruction : [disposition sur la reconnaissance d’imputabilité et le placement en CITIS](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049428843).

Ces trois extraits du décret relatif aux fonctionnaires territoriaux sont fournis en version applicable depuis le **18 avril 2024**, avec consultation officielle archivée le **11 octobre 2026**.

**État de décision : possible sous conditions pour la saisine.** La DRH doit documenter le motif de contestation pour déterminer si le cas impose cette consultation, puis préparer la décision de l’autorité territoriale.

**Confiance : stable sur la formation et l’auteur de la décision ; nécessité de saisine à apprécier selon les faits.**
