# Carrière & paie

## Question
Après une exclusion temporaire de fonctions de 5 jours prononcée en 2026, l'agent territorial peut-il saisir un conseil de discipline de recours ? Quelles voies dois-je indiquer dans la notification ?

## Réponse (contexte vierge)
**Non, pour un fonctionnaire territorial relevant de l’échelle des sanctions fournie : une exclusion prononcée en 2026 ne peut pas être contestée devant un conseil de discipline de recours.**

Les textes fournis établissent la suppression de cette voie. Le maintien transitoire concerne les recours déjà en cours lors de l’entrée en vigueur de la réforme de 2019, pas une sanction nouvelle de 2026. Sources : décret modificatif, [abrogation du chapitre relatif au recours](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000042625346) et [dispositions transitoires](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000042625452), consultations archivées du 11 octobre 2026.

**Dans la notification, indiquez le recours devant le tribunal administratif compétent et son délai.** Les extraits officiels fournis établissent :

- un délai de **deux mois à compter de la notification** pour contester la décision : [Code de justice administrative](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005) ;
- l’exigence de mentionner les voies et délais de recours dans la notification pour rendre ce délai opposable : [Code de justice administrative](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946).

Formulation à compléter après contrôle du ressort :

> « La présente décision peut être contestée devant le tribunal administratif de **[ville]**, dans un délai de **deux mois à compter de sa notification**. »

Pour un éventuel **recours gracieux auprès de l’autorité signataire**, les extraits fournis ne permettent pas de certifier ses modalités ni son effet sur le délai contentieux. Ces points doivent être contrôlés avant d’ajouter une mention correspondante.

Autre contrôle utile : dans l’échelle fournie, l’exclusion de cinq jours appartient au **deuxième groupe** et exige une consultation **préalable** du conseil de discipline. Ce conseil préalable est distinct du conseil de recours supprimé. Sources : [échelle des sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) et [consultation préalable et motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422).

**État de décision : notification possible sous conditions.** Avant envoi, confirmer le statut de l’agent, le tribunal compétent, la motivation et la preuve de notification. L’agent est-il **titulaire, stagiaire ou contractuel**, et quelle collectivité l’emploie ? Le corpus ne permet pas de finaliser les régimes propres aux deux dernières situations.

**Confiance : stable sur les points établis par les consultations officielles fournies ; abstention ciblée sur les modalités du recours gracieux.**
