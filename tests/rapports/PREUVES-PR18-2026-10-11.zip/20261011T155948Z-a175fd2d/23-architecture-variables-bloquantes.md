# Carrière & paie

## Question
Je prépare le tableau d'avancement de grade. Un agent pourrait-il être nommé au grade supérieur cette année ? Je n'ai pour l'instant que son nom et son cadre d'emplois.

## Réponse (contexte vierge)
**Non tranchable en l’état : son nom et son cadre d’emplois ne suffisent pas pour déterminer s’il peut être nommé au grade supérieur en 2026.** Il faut contrôler son éligibilité, puis les conditions de nomination.

Pour avancer, pouvez-vous réunir ces trois blocs d’informations, sans transmettre son nom ?

- **Employeur et statut** : type de collectivité, effectif supérieur ou non à 350 agents ; agent titulaire, stagiaire ou contractuel.
- **Situation de carrière** : cadre d’emplois exact, grade actuel et grade visé, échelon et date d’accès, ancienneté et services accomplis, éventuel examen professionnel réussi, date de nomination envisagée.
- **Pièces locales** : LDG applicables, délibération fixant le taux de promotion lorsqu’il s’applique, projet de tableau et situation de l’emploi permettant la nomination.

Les extraits officiels fournis permettent déjà de distinguer :

| Socle national documenté | Élément local à contrôler |
|---|---|
| L’avancement passe notamment par un tableau annuel, au choix ou après examen professionnel. | Modalité applicable au grade visé et critères des LDG. |
| Le maximum de promotions dépend d’un taux fixé par l’assemblée après avis du CST, avec l’exception mentionnée pour le cadre d’emplois des agents de police municipale. | Délibération applicable et effectif des promouvables. |
| L’autorité territoriale prononce les promotions parmi les inscrits, dans l’ordre du tableau. | Inscription et rang de l’agent. |

**Recommandation :** faites préparer par le gestionnaire carrière une fiche anonymisée « grade actuel → grade cible ». Il devra confronter les données individuelles au **statut particulier du cadre d’emplois**, puis aux pièces locales. Ce statut particulier n’est pas fourni : je ne peux donc confirmer aucune condition d’ancienneté, d’échelon ou d’examen.

Les trois premières règles sont documentées par les traces officielles fournies : CGFP, [modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), [taux de promotion](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500) et [nomination dans l’ordre du tableau](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), versions applicables au 11 octobre 2026, consultations archivées à cette date.

**Confiance : abstention sur l’éligibilité individuelle.** Le risque serait de confondre agent potentiellement promouvable et agent pouvant effectivement être nommé ; ces deux contrôles restent à réaliser.
