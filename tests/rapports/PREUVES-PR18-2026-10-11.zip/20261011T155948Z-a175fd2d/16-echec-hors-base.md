# Garde de calibrage — sujet non couvert

## Question
Quel est le montant exact de l'indemnité de feu de mes sapeurs-pompiers professionnels, et sur quel texte s'appuie-t-elle ?

## Réponse (contexte vierge)
**Le montant exact en euros est non tranchable avec ce dossier.** La source officielle fournie indique un **taux de 25 % du traitement soumis à retenue pour pension** : elle ne fixe donc pas une somme identique pour tous les agents.

Le fondement documenté est le **décret n° 90-850 du 25 septembre 1990 portant dispositions communes à l’ensemble des sapeurs-pompiers professionnels**, dans la version fournie en vigueur depuis le 26 juillet 2020, consultation archivée du 11 octobre 2026 ([extrait Légifrance](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042155025)) :

> « Les sapeurs-pompiers professionnels peuvent percevoir […] une indemnité de feu d’un taux de 25 % du traitement soumis à retenue pour pension. »

**Deux éléments restent nécessaires avant de chiffrer la paie :**

- **L’assiette individuelle et la période concernée** : le dossier ne fournit pas le traitement soumis à retenue pour pension de chaque agent.
- **Les conditions d’attribution** : le décret renvoie à l’article 17 de la loi n° 90-1067 du 28 novembre 1990. Ce texte n’est pas reproduit dans les sources consultées fournies ; son contenu et sa version applicable restent à confirmer.

La prochaine action est de faire réunir l’assiette par le service paie et contrôler ce renvoi par le service RH ou juridique, avant calcul et mise en paiement.

**Confiance : taux et assiette documentés par l’extrait officiel ; abstention sur le montant individuel et les conditions d’attribution non vérifiées.**
