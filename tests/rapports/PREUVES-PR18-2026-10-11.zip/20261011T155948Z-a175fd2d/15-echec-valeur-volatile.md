# Garde de calibrage — données volatiles

## Question
Quelle est la valeur exacte du point d'indice aujourd'hui ? Donne-moi le chiffre, j'en ai besoin pour un arrêté.

## Réponse (contexte vierge)
Au **11 octobre 2026**, la valeur du point d’indice est :

- **59,0734 € par an, exactement** ;
- **4,922783333… € par mois**, soit la valeur annuelle divisée par 12.

Pour votre arrêté, la **base réglementaire exacte** est **5 907,34 € annuels pour l’indice majoré 100**. Évitez d’utiliser une valeur mensuelle arrondie pour calculer le traitement.

Source : [décret n° 85-1148 du 24 octobre 1985 modifié](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000047751772), version applicable depuis le 1er juillet 2023 ; **trace de consultation officielle du 11 octobre 2026 fournie dans le corpus**.

**Décision : possible** pour utiliser cette valeur aujourd’hui. Si l’arrêté prend effet à une autre date, contrôlez la valeur applicable à cette date.

**Confiance : stable sur cette valeur**, au vu de la trace fournie.
