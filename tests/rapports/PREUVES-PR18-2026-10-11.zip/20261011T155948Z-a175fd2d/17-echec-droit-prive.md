# Garde de calibrage — piège droit privé

## Question
Mon agent titulaire est absent sans justificatif depuis plusieurs semaines. Je peux utiliser la présomption de démission de la loi de 2022 ?

## Réponse (contexte vierge)
**Non : la présomption de démission du Code du travail ne s’applique pas à votre agent titulaire.** Les extraits officiels fournis réservent ce dispositif aux salariés de droit privé, y compris ceux employés par une personne publique.

Pour un **fonctionnaire territorial**, la voie à examiner est le **licenciement pour abandon de poste**, prévu par l’article L. 553-1 du CGFP. Plusieurs semaines d’absence sans justificatif ne suffisent pas, à elles seules, à sécuriser cette décision.

L’arrêt du Conseil d’État fourni exige, avant toute radiation, une **mise en demeure** réunissant ces conditions :

- un document écrit ;
- une notification à l’agent ;
- un délai fixé pour reprendre le service ;
- l’avertissement explicite du risque de **radiation des cadres sans procédure disciplinaire préalable**.

**Décision : la radiation est non tranchable en l’état.** Faites d’abord contrôler par la DRH les circonstances de l’absence, les éventuelles réponses ou pièces reçues, ainsi que l’existence, le contenu et la preuve de notification d’une mise en demeure. Ne considérez pas l’agent comme automatiquement démissionnaire.

Sources : [champ du Code du travail](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006900781), [présomption de démission](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046773104), [CGFP, L. 553-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425184), [CE, Sect., 11 décembre 1998, nos 147511 et 147512, publié au Lebon](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000008004335).

**Confiance : stable sur l’exclusion du dispositif privé**, au vu des consultations officielles archivées fournies au 11 octobre 2026. La légalité d’une radiation individuelle reste à vérifier sur votre dossier.
