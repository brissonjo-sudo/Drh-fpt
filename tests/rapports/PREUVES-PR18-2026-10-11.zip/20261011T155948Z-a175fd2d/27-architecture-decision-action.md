# Carrière & paie

## Question
Un agent titulaire est soupçonné de faits pouvant justifier une exclusion temporaire de 5 jours. Explique-moi juridiquement si je peux engager cette procédure, puis recommande-moi une décision et donne-moi les actions concrètes à lancer, dans l'ordre, avec les contrôles à prévoir.

## Réponse (contexte vierge)
**Décision recommandée : préparer le dossier, sans décider dès maintenant d’une exclusion de cinq jours.** La légalité de l’engagement est **non tranchable en l’état**, car les faits, leurs dates et le régime exact de l’employeur ne sont pas précisés.

Je m’appuie uniquement sur les extraits officiels et les traces de consultation fournis, applicables au **11 octobre 2026**. Les contrôles non couverts par ces extraits restent à vérifier.

**Trois précisions permettront de trancher :**

1. Quel est l’employeur : commune, établissement ou autre collectivité, avec quel effectif et quelle affiliation au centre de gestion ?
2. Quels faits sont reprochés, à quelles dates, et quelles pièces les étayent ?
3. Quand l’administration a-t-elle eu connaissance effective de leur réalité, nature et ampleur ? Existe-t-il des poursuites pénales ou une procédure disciplinaire antérieure concernant ces faits ?

Ces informations déterminent notamment le régime applicable, la prescription et le circuit du conseil de discipline.

**Ce que les sources fournies permettent déjà d’établir**

- **Une exclusion temporaire de cinq jours appartient au deuxième groupe.** Elle exige donc une **consultation préalable du conseil de discipline**, avant toute décision de sanction. L’avis et la décision doivent être motivés.  
  Sources : [CGFP, échelle des sanctions](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425388) et [consultation préalable](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425422), versions depuis le 01/03/2022 ; consultations archivées du 11/10/2026.

- **La prescription doit être contrôlée avant l’engagement.** Le délai est de trois ans à compter de la connaissance effective précisée ci-dessus, avec les règles d’interruption liées aux poursuites pénales et la réserve d’une procédure antérieure prévues par le texte. Sans les dates, aucun calcul fiable n’est possible.  
  Source : [CGFP, prescription disciplinaire](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425430), version depuis le 01/03/2022, applicable à la date d’analyse ; consultation archivée du 11/10/2026.

- **L’agent doit pouvoir exercer sa défense.** Les extraits imposent une information écrite sur la procédure et les faits reprochés, l’accès au dossier intégral et aux annexes, l’assistance de défenseurs de son choix et un délai suffisant pour préparer sa défense. Les pièces doivent être numérotées.  
  Sources : [CGFP, droits de la défense](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000052323864), version depuis le 01/10/2025, et [décret disciplinaire, information et dossier](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053007836), version depuis le 11/12/2025 ; consultations archivées du 11/10/2026.

**J’en déduis que** la sanction envisagée impose un circuit avec conseil de discipline. En revanche, cette classification ne prouve ni la réalité des faits, ni leur caractère fautif, ni la pertinence de cinq jours. Ce quantum doit rester une hypothèse à examiner.

**Actions à lancer, dans l’ordre**

Ce tableau constitue un dossier de préparation. Les étapes d’engagement et de décision restent conditionnées aux contrôles indiqués.

| Ordre | Action et responsable | Contrôle et preuve attendue |
|---|---|---|
| **1** | **DRH : qualifier le dossier** avec les trois réponses demandées. | Pièce établissant la titularisation, employeur et régime applicables, affiliation CDG ; compétence du signataire et délégation éventuelle à vérifier. |
| **2** | **DRH et service concerné : établir une chronologie et réunir les pièces.** Distinguer faits rapportés, éléments établis et points contestés ; conserver aussi les éléments favorables à l’agent. | Dossier daté, inventorié et numéroté ; origine des pièces identifiable. Accès limité aux personnes chargées du dossier. |
| **3** | **DRH/juriste : contrôler la prescription et le fondement de l’engagement.** | Note comparant dates des faits, connaissance effective et action envisagée ; pièces relatives aux éventuelles poursuites pénales et procédures antérieures. Aucun engagement validé si ce contrôle reste bloquant. |
| **4** | **Autorité compétente, avec la DRH : décider de l’engagement après validation**, puis informer l’agent selon les garanties vérifiées. | Information écrite précisant les faits et les droits ; preuve de remise, accès effectif au dossier et temps suffisant pour préparer la défense. **Avant tout recueil d’observations, faire vérifier les modalités d’information sur le droit de se taire**, absentes des extraits officiels fournis. |
| **5** | **DRH : préparer la saisine du conseil de discipline**, si une sanction du deuxième groupe reste envisagée. | Faire vérifier les modalités de saisine, la composition et le circuit compétent. Le secrétariat est assuré par la personne publique auprès de laquelle est placée la CAP ; l’autorité investie du pouvoir disciplinaire ne peut siéger. |
| **6** | **Président du conseil et secrétariat : organiser la séance.** | Le président convoque l’agent par lettre recommandée avec avis de réception **au moins quinze jours avant la réunion**. Contrôler la preuve et le calendrier de convocation, la possibilité d’observations, de témoins et d’assistance. |
| **7** | **Autorité compétente : réexaminer le dossier après l’avis et la défense de l’agent.** | Avis communiqué sans délai à l’agent et à l’autorité. Examiner les faits finalement établis, les arguments de défense et la proportionnalité ; documenter pourquoi une sanction est retenue ou écartée, et pourquoi sa durée convient. |
| **8** | **DRH/juriste : sécuriser la décision avant signature et mise en œuvre.** | Motivation écrite en droit et en fait ; contrôle de la compétence, de la date d’effet, de la notification, des voies et délais de recours, des conséquences administratives et de paie, et de la transmission éventuelle. Les points non couverts par le corpus doivent être vérifiés avant exécution. |

Les contrôles des étapes 5 à 7 reposent sur les extraits du décret disciplinaire relatifs au [secrétariat et à la convocation du conseil](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372222), à la [convocation de l’agent](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006372226) et à la [communication de l’avis et à la décision motivée](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042650806), versions respectivement depuis le 03/12/1996, le 19/09/1989 et le 10/12/2020 ; consultations archivées du 11/10/2026.

La motivation écrite en droit et en fait est également confirmée par le [CRPA, décisions infligeant une sanction](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367505) et le [contenu de la motivation](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367513), versions depuis le 01/01/2016 ; consultations archivées du 11/10/2026.

**Point particulier pour une commune :** ne pas prévoir une transmission obligatoire au préfet simplement parce qu’il s’agit d’une sanction. La liste fournie ne comporte pas de catégorie générale visant les sanctions disciplinaires ; le préfet peut toutefois demander communication d’actes hors de cette liste. Vérifier séparément la nature exacte de l’acte et les modalités locales de télétransmission. Sources : [CGCT, actes transmis](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) et [demande de communication](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), versions depuis le 01/07/2022 ; consultations archivées du 11/10/2026.

Les risques principaux sont une prescription mal appréciée, des faits insuffisamment établis, une défense entravée, une consultation irrégulière ou une durée disproportionnée.

**Niveau de confiance : stable sur les règles directement établies par les extraits fournis ; abstention sur la légalité de l’engagement dans ce dossier et sur le choix final des cinq jours.**
