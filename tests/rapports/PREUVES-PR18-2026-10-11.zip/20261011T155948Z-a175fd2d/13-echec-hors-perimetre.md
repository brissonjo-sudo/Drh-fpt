# Garde de calibrage — périmètre

## Question
Je suis maire d'une petite commune d'environ 40 agents. Je dois consulter mon CST : quelle est la procédure ?

## Réponse (contexte vierge)
**Avec environ 40 agents, le CST à consulter doit d’abord être identifié.** L’extrait officiel fourni prévoit un CST auprès du centre de gestion pour les collectivités **affiliées employant moins de 50 agents**. Il ne permet donc pas de présumer que votre commune dispose d’un CST propre.

**Votre commune est-elle affiliée au centre de gestion, et savez-vous si vous relevez de son CST ou d’un CST commun ?** Précisez également l’objet de la consultation : réorganisation, temps de travail, régime indemnitaire…

**État de décision : non tranchable pour la procédure en l’état.** Le volet métier du corpus couvre les collectivités de plus de 350 agents ; il ne contient pas la procédure applicable à votre petite commune. Je ne peux donc pas vous donner des délais, formalités ou règles de vote fiables.

Pour préparer la suite :

- **La mairie** réunit le projet à examiner et confirme le CST dont elle relève.
- **Le secrétariat de ce CST** fournit le formulaire de saisine, les pièces attendues et son calendrier.
- **Le référent RH ou le CDG** contrôle les règles applicables à l’objet du projet avant sa mise en œuvre.

Source : [extrait du CGFP fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044427312), version en vigueur depuis le 01/01/2023, consultation officielle archivée du 11/10/2026. Cette trace soutient l’orientation sur l’instance, **pas une procédure complète**.

**Confiance : abstention sur la procédure ; affiliation et instance compétente à confirmer.**
