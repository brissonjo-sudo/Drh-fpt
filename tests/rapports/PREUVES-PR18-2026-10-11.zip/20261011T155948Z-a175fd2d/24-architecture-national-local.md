# Carrière & paie

## Question
Notre service travaille selon un cycle annualisé défini il y a plusieurs années. Quelles règles de temps de travail devons-nous appliquer aujourd'hui, et pouvons-nous conserver notre organisation actuelle ?

## Réponse (contexte vierge)
**Vous pouvez conserver un cycle annualisé, à condition qu’il respecte les règles actuelles et repose sur une délibération applicable. Son ancienneté ne suffit pas à établir sa conformité.**

**Décision : non tranchable pour votre organisation précise**, faute de disposer du cycle, de la délibération et du décompte annuel. L’annualisation reste une organisation possible sous conditions.

Cette réponse porte sur le **droit commun de la fonction publique territoriale au 11 octobre 2026**. Elle s’appuie sur les extraits officiels et les traces de consultation fournis dans le corpus, sans nouvelle consultation.

**Les règles à appliquer**

Pour un agent à temps complet, la référence est **35 heures hebdomadaires et 1 607 heures annuelles de travail effectif**. Dans un cycle annualisé, les semaines peuvent avoir des durées différentes : le contrôle porte sur le décompte annuel **et** sur les limites quotidiennes et hebdomadaires.

Le décret territorial rend applicables les règles du décret relatif à l’État, avec des adaptations propres à la FPT : les modalités du cycle sont déterminées par **l’organe délibérant, après avis du CST**. Il ne faut donc pas reprendre les compétences ministérielles mentionnées dans le texte applicable à l’État.

Sources : [décret territorial, règle de renvoi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006379388), version depuis le 14/07/2001 ; [durée de référence](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560142) et [mise en place des cycles territoriaux](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498472), versions depuis le 01/01/2023. Consultations archivées du 11/10/2026.

Le cycle doit respecter les garanties suivantes, **heures supplémentaires comprises** :

| Point contrôlé | Limite ou minimum |
|---|---:|
| Travail effectif quotidien | 10 heures maximum |
| Amplitude de la journée | 12 heures maximum |
| Repos quotidien | 11 heures minimum |
| Travail sur une semaine | 48 heures maximum |
| Moyenne sur toute période de 12 semaines consécutives | 44 heures maximum |
| Repos hebdomadaire | 35 heures minimum, comprenant en principe le dimanche |
| Pause | Au moins 20 minutes avant que le travail quotidien atteigne 6 heures |

**Une période creuse ne compense pas le dépassement d’une garantie minimale pendant une période chargée.** Des dérogations existent dans des cadres strictement définis ; une organisation habituelle ou une simple délibération locale ne suffit pas à les justifier.

Source : [garanties minimales et dérogations](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042560150), version depuis le 01/01/2023, consultation archivée du 11/10/2026.

Deux autres contrôles comptent :

- **Le travail effectif** correspond au temps où l’agent reste à la disposition de l’employeur, suit ses directives et ne peut vaquer librement à ses occupations personnelles. Le nom donné à une « pause » ne suffit donc pas à déterminer son décompte. [Source officielle](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006566083), version depuis le 29/06/2006.
- **Une réduction de la durée annuelle** peut tenir compte de sujétions réelles : nuit, dimanche, horaires décalés, travail en équipes, modulation importante du cycle, travaux pénibles ou dangereux. Elle relève d’une délibération après avis du CST ; elle n’est pas acquise du seul fait que le cycle est annualisé. [Source territoriale](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498477), version depuis le 01/01/2023.

Ces deux sources ont également été consultées dans les traces fournies le 11/10/2026.

**Comment décider du maintien de votre cycle**

La distinction est la suivante :

- **Socle national** : durée de référence, définition du travail effectif, garanties de travail et de repos.
- **Choix local** : période du cycle, horaires, répartition des périodes chargées et creuses, modalités de pause et éventuelle réduction pour sujétions.

Pour examiner votre organisation, il manque trois ensembles d’informations :

1. **Le régime des agents** : service relevant de la FPT de droit commun ou d’un régime particulier ; agents à temps complet, non complet ou partiel.
2. **Le cadre adopté** : délibération initiale, modifications, règlement du temps de travail et avis de l’instance compétente à l’époque.
3. **Le fonctionnement réel** : calendrier annuel, horaires, pauses, repos, décompte des congés et heures supplémentaires, durée annuelle retenue et justification d’une éventuelle réduction.

Pouvez-vous préciser le premier point et reproduire les dispositions utiles de votre délibération ainsi qu’un exemple de planning annuel ?

**Les premières actions à mener**

| Ordre | Responsable | Action et preuve attendue |
|---|---|---|
| 1 | RH et responsable du service | Réunir les documents applicables et les plannings ; établir un décompte annuel explicite. |
| 2 | RH, avec appui juridique | Comparer les horaires réels aux garanties nationales et vérifier la justification des réductions ; produire une liste des écarts. |
| 3 | Autorité territoriale, RH et service | Arrêter le maintien ou les adaptations nécessaires ; si le cadre local doit évoluer, préparer l’avis du CST puis la délibération correspondante. |

**Point restant à vérifier :** le régime de mise en conformité des anciennes organisations plus favorables est évoqué dans le corpus métier, mais sa source officielle n’est pas fournie pour ce cas. Je ne peux donc pas certifier qu’un ancien avantage reste applicable. Ce contrôle doit précéder la validation du maintien.

Les risques principaux sont un décompte annuel erroné, des dépassements pendant les périodes chargées ou un écart entre la délibération et les pratiques. **Niveau de confiance : stable sur les règles nationales documentées ; à vérifier sur votre cadre local ; abstention sur la conformité finale du cycle actuel.**
