# Garde de calibrage — périmètre

## Question
Je suis DRH d'un centre hospitalier universitaire (CHU) de 900 agents. Un agent titulaire est en arrêt maladie depuis 8 mois : quel est son régime de congé de longue maladie ?

## Réponse (contexte vierge)
**Votre CHU relève de la fonction publique hospitalière (FPH).** Le corpus fourni concerne la fonction publique territoriale et exclut expressément la FPH : l’effectif de 900 agents ne change pas cette limite.

**Décision : non tranchable avec ce corpus.** Aucune source officielle n’a été consultée ; la réponse est donc en mode dégradé. Je ne peux pas vous donner les conditions, la durée ou la rémunération du congé de longue maladie hospitalier en appliquant les règles territoriales.

Pour préparer une réponse adaptée, votre service RH doit réunir :

- **L’acte de congé actuel** : congé de maladie ordinaire, CLM déjà accordé ou autre situation.
- **Les dates et l’historique des congés** : début de l’arrêt, décisions et éventuels renouvellements.
- **Les pièces médicales utiles**, dans le circuit confidentiel approprié, sans communiquer le diagnostic dans cet échange.

Le contrôle juridique doit ensuite porter sur les dispositions du **CGFP applicables aux fonctionnaires hospitaliers** et les textes propres à la FPH, dans leur version applicable : accès au CLM, droits à congé, rémunération, avis médical et autorité décisionnaire.

La seule indication « en arrêt depuis huit mois » ne permet pas, avec les éléments fournis, de déterminer son régime de CLM.

**Niveau de confiance : abstention sur le régime demandé**, faute de documentation hospitalière et de vérification officielle.
