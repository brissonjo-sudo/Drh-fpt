# Carrière & paie

## Question
Analyse la possibilité de nommer un agent après avancement de grade puis rédige, dans la même réponse, un projet d'arrêté correspondant. Les informations qui manquent peuvent rester sous forme de champs à compléter.

## Réponse (contexte vierge)
**Décision : non tranchable en l’état.** Un projet peut être préparé, mais les informations absentes ne permettent pas de confirmer que l’agent peut être nommé ni de produire un arrêté prêt à signer.

L’analyse ci-dessous repose uniquement sur les **extraits officiels et les traces de consultation fournis**, datés du 11 octobre 2026. Aucune nouvelle consultation n’a été réalisée.

**Ce que le dossier permet d’établir**

Les extraits distinguent **l’inscription au tableau d’avancement** et **la décision individuelle prononçant l’avancement**. Si l’agent est seulement inscrit au tableau, l’arrêté demandé peut constituer cette décision individuelle. Si un arrêté d’avancement existe déjà, il faut examiner son contenu avant de rédiger un second acte.

Pour la FPT, les sources fournies établissent les contrôles suivants :

| Point | Règle établie par l’extrait fourni |
|---|---|
| Modalité d’avancement | Selon la voie applicable : choix, examen professionnel ou concours professionnel. Au choix, l’autorité tient compte des LDG sans renoncer à son appréciation. |
| Tableau | L’autorité territoriale prononce l’avancement parmi les agents inscrits ; les promotions respectent l’ordre du tableau. |
| Nombre de promotions | Le taux local intervient dans le calcul du nombre maximal de promotions, avec l’exception expressément prévue pour le cadre d’emplois des agents de police municipale. |
| Emploi assigné | L’avancement est subordonné à l’acceptation de l’emploi assigné dans le nouveau grade. |
| Date d’effet | La décision peut prévoir une date d’effet antérieure à son caractère exécutoire. Cet extrait ne suffit pas à valider n’importe quelle date rétroactive. |

Sources : CGFP, extraits [modalités d’avancement](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425506), [taux de promotion](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425500), [autorité et ordre du tableau](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425498), [acceptation de l’emploi](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425496), [date d’effet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044425494). Versions applicables depuis le 1er mars 2022, consultations archivées du 11 octobre 2026.

**Les informations à compléter**

Trois ensembles d’informations conditionnent la finalisation :

1. **Employeur et agent** : quel employeur territorial, quel effectif et quel éventuel statut particulier ? L’agent est-il titulaire, stagiaire ou contractuel ; quels sont son cadre d’emplois, son grade actuel et son grade cible ?
2. **Situation d’avancement** : existe-t-il seulement une inscription au tableau, ou déjà un arrêté individuel ? Quelle voie d’avancement, quel tableau annuel et quel rang ? Quelles LDG et quelle délibération de taux sont applicables, le cas échéant ?
3. **Nomination envisagée** : quelle date d’effet, quel emploi et quelle quotité ? L’emploi est-il accepté ? Quels sont l’échelon et l’ancienneté actuels ?

Ces données sont **bloquantes pour la décision**, même si elles peuvent rester en champs dans le brouillon. L’identité nominative et le numéro de l’arrêté sont, à ce stade, non bloquants.

Le corpus ne contient pas le statut particulier du cadre d’emplois ni les règles de classement. Il ne permet donc pas de confirmer l’éligibilité, l’échelon de classement, l’ancienneté conservée ou les indices.

**Recommandation et préparation**

La DRH peut préparer le document ci-dessous. Avant sa finalisation :

- **Gestionnaire carrière** : réunir les pièces individuelles, le tableau, les LDG et le cadre local applicable ; constituer une fiche de contrôle de l’éligibilité.
- **DRH ou service juridique** : consulter le statut particulier et les règles de classement aux dates utiles ; vérifier l’emploi, les conditions budgétaires et la compétence du signataire.
- **Gestionnaire carrière et paie** : valider le classement et la date d’effet ; faire compléter le projet uniquement avec les données contrôlées.
- **Service des actes** : déterminer les formalités applicables et conserver leurs preuves.

La liste communale de transmission obligatoire fournie ne comporte pas de catégorie générale « avancement de grade ». Cela ne permet pas de conclure sans connaître l’employeur et la nature exacte de l’acte ; une demande préfectorale de communication reste également à examiner. Sources : [CGCT — actes transmis](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560) et [communication à la demande du préfet](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556), versions applicables depuis le 1er juillet 2022, consultations archivées du 11 octobre 2026.

---

**PROJET DE TRAVAIL — NON SIGNABLE EN L’ÉTAT**

**[Nom de la collectivité ou de l’établissement]**  
**Arrêté n° [à compléter] portant avancement de grade de [identité de l’agent]**

*Cette trame correspond à l’hypothèse d’un fonctionnaire territorial inscrit au tableau, dont l’avancement n’a pas encore été prononcé par décision individuelle. Cette hypothèse reste à confirmer.*

**[Qualité de l’autorité territoriale compétente],**

Vu le code général de la fonction publique, notamment ses dispositions relatives à l’avancement de grade des fonctionnaires territoriaux **[références d’articles à relever sur les sources officielles fournies]** ;

Vu **[le texte statutaire applicable au cadre d’emplois : intitulé, référence, dispositions et version à vérifier]** ;

Vu **[les dispositions de classement applicables : références et version à vérifier]** ;

Vu **[les lignes directrices de gestion applicables, date et référence]** ;

Vu **[la délibération fixant le taux de promotion et l’avis du CST correspondant, si ce régime est applicable — visa à adapter ou supprimer après contrôle]** ;

Vu le tableau annuel d’avancement à **[grade cible]** au titre de **[année]**, établi le **[date]**, sur lequel **[identité]** figure au rang **[rang]** ;

Vu l’arrêté n° **[référence]** du **[date]** fixant la situation actuelle de l’agent ;

Vu **[les pièces établissant l’existence de l’emploi, sa quotité et les conditions budgétaires nécessaires]** ;

Vu l’acceptation par l’agent de l’emploi de **[emploi assigné]**, constatée par **[pièce et date]** ;

Considérant **[les éléments vérifiés établissant que l’agent remplit les conditions statutaires de la voie d’avancement retenue]** ;

Considérant **[les éléments vérifiés permettant la promotion dans le respect de l’ordre du tableau et, lorsqu’il s’applique, du nombre maximal de promotions]** ;

**ARRÊTE**

**Article 1 — Avancement de grade**

À compter du **[date d’effet validée]**, **[identité de l’agent]**, fonctionnaire titulaire du grade de **[grade actuel]**, relevant du cadre d’emplois de **[cadre d’emplois]**, est nommé au grade de **[grade cible]** par avancement de grade.

**Article 2 — Classement**

L’agent est classé au **[échelon vérifié]**, avec une ancienneté conservée de **[ancienneté vérifiée]**, conformément à **[dispositions de classement vérifiées]**.

**[Les indices ne seront ajoutés qu’après contrôle de la grille applicable à la date d’effet.]**

**Article 3 — Emploi assigné**

L’agent occupe l’emploi de **[intitulé]**, au sein de **[service]**, à **[temps complet ou temps non complet ; durée de l’emploi à compléter]**.

**[Mention distincte du temps partiel autorisé, si nécessaire et après contrôle.]**

**Article 4 — Formalités**

**[Clause à finaliser après vérification : notification à l’agent, publicité éventuellement requise, transmission obligatoire ou communication éventuelle au représentant de l’État, selon l’employeur et la nature de l’acte.]**

**Article 5 — Recours**

**[Clause à finaliser après identification du tribunal compétent et vérification des voies de recours applicables.]**

Pour préparer cette clause, les extraits fournis établissent un délai contentieux de deux mois à compter de la notification ou de la publication, et subordonnent l’opposabilité des délais à la mention des voies et délais dans la notification. Sources : [CJA — délai de recours](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000039807005), version depuis le 1er janvier 2020 ; [CJA — opposabilité](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449946), version depuis le 1er janvier 2001 ; consultations archivées du 11 octobre 2026.

Fait à **[lieu]**, le **[date de signature]**.

**[Qualité, identité et signature de l’autorité compétente]**  
**[Délégation, uniquement si vérifiée]**

---

**Avant signature :** contrôler surtout l’éligibilité, l’ordre du tableau, le classement, l’emploi accepté, la date d’effet, la compétence et les formalités. Limiter les données personnelles aux informations nécessaires.

**Niveau de confiance : abstention sur la possibilité individuelle de nomination ; socle documentaire établi uniquement dans les limites des extraits fournis.** Le projet reste un support de préparation, sans validation juridique finale.
