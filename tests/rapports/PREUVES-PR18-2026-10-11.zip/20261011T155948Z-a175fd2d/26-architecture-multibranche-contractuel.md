# Carrière & paie + Agents contractuels

## Question
Un agent contractuel en CDI, rémunéré par référence à un indice, demande la reprise de toute son ancienneté et un avancement de grade comme un fonctionnaire titulaire. Analyse sa situation et indique la marche à suivre.

## Réponse (contexte vierge)
**La référence à un indice ne donne pas, à elle seule, les droits de carrière d’un fonctionnaire titulaire.** Il faut distinguer la demande d’avancement de grade de celle d’une meilleure prise en compte de l’expérience dans la rémunération.

Analyse au **11 octobre 2026**, fondée sur les extraits officiels archivés fournis. La date d’effet souhaitée d’une éventuelle revalorisation reste à préciser.

**1. Ce que l’agent peut demander**

Dans le régime contractuel ordinaire décrit par le corpus, l’indice constitue une **référence de rémunération**, sans conférer un grade. L’avancement de grade du titulaire ne se transpose donc pas au CDI. De même, la reprise d’ancienneté selon les règles de classement des fonctionnaires ne peut pas être appliquée automatiquement au contractuel.

En revanche, l’expérience professionnelle fait partie des éléments à prendre en compte pour fixer sa rémunération, avec les fonctions exercées et les qualifications requises et détenues. **Prendre en compte l’expérience ne signifie pas reprendre obligatoirement chaque année d’ancienneté selon une grille de fonctionnaire.**

Sources fournies pour la fixation de la rémunération :

- [CGFP — disposition relative à la rémunération des contractuels](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044424781), version applicable depuis le 1er mars 2022, consultation archivée du 11 octobre 2026.
- [Décret relatif aux contractuels territoriaux — fixation et réévaluation de la rémunération](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054242039), version applicable depuis le 1er juillet 2026, consultation archivée du 11 octobre 2026.

Ce dernier extrait prévoit pour les CDI une **réévaluation au moins tous les trois ans**, notamment au regard des entretiens professionnels ou de l’évolution des fonctions. Cette obligation d’examen ne fixe ni augmentation automatique ni montant garanti.

**2. Ce qu’il faut clarifier avant de décider**

Les données connues sont le CDI, la référence indiciaire et les deux demandes de l’agent. Pour trancher leur portée concrète, trois ensembles de pièces sont nécessaires :

- **Le contrat et ses avenants** : contrat de droit public territorial, fondement du recrutement, clauses de rémunération et éventuelle clause d’évolution.
- **L’emploi et le cadre local** : fonctions réellement exercées, éventuel emploi fonctionnel, délibération ou cadre local de rémunération. L’extrait officiel prévoit une dérogation pour certains emplois fonctionnels : leur régime doit être contrôlé séparément.
- **L’historique professionnel et salarial** : expériences dont la reprise est demandée, justificatifs, dernière réévaluation, entretiens professionnels et date d’effet souhaitée.

Le type d’employeur et son effectif restent également à confirmer pour le périmètre du corpus DRH, consacré aux collectivités de plus de 350 agents.

**État de décision :**

- **Impossible en l’état** de traiter les demandes comme un avancement de grade et une reprise statutaire d’ancienneté de titulaire sur le seul fondement de l’indice.
- **Possible sous conditions** d’examiner une revalorisation tenant compte de l’expérience, des fonctions et des clauses applicables.
- **Non tranchable**, avec les seules données fournies, quant au droit à une évolution précise, à son montant ou à sa date d’effet.

**3. Marche à suivre**

| Ordre | Action | Responsable et preuve attendue |
|---|---|---|
| 1 | Réunir les pièces ci-dessus et préciser les expériences revendiquées. | Gestionnaire RH et agent : dossier documenté. |
| 2 | Vérifier les clauses contractuelles, le cadre local et l’absence de régime spécial. | DRH / service juridique : analyse écrite des dispositions applicables. |
| 3 | Contrôler la date de dernière réévaluation et apprécier l’expérience utile, les responsabilités et les résultats professionnels. | DRH et supérieur hiérarchique : proposition motivée. |
| 4 | Soumettre l’arbitrage salarial à l’autorité territoriale, puis formaliser l’évolution éventuelle après contrôle du support nécessaire. | Autorité territoriale et DRH : décision et pièces de rémunération cohérentes. |
| 5 | Répondre distinctement aux deux demandes de l’agent. | DRH : explication du régime contractuel et résultat de l’examen salarial. |

Pour un CDI sur emploi permanent, l’entretien professionnel annuel est prévu par l’[extrait officiel fourni](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000043498480), version applicable depuis le 1er janvier 2023, consultation archivée du 11 octobre 2026. Son compte rendu peut alimenter l’examen salarial.

Si l’objectif de l’agent est une **carrière statutaire**, une voie d’accès au statut de fonctionnaire peut être étudiée séparément ; ses conditions ne sont pas vérifiées par les extraits de ce dossier.

**Contrôles avant mise en œuvre :** éviter de présenter l’indice comme un grade, vérifier toute clause d’évolution, justifier l’arbitrage et contrôler ses effets en paie. Aucun montant ni acte individuel ne peut être finalisé ici.

**Confiance : stable** pour les règles de fixation et de réévaluation présentes dans les extraits officiels ; **à vérifier** pour leur traduction dans le contrat et l’emploi de cet agent.
