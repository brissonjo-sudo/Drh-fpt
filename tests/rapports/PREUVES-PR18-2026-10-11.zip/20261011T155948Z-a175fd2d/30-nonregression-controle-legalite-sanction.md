# Carrière & paie

## Question
Une exclusion temporaire de fonctions de 5 jours prononcée contre un fonctionnaire communal doit-elle obligatoirement être transmise au contrôle de légalité au titre de l'article L. 2131-2 du CGCT ?

## Réponse (contexte vierge)
**Non.** Une exclusion temporaire de fonctions de **5 jours** infligée à un fonctionnaire communal **n’est pas obligatoirement transmissible au titre de l’article L. 2131-2 du CGCT**.

Dans la version applicable au **11 octobre 2026**, cet article ne mentionne pas les sanctions disciplinaires parmi les actes soumis à transmission obligatoire. J’en déduis que cette exclusion n’entre pas dans cette obligation sur ce fondement.

Le préfet peut toutefois **en demander communication**, conformément à l’[article L. 2131-3 du CGCT](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190556). L’absence de transmission obligatoire ne soustrait donc pas l’acte au contrôle de légalité.

**Conséquence pratique :** vérifier une éventuelle demande préfectorale et le circuit local de télétransmission, sans les confondre avec l’obligation légale.

**Confiance : stable**, sur la base des extraits officiels et des traces de consultation fournis, datés du 11 octobre 2026 — [article L. 2131-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044190560), version en vigueur depuis le 1er juillet 2022.
